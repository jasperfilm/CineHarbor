# Browser (Playwright / E2E) Tests — Single Source of Truth

This is the **canonical guide** for Playwright browser tests in ComfyUI_frontend.
Setup, running, structure, conventions, flake prevention, typed mocks, and the
screenshot workflow all live here. Other test docs are short stubs that redirect
to a section below.

**Where guidance lives**

| Concern                                    | Location                                                                               |
| ------------------------------------------ | -------------------------------------------------------------------------------------- |
| Everything about writing/running E2E tests | **This file** (canonical)                                                              |
| Agent auto-load in `browser_tests/`        | `browser_tests/AGENTS.md` (stub → this file)                                           |
| Agent auto-load on `*.spec.ts` edit        | `docs/guidance/playwright.md` (stub → this file)                                       |
| Flake triage checklist                     | [Flake Prevention](#flake-prevention) (was `FLAKE_PREVENTION_RULES.md`)                |
| Mock data fixtures                         | [Test Data & Typed Mocks](#test-data--typed-api-mocks) (was `fixtures/data/README.md`) |
| Authoring skill (agents)                   | `.claude/skills/writing-playwright-tests/SKILL.md`                                     |
| Flake-hardening skill (agents)             | `.claude/skills/hardening-flaky-e2e-tests/SKILL.md`                                    |
| Review rulebook (subagent)                 | `.agents/checks/playwright-e2e.md` (references this file)                              |

---

## Prerequisites

For real Cloud billing E2E setup and account prerequisites, see [Cloud billing E2E coverage](../docs/testing/cloud-billing-e2e.md).
Its dedicated runner requires real authentication and a dedicated sandbox account;
the live suite is excluded from the ordinary browser test configurations.

**CRITICAL**: Start the ComfyUI backend with `--multi-user`:

```bash
python main.py --multi-user
```

Without this flag, parallel tests conflict and fail randomly.
`pnpm container:start` already passes it.

## Setup

### ComfyUI devtools

ComfyUI_devtools ships in this repo under `tools/devtools/` and is copied into
`custom_nodes` automatically during CI. It adds API endpoints and nodes used by
browser tests. For local development, copy it into your ComfyUI install (create the target
directory first — it won't exist on a fresh install):

```bash
mkdir -p /path/to/your/ComfyUI/custom_nodes/ComfyUI_devtools
cp -r tools/devtools/* /path/to/your/ComfyUI/custom_nodes/ComfyUI_devtools/
```

### Containerized ComfyUI

To run a containerized ComfyUI backend instead of maintaining a separate
install, install and start Docker, then run:

```bash
pnpm container:start
```

The command mounts `tools/devtools` and starts ComfyUI at `localhost:8188`.
Leave it running. Use another terminal for `pnpm dev:test` and a third for
`pnpm test:browser:local`.

Run browser tests against port 5173 when using this container. Port 8188 serves
the frontend bundled into the container, not the current frontend checkout.

The CI image is private. If it is not cached, the launcher pulls it from GHCR
with `GH_TOKEN` and gets the matching username from `gh api user`.
`COMFY_CI_CONTAINER_TOKEN` and `COMFY_CI_CONTAINER_USER` take precedence when
set. The token must be a personal access token (classic) with the
`read:packages` scope, owned by an account that can read
`comfy-org/comfyui-ci-container`. GHCR rejects fine-grained tokens.
`gh auth status` lists the scopes of the current `GH_TOKEN`.

If credentials are missing or the pull fails, the launcher says why and builds
the matching release from source instead. This fallback may differ from the
published CI image. The build takes 15 to 20 minutes and uses about 10 GB, plus
Docker build cache. Its `apt-get` steps can pause for minutes on slow Ubuntu
mirrors and then continue. Later starts reuse the built image.

The launcher log shows which path it took:

| Log line                                                                 | Meaning                                      |
| ------------------------------------------------------------------------ | -------------------------------------------- |
| `Using cached image ghcr.io/...`                                         | CI image; the backend starts within seconds  |
| `Status: Downloaded newer image for ghcr.io/...`                         | CI image pulled in about a minute            |
| `GHCR credentials are not configured` or `The private image pull failed` | A source build follows                       |
| `Using source-built fallback ...`                                        | Fallback image is built; ComfyUI is starting |
| `To see the GUI go to: http://0.0.0.0:8188`                              | Backend ready                                |

### Remote agent containers

Agent containers run the backend and the dev server as background services.
In Amp orbs, `.agents/setup` installs Docker and `.amp/services.yaml` declares
`docker-daemon`, `comfyui` (`pnpm container:start`), and `frontend`
(`pnpm dev:test` on 5173). `amp orb services ensure` starts them and waits for
their ports; stopping it early leaves them starting. The `frontend` service
waits about 10 minutes for the backend, then exits and restarts, so a long
source build needs no intervention. Other platforms can run the same commands
as services.

Store the GHCR token as a container secret: add `read:packages` to `GH_TOKEN`,
or set `COMFY_CI_CONTAINER_TOKEN` to keep that scope off `GH_TOKEN`. Restart
the container processes after changing secrets.

Set `COMFYUI_FRONTEND_MODE=cloud` to skip Docker and the local backend and run
the frontend against the Comfy test cloud for manual work. E2E needs local
mode. The regular Playwright projects, `cloud` included, all run against the
local backend.

### Node.js & Playwright

Install the Node version in `.nvmrc`, then the workspace dependencies and the
Chromium and WebKit drivers (run from the repository root):

```bash
pnpm install
pnpm exec playwright install chromium webkit --with-deps
```

### Environment

Start the dev server with `pnpm dev:test`. It removes the Vue dev overlay that
blocks UI elements (`DISABLE_VUE_PLUGINS`) and loads the default workflow CI
builds with (`VITE_USE_LEGACY_DEFAULT_GRAPH`).

Create `.env` from the template and set the debugging keys:

```bash
cp .env_example .env
```

```bash
# Test against dev server (recommended) or backend directly
PLAYWRIGHT_TEST_URL=http://localhost:5173      # Dev server
# PLAYWRIGHT_TEST_URL=http://localhost:8188     # Direct backend
PLAYWRIGHT_SETUP_API_URL=http://localhost:8188 # Setup/auth API when using the dev server

# Path to ComfyUI for backing up user data/settings before tests
TEST_COMFYUI_DIR=/path/to/your/ComfyUI
```

### Release API mocking

By default all tests mock `api.comfy.org/releases` so release popups don't cover
UI elements. To supply a custom release response before the first app load:

```typescript
test.use({ mockReleases: false })
```

Install the replacement route in a test-scoped auto fixture that depends on
`page`, before `comfyPage` boots. Disabling the default mock does not disable
network isolation. See `fixtures/releaseNotificationFixture.ts` and
`tests/releaseNotifications.spec.ts` for release-specific responses and request
tracking.

### Network isolation

The live Cloud routing infrastructure spec requires `openssl` on PATH to generate
a disposable localhost TLS certificate; it does not use a live account.

The shared fixtures allow HTTP and real WebSockets only to the configured
frontend/backend origins: `PLAYWRIGHT_TEST_URL`, `PLAYWRIGHT_SETUP_API_URL`,
`DEV_SERVER_COMFYUI_URL`, and Playwright's `baseURL`. Service workers are blocked.
Other browser requests must have a local `route.fulfill()` or intentional
`route.abort()` mock. An unmocked request is blocked and fails its owning test,
even if the app catches the network error. Popup mocks belong on `context`,
not `page`, so they cover the first navigation.

Use `route.fallback()` for unmatched requests. `route.continue()` bypasses
other handlers. Oxlint bans raw Playwright `test` imports and `continue()`
outside `networkIsolationFixture.ts`. Extend that fixture for custom test roots.
Keep auth mocks in the existing auth helpers; shared mocks
only replace third-party scripts, model metadata lookups, and carousel media.
Use scoped `test.use({ userAgent })` rather than `browser.newContext()` so
custom user agents retain the fixture's isolation.

Both `request` and `context.request` reject external URLs and disable automatic
redirect following. Node networking, new standalone request/browser contexts,
`route.fetch()`, and browser redirects can bypass fixture routing. For a full
test-process network boundary, run the frontend, backend, and tests together
in a Docker container with networking disabled:

```bash
pnpm install --frozen-lockfile
VITE_USE_LEGACY_DEFAULT_GRAPH=true pnpm build
docker pull ghcr.io/comfy-org/comfyui-ci-container:0.0.28
scripts/test-browser-offline.sh --project=chromium errorDialog.spec.ts
```

Complete downloads and builds first. The offline runner never pulls an image
or invokes the package manager. It requires a Linux-compatible `node_modules`
and a cached CI image. `COMFYUI_TEST_IMAGE` selects a source-built image;
`PLAYWRIGHT_OFFLINE_DIST` selects another built distribution, such as a cloud
build for `--project=cloud` or `--project=mobile-safari`. Remote backend runs
still use the regular test commands, not the offline runner.

The container runs as root so the bundled backend can write to `/ComfyUI`.
Generated reports are root-owned on the host. Before running tests outside the
container, restore ownership of each generated output directory with
`sudo chown -R "$(id -u):$(id -g)" test-results`, substituting
`playwright-report`, `blob-report`, `coverage`, or your `--output` directory
when used.

## Recording Tests (For Non-Developers)

If you're a QA tester or non-developer, use the interactive recorder:

```bash
pnpm comfy-test record
```

`pnpm comfy-test recorder` is an equivalent alias and accepts the same flags.

This guides you through a 6-step flow:

1. **Environment check** — verifies the tools, the backend, and the dev server (with install instructions if anything is missing)
2. **Project setup** — installs dependencies
3. **Configure** — set test name, tags, and starting workflow
4. **Record** — opens the browser with the Playwright Inspector; press Record, act, then close both windows — the generated code is saved automatically as you go, no copy/paste
5. **Transform** — the captured code is rewritten to project conventions automatically
6. **Refactor (optional)** — offers to hand the spec to a local coding-agent CLI (Claude Code, Codex, Gemini CLI, ...) for a convention pass, if one is installed

Then, if you want, it opens a PR for you via `gh` CLI (or gives manual instructions).

`record` needs a real terminal — it exits immediately with guidance if run
without one (piped input, CI, etc).

The dev server must be serving _this_ checkout. Step 1 fails if the port is
held by a server started from a different folder. To use another port:

```bash
pnpm dev --port 5174 --strictPort
COMFY_TEST_DEV_PORT=5174 pnpm comfy-test record
```

### For agents

`record` is built around a human clicking a real browser and can't be
driven programmatically. An agent should use `comfy-test plan` instead —
fully non-interactive, no terminal required:

```bash
pnpm comfy-test plan --description "collapsing a KSampler node keeps its connections" \
  --tags @canvas,@widget
```

This validates the environment/tags/workflow and prints a test-plan block
ready to hand to the `playwright-test-generator` agent
(`.claude/agents/playwright-test-generator.md`), which drives the app via
Playwright MCP tools and writes a convention-compliant spec directly — no
`transform` step needed. Then open the PR:

```bash
pnpm comfy-test pr browser_tests/tests/<slug>.spec.ts
```

Other commands:

```bash
pnpm comfy-test check       # Just run environment checks
pnpm comfy-test plan --description "<what to test>"  # Print a plan for playwright-test-generator
pnpm comfy-test transform <file>  # Transform a raw codegen file
pnpm comfy-test pr <file>   # Open a PR for a generated test
pnpm comfy-test list        # List available workflow assets
```

## Running Tests

Start the backend and the dev server first (see [Setup](#setup)). Both checks
must pass:

```bash
curl -sf localhost:8188/system_stats >/dev/null && echo backend ready
curl -sf localhost:5173/ >/dev/null && echo frontend ready
```

```bash
pnpm test:browser:local                     # Run all E2E tests
pnpm test:browser:local widget.spec.ts      # Run a specific file
pnpm test:browser:local --ui                # Interactive UI mode (use for development)
```

Run the first spec after the dev server starts with one worker, the
`test:browser:local` default. Vite compiles the app on the first page load, and
parallel workers against a cold server time out in `beforeEach` with
`app never became ready`.

**Use UI mode while developing.** It provides:

- **Locator picker** — click an element to get its exact locator code
- **Step debugging** — step through a test line by line via the _Source_ tab
- **Time travel** — click any step in _Actions_ to see browser state at that moment
- **Console / Network / Attachments** tabs — logs, API calls, and snapshot diffs

### Environment failures

Rule these out before blaming the change under test:

| Symptom                                                    | Cause                                                   |
| ---------------------------------------------------------- | ------------------------------------------------------- |
| `connect ECONNREFUSED` on 5173 or 8188                     | Backend or dev server not running yet                   |
| `app never became ready` on the first run only             | Cold Vite with parallel workers; rerun                  |
| Default-graph nodes such as `Load Checkpoint` are missing  | Dev server without `VITE_USE_LEGACY_DEFAULT_GRAPH=true` |
| Backend-provided data differs on the source-built fallback | Fallback differs from the CI image; confirm in CI       |

A failure that also reproduces on the merge base is not caused by the change. The
dev server serves whatever the checkout holds, so rerun the spec after
`git switch --detach "$(git merge-base HEAD origin/main)"`, then switch back.

### Slowing the browser down

With `--headed` or `--ui`, set `SLOW_MO` (ms) to slow every action. Applies only
when `PLAYWRIGHT_LOCAL` is set (the default for `test:browser:local`):

```bash
SLOW_MO=250 pnpm test:browser:local --headed widget.spec.ts
```

## Directory Structure

```text
browser_tests/
├── assets/           - Test data (JSON workflows, images)
├── fixtures/
│   ├── ComfyPage.ts      - Main fixture (delegates to helpers)
│   ├── ComfyMouse.ts     - Mouse interaction helper
│   ├── VueNodeHelpers.ts - Vue Nodes 2.0 helpers
│   ├── selectors.ts      - Centralized TestIds
│   ├── data/             - Static test data (mock API responses, workflow JSONs, node definitions)
│   ├── components/       - Page object classes (locators, user interactions)
│   ├── helpers/          - Focused helper classes (domain-specific actions)
│   └── utils/            - Standalone utility functions (used by tests or fixtures)
└── tests/            - Test files (*.spec.ts), nested by feature
```

### Spec File Placement

- **Nest specs in a folder that mirrors the feature under test.** Do not dump
  new specs at the top level of `tests/` — create/extend the matching feature
  subfolder (e.g. `tests/templates/`, `tests/nodes/`) so the layout mirrors the
  product surface. A flat `tests/*.spec.ts` pile is not acceptable for new work.
- **Keep spec filenames current.** A spec's name must describe the coverage it
  actually holds. When a test's scope changes, rename the file — never leave a
  stale name that misdescribes what runs. Stale names send reviewers and future
  authors to the wrong file.

### Architectural Separation

- **`fixtures/data/`** — Test data: mock API responses, workflow JSONs, node
  definitions, and the typed factory builders that produce them (e.g.
  `createMockNodeDefinitions`). No Playwright imports and no test logic — data
  and the functions that assemble it, nothing else.
- **`fixtures/components/`** — Page object components. Classes that own locators
  for a specific UI region (e.g. `Actionbar`, `ContextMenu`, `SettingDialog`,
  `Templates`).
- **`fixtures/helpers/`** — Helper classes that coordinate actions across
  multiple regions without owning a locator surface of their own (e.g.
  `CanvasHelper`, `WorkflowHelper`, `NodeOperationsHelper`).
- **`fixtures/utils/`** — Standalone exported functions (not classes) used by
  tests or fixtures (e.g. `fitToView`, `clipboardSpy`, `builderTestUtils`).

### File Placement Rule

```mermaid
flowchart TD
    A[New file in browser_tests/fixtures/] --> B{Has any code?}
    B -- No, JSON/data only --> D[fixtures/data/]
    B -- Yes --> C{Is it a class?}
    C -- No, exported functions --> V{Pure data or a typed<br/>data factory?}
    V -- Yes --> D
    V -- No, test utility --> U[fixtures/utils/]
    C -- Yes --> E{Owns locators for a<br/>specific UI region?}
    E -- Yes --> P[fixtures/components/]
    E -- No, coordinates actions<br/>across the app --> H[fixtures/helpers/]
```

### Custom-node regression suite

`tests/customNodes/` holds the manifest-driven suite that proves community
custom-node packs load, render in both renderers (LiteGraph canvas and Vue
Nodes 2.0), and execute real workflows. It has its own prerequisites, pnpm
scripts (`pnpm test:custom-nodes` and variants), and a one-JSON-row process
for adding packs - see
[docs/custom-node-regression-suite.md](../docs/custom-node-regression-suite.md).

## Writing Tests

Design rules that hold at every test level (behavioral assertions, lowest
proving level, table-driven variants, isolation, no sleeps) are in
`docs/guidance/testing-principles.md`, which auto-loads for `*.spec.ts`. This
guide covers the Playwright and ComfyUI mechanics.

### Golden rules

1. **Look at existing tests first.** Search `tests/` for similar patterns.
2. **Read the fixture code.** APIs live in `fixtures/` — read them directly
   instead of guessing.
3. **Use premade JSON workflow assets** instead of building graphs
   programmatically. Assets live in `assets/`; create new ones by copying
   `assets/default.json` and editing the JSON.

### Before changing an existing test

Run a **regression-detection pass** before you edit a test you did not write.
`git blame` (or `git log -p`) the lines you are about to change and read the
commit that introduced them — an assertion, wait, or timeout that looks
redundant is often a deliberate fix for a past flake or bug. Confirm you are not
silently undoing that fix. If the history shows the line guards a specific
race/regression, preserve the guarantee (keep it, or replace it with an
equivalent) rather than deleting it.

### Test structure — Arrange / Act / Assert

- All mock setup, state resets, and fixture arrangement belong in
  `test.beforeEach()` or Playwright fixtures.
- Prefer `test.use({ initialSettings })` for starting settings rather than
  `comfyPage.settings.setSetting()` in `beforeEach`.
- Inside `test()`, only **act** (user actions) and **assert**.
- Never call `clearAllMocks` or reset mock state mid-test.
- **Free-standing helpers, constants, and locator wiring don't belong inline in
  the spec — move them to a helper, fixture, or page object.** Reusable dialog
  interactions (closing the templates dialog, dismissing a modal), setup
  routines, and locator wiring belong in `fixtures/components/` (page objects),
  `fixtures/helpers/`, or a Playwright fixture — not as free-standing functions
  or constants at the top of the spec. Example: a "close the templates dialog"
  step becomes a method on a `Templates` page object, not an inline helper in the
  spec. Top-level Playwright hooks and configuration are fine to keep in the spec:
  `test.use()`, `test.describe.configure()`, and file-level `test.beforeEach()`/
  `test.afterEach()` are Playwright's own API, not the free-standing code this
  rule targets. A spec file should otherwise contain only `test.describe`/`test`
  blocks, those Playwright hooks/config, and imports.

```typescript
import {
  comfyPageFixture as test,
  comfyExpect as expect
} from '@e2e/fixtures/ComfyPage'

test.describe('Feature', { tag: ['@canvas'] }, () => {
  test.beforeEach(async ({ comfyPage }) => {
    await comfyPage.workflow.loadWorkflow('test.json')
  })

  test('should do something', async ({ comfyPage }) => {
    await comfyPage.menu.topbar.click()
    await expect(comfyPage.menu.nodeLibraryTab.root).toBeVisible()
  })
})
```

### Import conventions

- Prefer `@e2e/*` for imports within `browser_tests/`.
- Use `@/*` for imports from `src/`.
- Avoid new deep relative imports when an alias is available.

### Leverage existing fixtures and helpers

Check for existing helpers before writing new ones — most needs are covered:

- **ComfyPage** — main fixture; delegates to helper objects:
  `comfyPage.workflow.loadWorkflow()`, `comfyPage.settings.setSetting()`,
  `comfyPage.command.executeCommand()`, `comfyPage.nodeOps.getNodeRefById()`.
- **Component page objects** — `fixtures/components/` (e.g. `Actionbar`,
  `ContextMenu`, `Templates`).
- **Helper classes** — `fixtures/helpers/` (e.g. `CanvasHelper`,
  `WorkflowHelper`).
- **Utilities** — `fixtures/utils/` (e.g. `fitToView`, `clipboardSpy`).

### Creating new test helpers

Register **new** domain-specific helpers as Playwright fixtures via
`base.extend()` — do **not** attach them as new properties on `ComfyPage`.
Fixtures get automatic setup/teardown and compose via `mergeTests`.

```typescript
// browser_tests/fixtures/assetFixture.ts
import { test as base } from '@playwright/test'

export const test = base.extend<{ assetHelper: AssetHelper }>({
  assetHelper: async ({ page }, use) => {
    const helper = new AssetHelper(page)
    await helper.setup()
    await use(helper)
    await helper.cleanup() // automatic teardown
  }
})
```

Extend `@playwright/test` base (not `comfyPageFixture`) so helpers can be
composed. The existing `comfyPage.*` helpers predate this rule and remain on
`ComfyPage`; new ones should be fixtures.

### Page object locator style

Define locators as `public readonly` properties assigned in the constructor —
not as getter methods. Getters that just return a locator add indirection and
hide the object shape from IDE auto-complete.

```typescript
// ✅ public readonly, assigned in constructor
export class MyDialog extends BaseDialog {
  public readonly submitButton: Locator
  constructor(page: Page) {
    super(page)
    this.submitButton = this.root.getByRole('button', { name: 'Submit' })
  }
}
```

Keep getters only for lazy init (`this._tab ??= new Tab(this.page)`),
runtime-computed values, or private convenience accessors. Reuse cached locator
properties in methods rather than rebuilding locators.

### Selectors

- Prefer role, label, or test-id selectors over CSS/DOM-structure selectors.
- Hard-coded `data-testid` strings should reference `fixtures/selectors.ts` when
  a matching entry exists.
- When multiple nodes share a title, disambiguate:
  `vueNodes.getNodeByTitle(name).nth(n)` — strict mode fails on ambiguous
  locators.
- Never locate a toast by its copy with `getByText` or
  `getByRole('alert' | 'status').filter({ hasText })`: `Toaster` repeats every
  toast's text in live regions with those roles. Use
  `comfyPage.toast.withText(text)` and its kind locators such as
  `toastErrors`. Tests without `comfyPage` (`cloudAppFixture`, `agentTest`,
  or a `page`-only test) destructure the `toast` fixture instead. Specs may
  not construct a `ToastHelper`; lint allows only type imports.

### Node references over coordinates

Node references from `fixtures/utils/litegraphUtils.ts` are stable; raw
coordinates are fragile.

```typescript
// ✅ Prefer — target by id, or by type when exactly one match is expected
const node = await comfyPage.nodeOps.getNodeRefById('12')
await node.click('title')

// ❌ Avoid
await comfyPage.canvas.click({ position: { x: 100, y: 100 } })
```

When selecting by type and more than one node can match, don't index `[0]` on
the returned array — the order is non-deterministic (see the
[Flake Prevention](#flake-prevention) patterns table). Use `getNodeRefById()`,
or guard with `toHaveLength(1)` first.

### Vue Nodes vs LiteGraph — decision guide

Choose based on **what you're testing**:

| Testing…                                       | Use                              | Why                                  |
| ---------------------------------------------- | -------------------------------- | ------------------------------------ |
| Vue-rendered node UI, DOM widgets, CSS states  | `comfyPage.vueNodes.*`           | Nodes are DOM elements; use locators |
| Canvas interactions, connections, legacy nodes | `comfyPage.nodeOps.*`            | Canvas-based; use coordinates/refs   |
| Both in one test                               | Pick primary, minimize switching | Mixing both is a smell               |

Always add `{ tag: '@vue-nodes' }` to the test or `test.describe` when it needs
Vue Nodes. The fixture enables the renderer before boot and waits for the nodes.
Never manually set `Comfy.VueNodes.Enabled`, including through `initialSettings`,
or call `comfyPage.vueNodes.waitForNodes()` in tests.

When renderer switching is the behavior under test, use
`comfyPage.menu.topbar.setVueNodesEnabled(enabled)`. It clicks the Nodes 2.0
switch and waits for the renderer. Keep `@vue-nodes` on these tests.
For command-level transitions, use
`comfyPage.command.executeCommand('Experimental.ToggleVueNodes')` and assert
the resulting behavior. This also works when an overlay blocks the menu.
Untagged tests start in classic mode, regardless of product defaults.

Vue Node state is expressed via CSS classes:

```typescript
const BYPASS_CLASS = /before:bg-bypass\/60/
await expect(node).toHaveClass(BYPASS_CLASS)
```

### Canvas timing

- After canvas ops (`drag`, canvas `click`, `resizeNode`, `pan`, `zoom`, or a
  `page.evaluate` graph mutation that changes visuals), call
  `await comfyPage.nextFrame()` before asserting. `loadWorkflow()` does **not**
  need it. Prefer encapsulating `nextFrame()` inside page-object methods.
- Focus the canvas before keyboard input: `await comfyPage.canvas.click()`
  before `page.keyboard.press(...)`, or keys go nowhere.
- Mark the canvas dirty after programmatic state changes:
  `window['app'].graph.setDirtyCanvas(true, true)`.
- `dblclick()` on canvas needs a small `{ delay: 5 }`. Use the shared drag
  helpers, which emit enough intermediate events for canvas behavior without
  making coverage runs process excessive pointer events. For a local drag,
  use the fewest steps the behavior needs (usually 5–20), never 100.

### Custom assertions

Prefer adding assertion methods directly on the page object or helper class —
they're discoverable via IntelliSense without special imports.

```typescript
// ✅ Page-object assertions for new code
await node.expectPinned()
```

The existing `comfyExpect` matchers (`toBePinned`, `toBeBypassed`,
`toBeCollapsed`, `toHaveFocus`, `toHaveScreenshot`) in
`fixtures/utils/customMatchers.ts` remain supported and are used across the
suite — keep using them. Do **not** extend `comfyExpect` with new matchers;
add new assertions as page-object methods instead.

### Test tags

Two tiers. **Project-routing tags are load-bearing** — `playwright.config.ts`
selects which project/run a test lands in by grepping these, so a test only runs
where its tags place it:

| Tag           | Effect (per `playwright.config.ts`)                    |
| ------------- | ------------------------------------------------------ |
| `@mobile`     | Runs in the mobile-chrome (Pixel 5) project            |
| `@mobile-ios` | Runs in the mobile-safari (iPhone 15 / WebKit) project |
| `@2x`         | Runs in the 2x-scale project                           |
| `@0.5x`       | Runs in the 0.5x-scale project                         |
| `@perf`       | Runs in the perf project                               |
| `@audit`      | Runs in the audit project                              |
| `@cloud`      | Runs in the cloud project                              |
| `@desktop`    | Runs against the desktop build                         |
| `@oss`        | Excluded from the cloud project                        |

Use `@mobile-ios` sparingly — only for regressions that reproduce under
iOS-shaped conditions (WKWebView bridge exposure, WebKit-only quirks). Playwright's
WebKit engine does not expose embedded-WKWebView globals such as
`window.webkit.messageHandlers`; inject them via `page.addInitScript()` and set the
context `userAgent`. See `browser_tests/tests/cloudLoginIosWebview.spec.ts` for the
reference pattern.

The `@desktop` tag only selects the desktop project. Tests that need Electron
APIs must import `desktopFixture` from `@e2e/fixtures/desktopFixture` to install
the mocked bridge before the app starts.

Organizational tags are used for manual `--grep` filtering (not project
routing). Common ones in the suite: `@smoke`, `@slow`, `@screenshot`, `@canvas`,
`@node`, `@widget`, `@subgraph`, `@ui`. Apply them so a test is
findable by its area; add a project-routing tag whenever the test must run in
that project.

`@vue-nodes` controls fixture setup, not just filtering. It is required for
Vue-node tests and owns renderer selection and initial readiness.

```typescript
test.describe('Feature', { tag: ['@screenshot', '@canvas'] }, () => {
```

### Type safety

Never use `any` or `as any` in E2E code.

Browser tests read `window.app`, `window.graph`, `window.LiteGraph` (optional in
app types). Use non-null assertions in E2E tests only:

```typescript
window.app!.graph!.nodes
window.LiteGraph!.registered_node_types
```

Acceptable type assertions:

```typescript
window.app!.extensionManager
id: 'TestSetting' as TestSettingId
type TestSettingId = keyof Settings
```

Forbidden: `settings: testData as any`, `data as unknown as SomeType`. Read
internal state via `page.evaluate` and stores directly — don't widen public API
types to expose internals.

**Never inline-declare types in tests.** Do not hand-write `interface`/`type`
shapes for API payloads, node definitions, or store data inside a spec or mock
file. Import the real type instead — the generated packages
(`@comfyorg/ingest-types`, `@comfyorg/registry-types`, `generatedManagerTypes.ts`)
or the `src/` Zod schemas (see
[Test Data & Typed Mocks](#test-data--typed-api-mocks) for the full source-of-truth
table). An inline type is a copy that silently drifts from the real shape; a
generated type or schema fails to compile the moment the contract changes.

### Assertion messages & soft assertions

Attach a message to precondition checks so a failure points at the broken
assumption, and use `expect.soft()` to verify several invariants without
aborting on the first failure:

```typescript
expect(node.widgets, 'Widget count changed — update test fixture').toHaveLength(
  4
)

expect.soft(menuItem1).toBeVisible()
expect.soft(menuItem2).toBeVisible()
```

### When to use `page.evaluate`

**Acceptable (sparingly)** — reading internal state with no UI representation, or
setting up fixtures:

```typescript
const nodeCount = await page.evaluate(() => window.app!.graph!.nodes.length)
await page.evaluate(() => useWorkflowStore().activeWorkflow)
await page.evaluate(() => window.app!.registerExtension({ name: 'TestExt' }))
```

**Avoid** — performing actions that have a UI equivalent; use locators instead:

```typescript
// ❌ node.widgets![0].value = 512     ✅ widgetLocator.click(); widgetLocator.fill('512')
// ❌ btn.dispatchEvent(new MouseEvent('click'))  ✅ page.getByTestId('...').click()
// ❌ app.queuePrompt(0)               ✅ page.getByRole('button', { name: 'Queue' }).click()
```

**Preferred** — helper methods from `fixtures/helpers/` that wrap real user
interactions.

### Starting settings and isolation

Use `test.use({ initialSettings })` at the narrowest file or describe scope:

```typescript
test.use({
  initialSettings: {
    'Comfy.UseNewMenu': 'Disabled',
    'Comfy.Canvas.SelectionToolbox': true
  }
})
```

`comfyPageFixture` replaces the worker user's entire settings file before each
test. It merges the common baseline, the `@vue-nodes` renderer override, and
`initialSettings`, in that order. Omitted keys from previous tests disappear.
The browser context is test-scoped, and initial setup clears localStorage and
sessionStorage. Tests do not need settings resets in `afterEach`.

Nested `test.use` calls **replace**, not merge, the parent's `initialSettings`
object. Include every suite-specific override needed by a nested scope. Use
`@vue-nodes` for renderer selection; never put `Comfy.VueNodes.Enabled` in
`initialSettings`.

Keep runtime `setSetting` calls when a live change or persistence is the behavior
under test. A same-test reload retains those changes.
Preserve readiness checks and install any mocks needed by startup settings before
the `comfyPage` fixture boots.

Use `test.use({ initialUrl: '/?template=template_id' })` to choose the first
app URL without calling `setup()` again. The fixture clears browser storage
before this navigation. Use `initialLocalStorage` to seed any required values.

Manual backend boots must call `comfyPage.setupSettings({ userId, settings })`
before navigation to apply the same baseline. `ComfyPage.setup()` alone does not
reset backend settings. Use a multi-user backend; separate test runs must not
share worker users on the same backend.

Mock-only cloud tests use their boot helper's settings response instead. Give
each test a fresh response; backend seeds cannot affect a mocked settings read.
Use a stateful mock when testing persistence across reloads.

### Minimal workflows & cleanup

- Load the smallest workflow the test needs (`loadWorkflow('single_ksampler')`),
  not the full default graph.
- Uploaded files and saved workflows are not covered by the settings baseline.
  Keep their cleanup in the owning fixture or `afterEach`:

```typescript
comfyPage.deleteFileAfterTest({ filename: 'image.png' })
```

### Debug helpers (remove before committing)

`comfyPage.debugAddMarker(pos)`, `debugAttachScreenshot(testInfo, name)`,
`debugShowCanvasOverlay()`, `debugGetCanvasDataURL()` are for local debugging
only. Never commit them.

## Replay coverage for agent bug fixes

### Playbook

```bash
DISTRIBUTION=cloud DEV_SERVER_COMFYUI_URL=http://127.0.0.1:8188 pnpm dev
```

```bash
PLAYWRIGHT_LOCAL=1 PLAYWRIGHT_TEST_URL=http://localhost:5173 DISTRIBUTION=cloud pnpm exec playwright test agentConversation --project=cloud
```

Watch one: add `--headed -g <case id>`. Recorded gaps: `AGENT_REPLAY_TIMING=recorded`.

The dev server above is fine for the replay cases, but it cannot run the two
agent cases that assert the panel stays **hidden** while the product flag is off
(`agentPanel.spec.ts` "does not expose the Ask Comfy Agent button" and
`agentPanelLifecycle.spec.ts` "preserves the stored preference while the flag is
off"). `setupFlagGate()` in `src/extensions/core/agentPanel.ts` force-enables the
panel whenever `import.meta.env.MODE === 'development'`, so against `pnpm dev`
both cases see the button and fail no matter what the flag mock says. CI does not
hit this because it serves a built `frontend-dist-cloud` artifact. To run them
locally, serve a production build instead:

```bash
DISTRIBUTION=cloud pnpm build:cloud
# serve dist/ (e.g. ComfyUI --front-end-root <repo>/dist) and point the run at it
PLAYWRIGHT_LOCAL=1 PLAYWRIGHT_TEST_URL=http://127.0.0.1:8188 DISTRIBUTION=cloud \
  pnpm exec playwright test browser_tests/tests/agent/ --project=cloud
```

When a fix changes how the agent's turns affect the app (graph edits,
CRDT frames, panel state), add a conversation replay case alongside the
fix so the bug stays fixed:

1. **Record the conversation.** Reproduce the bug's turn with
   `scripts/agentConversationRecord.ts` against the non-standalone local
   stack (Postgres + doc host). In that mode the agent writes the per-op
   audit rows (`agent_tool_calls` parent and child rows) to Postgres,
   which is what a replay asserts; the doc host is a separate required
   service and writes none of them. That one command records the turn and
   writes the conversation JSON under
   `browser_tests/fixtures/data/agent/conversations/`, marked
   `response_side: 'recorded'`; see `fixtures/data/agent/README.md` for
   the stack recipe, the command and the capture format. Never write
   `graph_ops` by hand and never relabel a synthesized response as recorded.
2. **Add the replay case.** Drive the fixture through the conversation
   replay fixture (`agentConversationFixture`), asserting the
   canvas-observable outcome the bug corrupted (graph end-state or
   panel state - not mock call counts, not model text). Write what a
   user sees for each turn (complete assistant text, tool rows in order)
   into `agentConversationExpectations.ts`; the replay asserts those
   literals and never predicts production rendering.
3. **Prove it bites.** Before merging, run the case once against the
   fix's parent commit (red) and once at the fix (green); paste both
   run lines in the PR description. A replay case that never went red
   against the bug does not count as regression coverage.

Name the case after the behavior it protects (`agent-<behavior-slug>.json`, with the fix PR cited in the fixture's `source.note`). The recorder writes the provenance the replay keeps: `source.capture` (backend, thread id, export time), `turns[].message_id`, and `source.note` (row ids and the raw capture hash). A bad fixture is re-recorded, never edited.

## Test Data & Typed API Mocks

Mock data in `fixtures/data/` exports **typed** objects that conform to
generated types or Zod schemas — never ad-hoc inline JSON. Typing mocks catches
shape drift at compile time instead of through flaky runtime failures.

> `comfyPageFixture` navigates during `setup()`, before the test body. Destructuring
> `{ comfyPage }` in a hook triggers that setup **before the hook body runs**, so a
> `page.route()` placed there misses the first navigation. Register routes **before**
> navigation — from a custom fixture, or a `beforeEach` that takes only `{ page }`
> and registers routes before `comfyPage` is ever set up — to intercept initial
> page-load requests.

```typescript
import { createMockNodeDefinitions } from '@e2e/fixtures/data/nodeDefinitions'

const nodeDefs = createMockNodeDefinitions({ MyCustomNode: {/* ... */} })
await page.route('**/api/object_info', (route) =>
  route.fulfill({ json: nodeDefs })
)
```

### Sources of truth for mock types

The three generated-type packages are auto-generated from OpenAPI specs — prefer
them for any mock targeting their endpoints:

| Endpoint category                                 | Type source                                                                        |
| ------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Cloud-only (hub, billing, workflows)              | `@comfyorg/ingest-types` (`packages/ingest-types`)                                 |
| Registry (releases, nodes, publishers)            | `@comfyorg/registry-types` (`packages/registry-types`)                             |
| Manager (queue tasks, packages)                   | `generatedManagerTypes.ts` (`src/workbench/extensions/manager/types/`)             |
| Local webserver responses that differ from ingest | `src/platform/remote/comfyui/types.ts`                                             |
| WebSocket messages and custom-node outputs        | `src/platform/remote/comfyui/execution/types.ts`                                   |
| Frontend settings                                 | `src/platform/settings/types.ts`                                                   |
| Node definitions                                  | `src/schemas/nodeDefSchema.ts`, `src/schemas/nodeDef/nodeDefSchemaV2.ts`           |
| Templates                                         | `src/platform/workflow/templates/types/template.ts`                                |
| Jobs API                                          | `src/platform/remote/comfyui/jobs/jobTypes.ts` (`zJobDetail`, `zJobsListResponse`) |
| Workflow validation                               | `src/platform/workflow/validation/schemas/workflowSchema.ts`                       |
| Asset metadata                                    | `src/types/metadataTypes.ts`                                                       |

```typescript
// ✅ Import the type and annotate mock data
import type { ReleaseNote } from '@/platform/updates/common/releaseService'
const mockRelease: ReleaseNote = {
  id: 1,
  project: 'comfyui',
  version: 'v0.3.44' /* ... */
}

// ❌ Untyped inline JSON — schema drift goes unnoticed
body: JSON.stringify([{ id: 1, project: 'comfyui', version: 'v0.3.44' }])
```

The example annotates with the app-facing `ReleaseNote` (which the release
service derives from the registry response) to show the pattern. When you mock
the **raw** endpoint response body, annotate with the generated type from the
table above — for releases that is `@comfyorg/registry-types` — so the mock
tracks the API shape directly.

Keep fixture values realistic but stable — avoid dates, random IDs, or anything
that would cause flakiness. When adding a fixture, locate the generated type or
Zod schema first, then create a `.ts` file that satisfies it.

## Flake Prevention

Distilled from the PR 10817 stabilization thread. Reference this section when
triaging or editing flaky tests.

### Quick checklist

Before merging a flaky-test fix, confirm all of these:

- the latest CI artifact was inspected directly
- the root cause is stated as a race or readiness mismatch
- the fix waits on the real readiness boundary
- the assertion primitive matches the job
- the fix stays local unless a shared helper truly owns the race
- local verification uses a targeted rerun

### 1. Start with CI evidence

- Don't trust the top-level GitHub check alone. Inspect the latest Playwright
  `report.json` directly, even on a green run.
- Treat tests marked `flaky` in `report.json` as real work.
- Use `error-context.md`, traces, and page snapshots before editing code.
- Pull the newest run after each push — the flaky set changes.

### 2. Wait for the real readiness boundary

- Visible is not always ready. If behavior depends on internal state, wait on
  that state.
- After canvas interactions, `await comfyPage.nextFrame()` unless the helper
  already guarantees a settled frame.
- After workflow reloads or node-def refreshes, wait for the reload to finish.
- Common boundaries: `node.imgs` populated before image context menus; settings
  cleanup finished before asserting persisted state; locale-triggered reload
  finished before selecting nodes; real builder UI ready (not transient helper
  metadata).

### 3. Choose the smallest correct assertion

- **Locator state** → built-in retrying assertions (`toBeVisible`,
  `toHaveText`, `toHaveCount`, `toHaveClass`).
- **Single async value** → `expect.poll(() => asyncFn()).toBe(expected)`.
- **Multiple assertions that must settle together** → `expect(async () => {
... }).toPass()`.
- Never make immediate assertions right after async UI mutations, settings
  writes, clipboard writes, or graph updates.
- Never use `waitForTimeout()` to hide a race — it is always wrong.

Prefer `expect.poll()` over `toPass()` for a single async call + single
assertion (better error messages). Use the default poll timeout (5000 ms);
never tighten below ~2000 ms.

```typescript
await expect
  .poll(() => comfyPage.settings.getSetting('Comfy.NodeLibrary.Bookmarks.V2'))
  .toEqual([])
```

### 4. Prefer behavioral assertions

Use screenshots only when appearance is the behavior under test. Otherwise
assert on link counts, positions, visible menu items, persisted settings, or
node state.

### 5. Keep helper changes narrow

- Shared helpers should drive setup to a stable boundary.
- Don't encode one-spec timing assumptions into generic helpers — prefer a local
  wait in that spec.
- If a helper fails before the real test begins, relax the brittle precondition
  and let downstream UI interaction prove readiness.

### 6. Verify narrowly

- Targeted reruns via `pnpm test:browser:local`.
- On Windows, prefer `file:line` or whole-spec args over `--grep` (quoting
  issues).
- Use `--repeat-each 5` for targeted flake verification.

### Common flake patterns

| Pattern                               | Bad                                                               | Fix                                                                      |
| ------------------------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------ |
| **Snapshot-then-assert**              | `expect(await evaluate()).toBe(x)`                                | `await expect.poll(() => evaluate()).toBe(x)`                            |
| **Immediate boundingBox/layout read** | `const box = await loc.boundingBox(); expect(box!.width).toBe(w)` | `await expect.poll(() => loc.boundingBox().then(b => b?.width)).toBe(w)` |
| **Immediate graph state after drop**  | `expect(await getLinkCount()).toBe(1)`                            | `await expect.poll(() => getLinkCount()).toBe(1)`                        |
| **Fake readiness helper**             | Helper that clicks but doesn't assert state                       | Remove; poll the actual value                                            |
| **nextFrame after menu click**        | `clickMenuItem(x); nextFrame()`                                   | `clickMenuItem(x); contextMenu.waitForHidden()`                          |
| **Tight poll timeout**                | `expect.poll(..., { timeout: 250 })`                              | ≥2000 ms; prefer default (5000 ms)                                       |
| **Immediate count()**                 | `const n = await loc.count(); expect(n).toBe(3)`                  | `await expect(loc).toHaveCount(3)`                                       |
| **Immediate evaluate after mutation** | `setSetting(); expect(await evaluate()).toBe(x)`                  | `await expect.poll(() => evaluate()).toBe(x)`                            |
| **Screenshot without readiness**      | `loadWorkflow(); nextFrame(); toHaveScreenshot()`                 | Assert the expected node state with a retrying assertion first           |
| **Non-deterministic node order**      | `getNodeRefsByType('X')[0]` with >1 match                         | `getNodeRefById(id)` or guard `toHaveLength(1)`                          |

### Local noise (not automatic CI root causes)

Missing local input fixtures/models, teardown `EPERM` while restoring the local
user-data dir, and local screenshot baseline diffs on Windows are local
distractions. Confirm whether they block the exact flaky path before acting.
Never commit temporary local assets or local screenshot baselines.

## Gotchas

| Symptom                                            | Cause                                       | Fix                                                                                        |
| -------------------------------------------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `subtree intercepts pointer events` on DOM widgets | Canvas `z-999` overlay intercepts `click()` | Use `locator.dispatchEvent('contextmenu', { bubbles: true, cancelable: true, button: 2 })` |
| Context menu empty or wrong items                  | Node not selected                           | Select node first: `vueNodes.selectNode()` or `nodeRef.click('title')`                     |
| `navigateIntoSubgraph` timeout                     | Node too small in test asset JSON           | Use node size `[400, 200]` minimum                                                         |
| Keyboard shortcuts don't work                      | Missing focus                               | `await comfyPage.canvas.click()` first                                                     |
| Widget value wrong after drag-drop                 | Upload incomplete                           | Add `{ waitForUpload: true }`                                                              |

## Screenshot / Visual Regression Testing

Screenshot expectations are **platform-specific** (font rendering). We maintain
**Linux** baselines because CI runs on Linux.

- **Do not commit local screenshot baselines.**
- Prefer functional assertions; use screenshots only when appearance is the
  behavior under test.

- Capture only the area under test with `@e2e/fixtures/utils/screenshotRegion`.
  Spec files may not call `toHaveScreenshot` directly; lint enforces this.

```typescript
import {
  expectElementScreenshot,
  expectRegionScreenshot,
  graphItems,
  screenshotRegion
} from '@e2e/fixtures/utils/screenshotRegion'

// One element's box
await expectElementScreenshot(dialog, 'dialog.png')

// The area enclosing several targets plus padding: locators, node
// references, graph items, page positions, or rectangles
await expectRegionScreenshot(
  comfyPage.page,
  [ksamplerNode, graphItems(comfyPage.page, 'selection')],
  'selection.png',
  { padding: 40, mask: [page.locator('.timestamp')] }
)

// One area measured once and compared before and after an action
const region = await screenshotRegion(comfyPage.page, nodes)
await region.expectScreenshot('before.png')
await doSomething()
await region.expectScreenshot('after.png')
```

### Working with screenshots locally

Skip screenshot tests locally:

```typescript
// playwright.config.ts
export default defineConfig({
  grep: process.env.CI ? undefined : /^(?!.*screenshot).*$/
})
```

`grep` matches the test title and its tags, not the test body — a screenshot
assertion alone won't be detected. Tag every screenshot test
`@screenshot` (or put "screenshot" in its title) for this filter to exclude it.

Or generate local baselines for comparison (do not commit them). If you added
the screenshot-skipping `grep` above, remove it (or override `--grep` for this
run) — otherwise `--update-snapshots` won't regenerate the excluded baselines:

```bash
pnpm test:browser:local --update-snapshots
```

### Creating new baselines in CI

1. Write the test with one of the screenshot assertions above.
2. Add the **`New Browser Test Expectations`** label, comment
   `/update-playwright`, or tick the "Update Playwright expectations"
   checkbox in the Playwright section of the PR report comment.

The workflow waits for the PR's `CI: Tests E2E` run and commits the actual
image of every screenshot assertion that failed there (stale or missing
baseline) without rerunning Playwright. A flaky screenshot that passed on
retry is never committed, and a run with no failed screenshot assertions
commits nothing. The workflow fails and says why when there is no run for
the head commit, the run takes over 45 minutes, a Playwright job did not
finish, no Playwright job ran, or a Playwright job left no
`snapshot-updates-*` artifact (for example after a crash or once the
artifacts expire after 7 days). Push to the branch for a new E2E run and
trigger the update again, or comment `/update-playwright full` to rerun the
`@screenshot` suite with `--update-snapshots`.

A failed screenshot assertion ends its test, so only the first stale
screenshot of each test is committed and the next E2E run fails on the
following one. Comment `/update-playwright full` when a change affects
several screenshots in one test.

Fork PRs can't auto-commit screenshots — a maintainer commits them for you.

### Canvas baselines: pin the viewport instead of re-baselining

If a canvas screenshot diff is only a viewport translation (same image size,
the whole graph shifted), the baseline is not stale: pin the pan/zoom in the
test before the shot rather than regenerating. Regenerate only when the
product changed, and open the diff to confirm the change is the one you made
rather than a viewport shift.

## Debugging in CI

1. Download artifacts from the failed run.
2. View the trace: `pnpm dlx playwright show-trace trace.zip`.
3. CI deploys an HTML report to Cloudflare Pages (link in the PR comment).
4. Reproduce CI locally: `CI=true pnpm test:browser`.

## Test Reports (Cloudflare Pages)

Reports deploy automatically for every PR and push to main branches, one
Cloudflare Pages project per browser configuration
(`comfyui-playwright-chromium`, `-mobile-chrome`, `-chromium-2x`,
`-chromium-0-5x`), with branch-specific URLs
(`https://[branch].comfyui-playwright-[browser].pages.dev`). PR comments carry
✅/❌ status and direct report links per browser.

## New-Test Video Walkthrough

CI re-runs any Playwright spec file newly added in a PR (detected via
`git diff --diff-filter=A` against the base branch) with video recording
enabled and deploys the resulting HTML report — Playwright's report embeds
the video inline per test — to the same `comfyui-playwright-chromium`
Cloudflare Pages project, on its own branch. The link is posted alongside
the other browser report links in the PR comment. It's scoped to added
files only — the existing suite always runs without video — to keep CI cost
and time bounded. Recording is opt-in via `RECORD_VIDEO=true` (set only by
that CI job; see `playwright.config.ts`) and slowed down with `SLOW_MO` so
the result is legible for reviewers. Files containing no tests eligible for
the `chromium` project, such as `@perf`-only specs, are skipped with an
explanation in the workflow summary. Newly added `@audit` tests fail this
job instead because the audit project has no regular CI coverage.

## After Making Changes

- `pnpm typecheck:browser` after modifying TypeScript in this directory.
- `pnpm exec eslint browser_tests/path/to/file.ts` to lint specific files.
- `pnpm exec oxlint browser_tests/path/to/file.ts` for oxlint.

## Resources

- [Playwright Best Practices](https://playwright.dev/docs/best-practices)
- [Playwright UI Mode](https://playwright.dev/docs/test-ui-mode) ·
  [Debugging](https://playwright.dev/docs/debug) ·
  [Auto-retrying assertions](https://playwright.dev/docs/test-assertions#auto-retrying-assertions)
- [act](https://github.com/nektos/act) — run GitHub Actions locally
</content>
