import type {
  BillingCapabilities,
  BillingCapabilitiesResponse
} from '@comfyorg/ingest-types'

import type { WorkspaceWithRole } from '@/platform/workspace/api/workspaceApi'

export function createBillingCapabilities(
  workspaceId: string,
  overrides: Partial<BillingCapabilities> = {}
): BillingCapabilitiesResponse {
  return {
    auto_top_up_enabled: false,
    resolved_for: {
      // The signed-in uid `CloudAuthHelper` mocks. Capabilities resolve per
      // (user, workspace) and the SDK reader checks both halves
      // (`capabilities.ts:180`), discarding an answer resolved for anyone else
      // — so a placeholder here reads as "no capabilities" on the SDK rail.
      user_id: 'test-user-e2e',
      workspace_id: workspaceId
    },
    capabilities: {
      can_cancel: false,
      can_change_seats: false,
      can_downgrade_to_personal: false,
      can_invite_members: false,
      can_manage_members: false,
      can_delete_workspace: false,
      can_leave_workspace: false,
      can_manage_billing: false,
      can_manage_partner_node_access: false,
      can_view_pending_invites: false,
      can_view_team_usage: false,
      can_edit_workspace: false,
      can_manage_auto_top_up: false,
      can_manage_subscription: true,
      can_open_plans: true,
      can_run_workflows: false,
      can_upgrade: false,
      can_reactivate: false,
      can_revert_scheduled_change: false,
      can_subscribe_self_serve: true,
      can_top_up: true,
      ...overrides
    },
    rollout_defaults_applied: {
      can_downgrade_to_personal: false,
      can_subscribe_self_serve: false,
      can_top_up: false
    },
    revision: 1,
    // Far-future expiry so the snapshot never goes stale mid-test.
    expires_at: '2099-01-01T00:00:00Z'
  }
}

/**
 * The capability set the server resolves for `ws`: management actions belong
 * to owners, and downgrade-to-personal only exists on a team workspace.
 *
 * `resolved_for.workspace_id` must match the active workspace or the client
 * discards the read as out-of-scope and falls back to every capability false.
 */
export function createWorkspaceBillingCapabilities(
  ws: WorkspaceWithRole,
  overrides: Partial<BillingCapabilities> = {}
): BillingCapabilitiesResponse {
  const isOwner = ws.role === 'owner'
  return createBillingCapabilities(ws.id, {
    can_cancel: isOwner,
    can_change_seats: isOwner,
    can_downgrade_to_personal: isOwner && ws.type === 'team',
    can_invite_members: isOwner,
    can_manage_members: isOwner,
    can_manage_subscription: isOwner,
    can_open_plans: isOwner,
    can_reactivate: isOwner,
    can_subscribe_self_serve: isOwner,
    can_top_up: isOwner,
    ...overrides
  })
}
