import type {
  BillingBalanceResponse,
  BillingPlansResponse,
  BillingStatusResponse as IngestBillingStatusResponse
} from '@comfyorg/ingest-types'

import type {
  Member,
  Plan,
  WorkspaceWithRole
} from '@/platform/workspace/api/workspaceApi'
import type { RemoteConfig } from '@/platform/remoteConfig/types'

import { createPlan } from '@e2e/fixtures/data/billingPlans'

export const CLOUD_REMOTE_CONFIG: RemoteConfig = {}

export const LEGACY_PERSONAL_BILLING_STATUS = {
  billing_rail: 'legacy_stripe',
  billing_status: 'inactive',
  has_funds: true,
  is_active: false,
  max_seats: 1,
  occupied_seats: 1,
  subscription_status: 'ended',
  subscription_tier: 'FREE',
  team_credit_stop: null,
  scheduled_change: null,
  ended_at: null,
  next_charge: null
} satisfies IngestBillingStatusResponse

export const EMPTY_BILLING_BALANCE = {
  amount_micros: 0,
  currency: 'usd',
  effective_balance_micros: 0
} satisfies BillingBalanceResponse

export const EMPTY_BILLING_PLANS = {
  plans: []
} satisfies BillingPlansResponse

export const TEAM_WORKSPACE: WorkspaceWithRole = {
  id: 'ws-team',
  name: 'Team Comfy',
  type: 'team',
  created_at: '2025-01-01T00:00:00Z',
  joined_at: '2025-01-02T00:00:00Z',
  role: 'owner',
  subscription_tier: 'PRO'
}

export const TEAM_MEMBER_WORKSPACE: WorkspaceWithRole = {
  ...TEAM_WORKSPACE,
  role: 'member'
}

export const CREATOR: Member = {
  id: 'u-liz',
  name: 'Liz',
  email: 'liz@test.comfy.org',
  joined_at: '2025-01-01T00:00:00Z',
  role: 'owner',
  is_original_owner: true
}

// Identity must match the CloudAuthHelper mock user so this row counts as
// "(You)".
export const VIEWER: Member = {
  id: 'u-me',
  name: 'E2E Test User',
  email: 'e2e@test.comfy.org',
  joined_at: '2025-01-02T00:00:00Z',
  role: 'owner',
  is_original_owner: false
}

export const MEMBER_JANE: Member = {
  id: 'u-jane',
  name: 'Jane',
  email: 'jane@test.comfy.org',
  joined_at: '2025-01-03T00:00:00Z',
  role: 'member',
  is_original_owner: false
}

export const MEMBER_JOHN: Member = {
  id: 'u-john',
  name: 'John',
  email: 'john@test.comfy.org',
  joined_at: '2025-01-04T00:00:00Z',
  role: 'member',
  is_original_owner: false
}

export const DEFAULT_TEAM_MEMBERS: Member[] = [
  CREATOR,
  VIEWER,
  MEMBER_JANE,
  MEMBER_JOHN
]

const TEAM_PLAN_SLUG = 'team-pro-monthly'

export const TEAM_BILLING_STATUS = {
  is_active: true,
  subscription_status: 'active',
  subscription_tier: 'PRO',
  subscription_duration: 'MONTHLY',
  plan_slug: TEAM_PLAN_SLUG,
  billing_status: 'paid',
  has_funds: true,
  renewal_date: '2099-02-20T00:00:00Z',
  team_credit_stop: null,
  scheduled_change: null,
  max_seats: 30,
  occupied_seats: DEFAULT_TEAM_MEMBERS.length,
  ended_at: null,
  next_charge: null
} satisfies IngestBillingStatusResponse

export const ENDED_STANDARD_BILLING_STATUS = {
  billing_rail: 'stripe',
  billing_status: 'inactive',
  has_funds: true,
  is_active: false,
  plan_slug: 'standard-monthly',
  subscription_duration: 'MONTHLY',
  subscription_status: 'ended',
  subscription_tier: 'STANDARD',
  ended_at: null,
  next_charge: null,
  team_credit_stop: null,
  scheduled_change: null,
  max_seats: 1,
  occupied_seats: 1
} satisfies IngestBillingStatusResponse & { billing_rail: 'stripe' }

export const INACTIVE_TEAM_BILLING_STATUS = {
  ...TEAM_BILLING_STATUS,
  billing_status: 'inactive',
  is_active: false,
  subscription_status: 'canceled',
  subscription_tier: 'TEAM'
} satisfies IngestBillingStatusResponse

export const TEAM_PRO_PLAN: Plan = createPlan({
  slug: TEAM_PLAN_SLUG,
  tier: 'PRO',
  duration: 'MONTHLY',
  priceCents: 10000,
  monthlyCredits: 21100,
  maxSeats: 30,
  seatCount: 4
})
