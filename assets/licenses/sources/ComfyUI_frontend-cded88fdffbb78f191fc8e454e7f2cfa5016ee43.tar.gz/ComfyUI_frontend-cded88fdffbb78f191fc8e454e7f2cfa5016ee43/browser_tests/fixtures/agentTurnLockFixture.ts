import { expect, mergeTests } from '@playwright/test'
import type { Locator, Page, WebSocketRoute } from '@playwright/test'

import type {
  AgentAnswerAccepted,
  AgentCancelAccepted,
  AgentError,
  AgentMessage,
  AgentPendingAsk,
  AgentThreadListResponse,
  AgentTurnAccepted
} from '@comfyorg/ingest-types'
import {
  zAgentPendingAsk,
  zAgentPostMessageRequest
} from '@comfyorg/ingest-types/zod'
import { escapeRegExp } from 'es-toolkit'
import { z } from 'zod'

import enMessages from '@/locales/en/main.json' with { type: 'json' }
import { TURN_RECOVERY_DELAYS_MS } from '@/workbench/extensions/agent/services/agent/turnRecoverySchedule'
import type {
  AgentWsEvent,
  zTurnInProgressError
} from '@/workbench/extensions/agent/schemas/agentApiSchema'

import { agentTest } from '@e2e/fixtures/agentPanelFixture'
import { workflowSelectionTest } from '@e2e/fixtures/agentWorkflowSelectionFixture'
import { AgentPanel } from '@e2e/fixtures/components/AgentPanel'
import { TestIds } from '@e2e/fixtures/selectors'
import { jsonRoute } from '@e2e/fixtures/utils/jsonRoute'
import { webSocketFixture } from '@e2e/fixtures/ws'

const zAnswerRequest = z.object({ selected: z.array(z.string()) })
const zWireInteger = z.coerce.number().int().safe()

function pendingAskForWire(
  ask: z.infer<typeof zAgentPendingAsk>
): AgentPendingAsk {
  if (ask.kind !== 'run_approval') return ask
  return {
    ...ask,
    context: {
      ...ask.context,
      doc_seq:
        ask.context.doc_seq === undefined
          ? undefined
          : zWireInteger.parse(ask.context.doc_seq)
    }
  }
}

const THREAD_ID = 'b9d0a2a1-0f2c-4f1a-9a5e-6b0f4f2c1d77'
const TURN_ID = '2dd4f367-3399-4cb4-8127-547f531c289a'
const FOREIGN_TURN_ID = 'd3f2b1c0-8a4e-4d6f-9b11-0c7a5e2f4318'
const WORKFLOW_ID = 'a81718a4-02ae-41e6-ae85-000000000001'
const BACKGROUND_THREAD_TITLE = 'Audio workflow'
const OTHER_THREAD_ID = '4ccb6603-4bbc-49e2-8b7d-b985230285e3'
const OTHER_THREAD_TITLE = 'Earlier workflow'

export const TURN_IN_PROGRESS_MESSAGE =
  'a turn is already in progress for this thread'

type TurnInProgressBody = AgentError & z.infer<typeof zTurnInProgressError>

const TURN_IN_PROGRESS: TurnInProgressBody = {
  error: TURN_IN_PROGRESS_MESSAGE,
  type: 'TURN_IN_PROGRESS',
  active_message_id: TURN_ID,
  turn_id: TURN_ID
}

export const TURN_THINKING_TEXT = 'Wiring the audio output node.'
export const LATE_THINKING_TEXT = 'Back online, so I can finish the wiring.'
export const POST_RECONNECT_TEXT = 'Reconnected, and the graph is ready.'
export const PERSISTED_BEFORE_TOOL_TEXT = 'Prepared the graph. '
export const PERSISTED_AFTER_TOOL_TEXT = 'Audio output connected.'

const TURN_THINKING_EVENT: AgentWsEvent = {
  type: 'agent_thinking',
  data: { delta: TURN_THINKING_TEXT, message_id: TURN_ID, thread_id: THREAD_ID }
}

const TURN_TOOL_EVENT: AgentWsEvent = {
  type: 'agent_tool_call',
  data: {
    tool_call_id: 'call-add-node',
    tool_name: 'add_node',
    status: 'success',
    duration_ms: 1300,
    message_id: TURN_ID,
    thread_id: THREAD_ID
  }
}

export const LATE_THINKING_EVENT: AgentWsEvent = {
  type: 'agent_thinking',
  data: { delta: LATE_THINKING_TEXT, message_id: TURN_ID, thread_id: THREAD_ID }
}

export const POST_RECONNECT_EVENT: AgentWsEvent = {
  type: 'agent_message_delta',
  data: {
    delta: POST_RECONNECT_TEXT,
    message_id: TURN_ID,
    thread_id: THREAD_ID
  }
}

export const TURN_DONE_EVENT: AgentWsEvent = {
  type: 'agent_message_done',
  data: { message_id: TURN_ID, thread_id: THREAD_ID }
}

const FOREIGN_TURN_DONE_EVENT: AgentWsEvent = {
  type: 'agent_message_done',
  data: { message_id: FOREIGN_TURN_ID, thread_id: THREAD_ID }
}

const RUN_APPROVAL_ASK_ID = `${TURN_ID}:call-run-workflow`

/**
 * The option ids this ask offers. Declared separately because `AgentWsEvent`
 * types `data` loosely, so reading them back off the event would be an
 * `unknown` the route would have to cast.
 */
const RUN_APPROVAL_OPTION_IDS = ['run', 'cancel'] as const

/**
 * The frame the server sends when a turn parks waiting for the user to approve
 * a run. Shaped after `pendingRunApproval`'s reader and cloud's `asks` writer:
 * the turn does not proceed until an answer posts back, so a client that drops
 * this frame strands the user with no way to answer and no error.
 */
export const RUN_APPROVAL_EVENT: AgentWsEvent = {
  type: 'agent_ask',
  data: {
    message_id: TURN_ID,
    thread_id: THREAD_ID,
    ask_id: RUN_APPROVAL_ASK_ID,
    kind: 'run_approval',
    prompt: 'Run workflow “Unsaved Workflow”?',
    context: { workflow_id: WORKFLOW_ID, workflow_name: 'Unsaved Workflow' },
    options: [
      {
        id: RUN_APPROVAL_OPTION_IDS[0],
        label: enMessages.agent.runApproval.run
      },
      {
        id: RUN_APPROVAL_OPTION_IDS[1],
        label: enMessages.agent.runApproval.cancel
      }
    ],
    min_selections: 1,
    max_selections: 1,
    allow_other: false
  }
}

export const RUN_APPROVAL_RESOLVED_EVENT: AgentWsEvent = {
  type: 'agent_ask_resolved',
  data: {
    message_id: TURN_ID,
    thread_id: THREAD_ID,
    ask_id: RUN_APPROVAL_ASK_ID,
    status: 'answered',
    selected: [RUN_APPROVAL_OPTION_IDS[0]]
  }
}

/**
 * The server's half of a turn, modelled on the real single-active-turn guard:
 * an assistant row goes `streaming` when a turn starts and only leaves that
 * state when the turn completes, fails, or is cancelled. Dropping the client's
 * socket does not touch it — that asymmetry is what these specs exercise.
 *
 * `transcript()` is the REST hydration input the minimize/restore specs read,
 * and this fake keeps its assistant row `streaming` for exactly as long as the
 * turn it simulates. The real server is weaker: a row can outlive the process
 * running it and stay `streaming` with nothing behind it. That orphan is out of
 * scope here, so these specs read a status that always matches the turn.
 *
 * One deliberate infidelity beyond that: the assistant row's `id` is `TURN_ID`,
 * so row id and turn id coincide where the real server mints them separately.
 * That keeps these specs on the turn-lock behaviour they exist for.
 */
interface Deferred {
  promise: Promise<void>
  resolve: () => void
}

function deferred(): Deferred {
  let resolve!: () => void
  const promise = new Promise<void>((settle) => {
    resolve = settle
  })
  return { promise, resolve }
}

class TurnLockServer {
  private streaming = false
  private prompt = ''
  private foreignPrompt: string | undefined
  private rejected = 0
  private posts = 0
  private transcriptReads = 0
  private readonly answered: string[][] = []
  private pendingAsk: z.infer<typeof zAgentPendingAsk> | undefined
  private heldTranscript:
    | {
        threadId?: string
        requested: Promise<void>
        markRequested: () => void
        released: Promise<void>
        release: () => void
      }
    | undefined

  get turnIsStreaming(): boolean {
    return this.streaming
  }

  get rejectedPosts(): number {
    return this.rejected
  }

  /** Every post the server answered, accepted or rejected. */
  get postAttempts(): number {
    return this.posts
  }

  get transcriptReadCount(): number {
    return this.transcriptReads
  }

  countTranscriptRead(): void {
    this.transcriptReads++
  }

  countPost(): void {
    this.posts++
  }

  /** Every ask answer the server accepted, in order, as the selected ids. */
  get answers(): string[][] {
    return this.answered
  }

  get askIsPending(): boolean {
    return this.pendingAsk !== undefined
  }

  recordAnswer(selected: string[]): void {
    this.answered.push(selected)
    this.pendingAsk = undefined
  }

  recordAsk(event: AgentWsEvent): void {
    if (event.type === 'agent_ask')
      this.pendingAsk = zAgentPendingAsk.parse(event.data)
  }

  completeTurn(): void {
    this.streaming = false
    this.foreignPrompt = undefined
  }

  holdNextTranscript(): void {
    const requested = deferred()
    const released = deferred()
    this.heldTranscript = {
      requested: requested.promise,
      markRequested: requested.resolve,
      released: released.promise,
      release: released.resolve
    }
  }

  async waitForHeldTranscript(): Promise<void> {
    await this.heldTranscript?.requested
  }

  releaseHeldTranscript(): void {
    this.heldTranscript?.release()
    this.heldTranscript = undefined
  }

  async waitForTranscriptRelease(threadId: string): Promise<void> {
    const held = this.heldTranscript
    if (held === undefined) return
    if (held.threadId !== undefined && held.threadId !== threadId) return
    held.threadId = threadId
    held.markRequested()
    await held.released
  }

  transcript(threadId = THREAD_ID): AgentMessage[] {
    if (threadId === OTHER_THREAD_ID)
      return [
        {
          id: 'other-user',
          thread_id: OTHER_THREAD_ID,
          turn_id: 'other-turn',
          seq: 1,
          role: 'user',
          status: 'complete',
          workflow_id: WORKFLOW_ID,
          content: { text: 'show my earlier workflow' }
        },
        {
          id: 'other-assistant',
          thread_id: OTHER_THREAD_ID,
          turn_id: 'other-turn',
          seq: 2,
          role: 'assistant',
          status: 'complete',
          workflow_id: WORKFLOW_ID,
          content: { text: 'Here it is.' }
        }
      ]
    const rows: AgentMessage[] = [
      {
        id: 'user-1',
        thread_id: THREAD_ID,
        turn_id: TURN_ID,
        seq: 1,
        role: 'user',
        status: 'complete',
        workflow_id: WORKFLOW_ID,
        content: { text: this.prompt }
      }
    ]
    if (!this.streaming || this.foreignPrompt !== undefined) {
      rows.push(
        {
          id: TURN_ID,
          thread_id: THREAD_ID,
          turn_id: TURN_ID,
          seq: 2,
          role: 'assistant',
          status: 'complete',
          workflow_id: WORKFLOW_ID,
          content: { text: PERSISTED_BEFORE_TOOL_TEXT }
        },
        {
          id: 'tool-row',
          thread_id: THREAD_ID,
          turn_id: TURN_ID,
          seq: 3,
          role: 'assistant',
          status: 'complete',
          workflow_id: WORKFLOW_ID,
          content: {
            tool_calls: [
              {
                id: 'call-add-node',
                tool_call_id: 'call-add-node',
                tool_name: 'add_node',
                status: 'success'
              }
            ],
            thinking: [
              { text: TURN_THINKING_TEXT, tool_call_id: 'call-add-node' },
              { text: LATE_THINKING_TEXT }
            ]
          }
        },
        {
          id: 'final-row',
          thread_id: THREAD_ID,
          turn_id: TURN_ID,
          seq: 4,
          role: 'assistant',
          status: 'complete',
          workflow_id: WORKFLOW_ID,
          content: { text: PERSISTED_AFTER_TOOL_TEXT }
        }
      )
      if (this.foreignPrompt !== undefined)
        rows.push(
          {
            id: 'user-2',
            thread_id: THREAD_ID,
            turn_id: FOREIGN_TURN_ID,
            seq: 5,
            role: 'user',
            status: 'complete',
            workflow_id: WORKFLOW_ID,
            content: { text: this.foreignPrompt }
          },
          {
            id: FOREIGN_TURN_ID,
            thread_id: THREAD_ID,
            turn_id: FOREIGN_TURN_ID,
            seq: 6,
            role: 'assistant',
            status: 'streaming',
            workflow_id: WORKFLOW_ID
          }
        )
      return rows
    }
    rows.push({
      id: TURN_ID,
      thread_id: THREAD_ID,
      turn_id: TURN_ID,
      seq: 2,
      role: 'assistant',
      status: 'streaming',
      workflow_id: WORKFLOW_ID,
      pending_ask:
        this.pendingAsk === undefined
          ? undefined
          : pendingAskForWire(this.pendingAsk)
    })
    return rows
  }

  startTurn(prompt: string): AgentTurnAccepted {
    this.prompt = prompt
    this.streaming = true
    return { message_id: TURN_ID, thread_id: THREAD_ID }
  }

  lockThreadElsewhere(prompt: string): void {
    this.foreignPrompt = prompt
    this.streaming = true
  }

  rejectPost(): TurnInProgressBody {
    this.rejected++
    return this.foreignPrompt === undefined
      ? TURN_IN_PROGRESS
      : {
          ...TURN_IN_PROGRESS,
          active_message_id: FOREIGN_TURN_ID,
          turn_id: FOREIGN_TURN_ID
        }
  }
}

async function routeTurnLock(
  page: Page,
  server: TurnLockServer
): Promise<void> {
  await page.route('**/api/agent/threads?*', (route) =>
    route.fulfill(
      jsonRoute({
        threads: [
          {
            id: THREAD_ID,
            title: BACKGROUND_THREAD_TITLE,
            preview: 'add an audio output node',
            workflow_id: WORKFLOW_ID,
            status: 'active',
            message_count: 2,
            created_at: '2026-09-30T00:00:00Z',
            updated_at: '2026-09-30T00:02:00Z',
            last_message_at: '2026-09-30T00:02:00Z'
          },
          {
            id: OTHER_THREAD_ID,
            title: OTHER_THREAD_TITLE,
            preview: 'show my earlier workflow',
            workflow_id: WORKFLOW_ID,
            status: 'active',
            message_count: 2,
            created_at: '2026-09-29T00:00:00Z',
            updated_at: '2026-09-29T00:02:00Z',
            last_message_at: '2026-09-29T00:02:00Z'
          }
        ],
        pagination: { offset: 0, limit: 100, total: 2, has_more: false }
      } satisfies AgentThreadListResponse)
    )
  )
  await page.route('**/api/agent/threads/*/messages', async (route) => {
    if (route.request().method() === 'GET') {
      const path = new URL(route.request().url()).pathname.split('/')
      const threadId = decodeURIComponent(path.at(-2) ?? '')
      await server.waitForTranscriptRelease(threadId)
      server.countTranscriptRead()
      return route.fulfill(jsonRoute(server.transcript(threadId)))
    }
    server.countPost()
    if (server.turnIsStreaming)
      return route.fulfill({ ...jsonRoute(server.rejectPost()), status: 409 })
    const request = zAgentPostMessageRequest.parse(
      route.request().postDataJSON()
    )
    return route.fulfill({
      ...jsonRoute(server.startTurn(request.content)),
      status: 202
    })
  })

  await page.route('**/api/agent/threads/*/asks/*/answer', (route) => {
    const url = new URL(route.request().url())
    const segments = url.pathname.split('/').map(decodeURIComponent)
    const threadId = segments[segments.indexOf('threads') + 1]
    const askId = segments[segments.indexOf('asks') + 1]
    if (threadId !== THREAD_ID || askId !== RUN_APPROVAL_ASK_ID)
      return route.fulfill({
        status: 404,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'unknown thread or ask' })
      })

    let body: unknown
    try {
      body = route.request().postDataJSON()
    } catch {
      return route.fulfill({ status: 400, body: 'invalid JSON' })
    }
    const parsed = zAnswerRequest.safeParse(body)
    if (!parsed.success)
      return route.fulfill({ status: 400, body: 'invalid answer' })
    const selected = parsed.data.selected
    const offered: readonly string[] = RUN_APPROVAL_OPTION_IDS
    if (selected.length !== 1 || !offered.includes(selected[0]))
      return route.fulfill({
        status: 422,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'selection not offered by this ask' })
      })

    server.recordAnswer(selected)
    const accepted: AgentAnswerAccepted = { status: 'answered', selected }
    return route.fulfill(jsonRoute(accepted))
  })

  await page.route('**/api/agent/threads/*/messages/*/cancel', (route) => {
    server.completeTurn()
    const accepted: AgentCancelAccepted = { status: 'cancelling' }
    return route.fulfill(jsonRoute(accepted))
  })
}

export class AgentTurnLockHarness {
  public readonly panel: Locator
  public readonly composer: Locator
  public readonly sendButton: Locator
  public readonly stopButton: Locator
  public readonly runApprovalButton: Locator
  public readonly workSummary: Locator
  public readonly workingRow: Locator
  public readonly liveProgressRow: Locator
  public readonly userBubbles: Locator
  public readonly turnInProgressNotice: Locator
  public readonly agentPanel: AgentPanel
  private readonly entryButton: Locator
  private readonly dock: Locator

  constructor(
    private readonly page: Page,
    private readonly server: TurnLockServer,
    private readonly finishSave: (success: boolean) => void,
    private readonly savedPaths: () => number,
    private readonly getAgentSocket: () => Promise<WebSocketRoute>,
    private readonly nextAgentSocket: () => Promise<WebSocketRoute>
  ) {
    this.agentPanel = new AgentPanel(page)
    this.panel = this.agentPanel.root
    this.composer = this.panel.getByRole('textbox')
    this.sendButton = this.panel.getByRole('button', {
      name: enMessages.agent.send,
      exact: true
    })
    this.stopButton = this.panel.getByRole('button', {
      name: enMessages.agent.stop,
      exact: true
    })
    this.runApprovalButton = this.panel.getByRole('button', {
      name: enMessages.agent.runApproval.run,
      exact: true
    })
    this.workSummary = this.panel.getByRole('button', {
      name: new RegExp(
        `^(${[
          enMessages.agent.worked,
          enMessages.agent.workedNotConfirmedOnCanvas
        ]
          .map(escapeRegExp)
          .join('|')})$`
      )
    })
    this.workingRow = this.panel.getByText(enMessages.agent.working, {
      exact: true
    })
    // The two status rows a live turn can show in this fixture's scenarios.
    // `working` needs every part settled (AgentMessage.vue's `composing`), so
    // it covers a turn resumed with its tool call intact; `thinking` covers one
    // rebuilt from REST, which has no parts at all because the server stores a
    // live row contentless. Asserting the pair keeps this about whether a live
    // turn is on screen rather than which recovery shape produced it. Visible
    // only, so a collapsed WorkSummary's retained trace cannot match.
    this.liveProgressRow = this.workingRow
      .or(this.panel.getByText(enMessages.agent.thinking, { exact: true }))
      .filter({ visible: true })
      .first()
    this.userBubbles = this.panel.getByTestId('user-message-bubble')
    this.turnInProgressNotice = this.panel.getByText(
      enMessages.agent.sendTurnInProgress,
      { exact: true }
    )
    this.entryButton = this.agentPanel.openButton
    this.dock = page.getByTestId('docked-agent-panel')
  }

  rejectedPosts(): number {
    return this.server.rejectedPosts
  }

  postAttempts(): number {
    return this.server.postAttempts
  }

  async waitForRecoveryExhausted(): Promise<void> {
    const hydrationRead = 1
    await expect
      .poll(() => this.server.transcriptReadCount, { timeout: 90_000 })
      .toBeGreaterThanOrEqual(TURN_RECOVERY_DELAYS_MS.length + hydrationRead)
  }

  /** Opens the panel on a blank workflow and points the composer at that tab. */
  async openOnBlankWorkflow(): Promise<void> {
    await expect(
      this.page.getByTestId(TestIds.topbar.integratedTabBarActions)
    ).toHaveAttribute('data-agent-gate-settled', 'true', { timeout: 15_000 })
    await this.agentPanel.open()
    await this.page
      .getByRole('button', {
        name: enMessages.sideToolbar.newBlankWorkflow,
        exact: true
      })
      .click()
    await expect(this.panel).toBeVisible()
    // Not AgentPanel.selectWorkflow(): it asserts the picker label straight
    // after the menu click, but under this fixture the label only settles once
    // the pending workflow save is released below.
    await this.agentPanel.workflowPicker.click()
    await this.page
      .getByRole('menuitemradio', { name: 'Unsaved Workflow', exact: true })
      .click()
    await expect.poll(() => this.savedPaths()).toBe(1)
    this.finishSave(true)
    await expect(this.agentPanel.workflowPicker).toHaveText('Unsaved Workflow')
  }

  /** Sends a prompt and streams it to the point where a user sees work happening. */
  async startTurn(prompt: string): Promise<void> {
    const live = await this.getAgentSocket()
    await this.composer.fill(prompt)
    await this.sendButton.click()
    // Stop is NOT an ack: Composer renders it from `isSending`, which
    // useAgentSession sets before the POST (and before a prepare() race worth
    // up to PREPARE_TIMEOUT_MS). The user bubble comes from recordUser(), one
    // line above startTurn(), so it is the first signal that activeTurnId is
    // set. Pushing a frame before that point gets it silently dropped by
    // agentConversationStore.ingest, with no retry.
    await expect(this.userBubbles).toHaveText([prompt])
    this.push(live, TURN_THINKING_EVENT)
    await expect(this.panel.getByText(TURN_THINKING_TEXT)).toBeVisible()
    this.push(live, TURN_TOOL_EVENT)
    await expect(this.workingRow).toBeVisible()
  }

  push(ws: WebSocketRoute, event: AgentWsEvent): void {
    ws.send(JSON.stringify(event))
  }

  finishTurn(ws: WebSocketRoute): void {
    this.server.completeTurn()
    this.push(ws, TURN_DONE_EVENT)
  }

  finishForeignTurn(ws: WebSocketRoute): void {
    this.server.completeTurn()
    this.push(ws, FOREIGN_TURN_DONE_EVENT)
  }

  async waitForForeignTurnCancellation(): Promise<void> {
    const request = await this.page.waitForRequest(
      '**/api/agent/threads/*/messages/*/cancel'
    )
    const segments = new URL(request.url()).pathname
      .split('/')
      .map(decodeURIComponent)
    expect(request.method()).toBe('POST')
    expect(segments[segments.indexOf('threads') + 1]).toBe(THREAD_ID)
    expect(segments[segments.indexOf('messages') + 1]).toBe(FOREIGN_TURN_ID)
  }

  finishTurnOnServer(): void {
    this.server.completeTurn()
  }

  lockThreadFromAnotherClient(prompt: string): void {
    this.server.lockThreadElsewhere(prompt)
  }

  /** Makes an ask available through transcript hydration, independently of WS delivery. */
  primePendingAsk(event: AgentWsEvent): void {
    this.server.recordAsk(event)
  }

  /** True only when a test explicitly primed transcript-based recovery. */
  pendingAskIsPrimed(): boolean {
    return this.server.askIsPending
  }

  /**
   * Replays the Web Audio work an audio preview does while a turn is live:
   * open an AudioContext, `decodeAudioData` real WAV bytes, close it. This is
   * the shape of `useWaveAudioPlayer.decodeAudioSource`, not a call into it —
   * the product's `api.fetchApi` step and its waveform pass are not exercised,
   * so this shows Web Audio alone is harmless rather than clearing the whole
   * player.
   */
  async decodeAudioLikeAPreview(): Promise<void> {
    await this.page.evaluate(async () => {
      const frames = 800
      const bytes = new ArrayBuffer(44 + frames * 2)
      const view = new DataView(bytes)
      const ascii = (offset: number, text: string) => {
        for (let i = 0; i < text.length; i++)
          view.setUint8(offset + i, text.charCodeAt(i))
      }
      ascii(0, 'RIFF')
      view.setUint32(4, 36 + frames * 2, true)
      ascii(8, 'WAVEfmt ')
      view.setUint32(16, 16, true)
      view.setUint16(20, 1, true)
      view.setUint16(22, 1, true)
      view.setUint32(24, 8000, true)
      view.setUint32(28, 16000, true)
      view.setUint16(32, 2, true)
      view.setUint16(34, 16, true)
      ascii(36, 'data')
      view.setUint32(40, frames * 2, true)

      const context = new AudioContext()
      await context.decodeAudioData(bytes)
      await context.close()
    })
  }

  /**
   * Minimizes the panel from the topbar Agent button, the control the report
   * used. `DockedAgentPanel.vue` gates the dock on `v-if`, so this unmounts
   * `AgentPanelRoot` and runs its `onBeforeUnmount` — not a visual hide. The
   * page is never reloaded and the shared websocket stays open.
   */
  async minimizePanel(): Promise<void> {
    await this.entryButton.click()
    await expect(this.dock).toHaveCount(0)
  }

  holdNextTranscript(): void {
    this.server.holdNextTranscript()
  }

  async waitForHeldTranscript(): Promise<void> {
    await this.server.waitForHeldTranscript()
  }

  releaseHeldTranscript(): void {
    this.server.releaseHeldTranscript()
  }

  async beginRestorePanel(): Promise<void> {
    await this.entryButton.click()
    await expect(this.panel).toBeVisible()
  }

  /**
   * Restores the panel, then waits out the remount's REST hydration for the
   * one case that can race: a restore over a turn the unmount abandoned. That
   * turn keeps its parts and renders `Worked...`, and hydration replaces it
   * with a contentless row that renders none, so the summary going away is a
   * real settle — it is what lets a caller assert on the restored turn rather
   * than on the abandoned one still on screen. It is a no-op, not a
   * guarantee, when there was no turn to abandon; that case leaves no summary
   * to wait on.
   */
  async restorePanel(): Promise<void> {
    await this.entryButton.click()
    await expect(this.panel).toBeVisible()
    await expect(this.workSummary).toHaveCount(0)
  }

  async selectHistoryThread(title: string): Promise<void> {
    await this.panel
      .getByRole('button', { name: enMessages.agent.showChatHistory })
      .click()
    await this.panel.getByRole('button', { name: title, exact: true }).click()
    await expect(this.panel.getByTestId('user-message-bubble')).toBeVisible()
  }

  /**
   * Every ask the user answered through the panel, flattened to the selected
   * option ids. Reads the fake server rather than the DOM, so it proves the
   * answer actually left the client.
   */
  answeredAsks(): string[] {
    return this.server.answers.flat()
  }

  /** The socket the client is currently on, with no drop. */
  async liveSocket(): Promise<WebSocketRoute> {
    return this.getAgentSocket()
  }

  /** Drops the live socket and resolves with the one the client reconnects on. */
  async dropSocket(): Promise<WebSocketRoute> {
    // Resolve the live route first: with no socket open yet both calls would
    // queue on the same waiter and hand back the same route, so the close
    // below would kill the one returned as the reconnect.
    const live = await this.getAgentSocket()
    const reconnected = this.nextAgentSocket()
    await live.close()
    return reconnected
  }
}

export const agentTurnLockTest = mergeTests(
  agentTest,
  workflowSelectionTest,
  webSocketFixture
).extend<{ turnLock: AgentTurnLockHarness }>({
  turnLock: async (
    { page, workflowSelection, getAgentSocket, nextAgentSocket },
    use
  ) => {
    const server = new TurnLockServer()
    await routeTurnLock(page, server)
    await use(
      new AgentTurnLockHarness(
        page,
        server,
        workflowSelection.finishSave,
        () => workflowSelection.savedPaths.length,
        getAgentSocket,
        nextAgentSocket
      )
    )
  }
})
