import type { Locator, Page, TestInfo } from '@playwright/test'
import { expect } from '@playwright/test'
import type { ApplyOutcome, WorkflowJSON } from '@comfyorg/comfy-multi-player'
import type { ListAssetsResponse } from '@comfyorg/ingest-types'
import { z } from 'zod'

import enMessages from '@/locales/en/main.json' with { type: 'json' }
import type { useWorkflowStore } from '@/platform/workflow/management/stores/workflowStore'
import type { ComfyWorkflowJSON } from '@/platform/workflow/validation/schemas/workflowSchema'
import { validateComfyWorkflow } from '@/platform/workflow/validation/schemas/workflowSchema'
import type { ComfyNodeDef, ObjectInfoResponse } from '@/schemas/nodeDefSchema'
import { toNodeId } from '@/types/nodeId'
import type {
  AgentCancelAccepted,
  AgentMessages,
  AgentWsEvent
} from '@/workbench/extensions/agent/schemas/agentApiSchema'
import { parseAgentWsEvent } from '@/workbench/extensions/agent/schemas/agentApiSchema'
import {
  DOC_PROTOCOL_VERSION,
  parseServerDocFrame
} from '@/workbench/extensions/agent/crdt/docFrameClient'
import type { GraphOperation } from '@/workbench/extensions/agent/crdt/graphOperations'
import type { useAgentWorkflowTabBindingStore } from '@/workbench/extensions/agent/stores/agent/agentWorkflowTabBindingStore'

import {
  agentTest,
  bootAgentApp,
  mockWorkflowPersistence
} from '@e2e/fixtures/agentPanelFixture'
import { ComfyPage } from '@e2e/fixtures/ComfyPage'
import type { HostFrame } from '@e2e/fixtures/agentConversationHostDoc'
import { HostDoc } from '@e2e/fixtures/agentConversationHostDoc'
import { AgentFollowerHostSocket } from '@e2e/fixtures/agentFollowerHostSocket'
import {
  AGENT_FRAME_HANDLED_EVENT,
  announceHandledAgentFrames
} from '@e2e/fixtures/agentSocket'
import { AgentPanel } from '@e2e/fixtures/components/AgentPanel'
import type {
  ClientDocFrame,
  HumanOpsHost
} from '@e2e/fixtures/agentFollowerHostSocket'
import { Topbar } from '@e2e/fixtures/components/Topbar'
import { VueNodeHelpers } from '@e2e/fixtures/VueNodeHelpers'
import { TestIds } from '@e2e/fixtures/selectors'
import type {
  AgentConversation,
  AgentConversationTurn,
  RecordedGraphOperation,
  RecordedWsEvent
} from '@e2e/fixtures/data/agent/agentConversation'
import { loadAgentConversation } from '@e2e/fixtures/data/agent/agentConversation'
import {
  agentHumanAddBlueprint,
  agentNestedSubgraphDefinition
} from '@e2e/fixtures/data/agent/agentHumanAddBlueprints'
import { agentReplayNodeDefs } from '@e2e/fixtures/data/agentReplayNodeDefs'
import type { ExpectedTurn } from '@e2e/fixtures/data/agent/agentConversationExpectations'
import { RECORDED_EXPECTATIONS } from '@e2e/fixtures/data/agent/agentConversationExpectations'
import { mockEmptyAgentThreadList } from '@e2e/fixtures/utils/agentThreadList'
import type { TabSwitchLens, WorkspaceStore } from '@e2e/types/globals'

import { jsonRoute } from '@e2e/fixtures/utils/jsonRoute'
import { AGENT_COMPOSER_LABEL } from '@e2e/fixtures/utils/agentComposerLabel'
import { assertAgentReplayNodeContract } from '@e2e/fixtures/utils/agentReplayNodeContract'
import { mockSavedWorkflowPersistence } from '@e2e/fixtures/utils/savedWorkflowPersistence'
import { loadSeedIntoActiveTab } from '@e2e/fixtures/utils/seedActiveTab'
import { nextFrame } from '@e2e/fixtures/utils/timing'

export const THREAD_ID = 'e9a2f3d1-7c44-4b2e-9a01-5f6d8c7b3a10'
// One synthetic message id per turn; the recorded ids never reach the page.
const turnId = (turn: number): string =>
  `0c5b1e77-2d4a-4f9e-8b63-1a2c3d4e5${turn.toString(16).padStart(3, '0')}`
const VUE_NODES_TAG = '@vue-nodes'
const PANEL_MOUNT_TIMEOUT = 30_000
const CANCEL_TIMEOUT = 10_000

const SEND_LABEL = enMessages.agent.send
const STOP_LABEL = enMessages.agent.stop
// Matches "Worked", "Worked for 3 seconds" and "Worked for 1m 2s" (agent.worked*).
const SUMMARY_LABEL = new RegExp(`^${enMessages.agent.worked}( for .+)?$`)
const FAILED_GLYPH = /lucide--circle-x/
const THINKING_GLYPH = '[class*="lucide--brain"]'

interface RecordedLink {
  fromNode: string
  fromSlot: number
  toNode: string
  toSlot: number
}

interface RecordedWidgetValue {
  nodeId: string
  widget: string
  value: string | number
}

interface RenderedWidgetRow {
  nodeId: string
  label: string
  value: string
  invalid: boolean
}

interface PanelCounts {
  streams: number
  summaries: number
}

// Three views of "which nodes does this tab hold" (the litegraph adapters,
// what serialize() emits, the tracker's captured state) plus the in-page
// observer's record of the rebuilt canvas and every removal since.
export interface NodeLens {
  live: string[]
  serialized: string[]
  activeState: string[]
  observer: TabSwitchLens | null
}

async function attachJson(
  testInfo: TestInfo,
  name: string,
  value: unknown
): Promise<void> {
  await testInfo.attach(name, {
    body: JSON.stringify(value, null, 2),
    contentType: 'application/json'
  })
}

// [id, from, from_slot, to, to_slot, type], as the projection stores a link.
const zProjectedLink = z
  .tuple([
    z.unknown(),
    z.union([z.string(), z.number()]),
    z.number(),
    z.union([z.string(), z.number()]),
    z.number()
  ])
  .rest(z.unknown())

// The projected node fields the canvas assertions read.
const zProjectedNode = z
  .object({
    id: z.union([z.string(), z.number()]),
    type: z.string(),
    title: z.string().optional(),
    inputs: z
      .array(z.object({ widget: z.unknown().optional() }).passthrough())
      .optional()
  })
  .passthrough()

function linkKey(link: RecordedLink): string {
  return `${link.fromNode}:${link.fromSlot}->${link.toNode}:${link.toSlot}`
}

function byLinkKey(a: RecordedLink, b: RecordedLink): number {
  return linkKey(a).localeCompare(linkKey(b))
}

function collapse(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

async function withTimeout(
  promise: Promise<void>,
  ms: number,
  message: string
): Promise<void> {
  let timer: ReturnType<typeof setTimeout> | undefined
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), ms)
  })
  try {
    await Promise.race([promise, timeout])
  } finally {
    clearTimeout(timer)
  }
}

type WorkflowBindingActions = Pick<
  ReturnType<typeof useAgentWorkflowTabBindingStore>,
  'tabPathFor'
>

type WorkflowLookup = Pick<
  ReturnType<typeof useWorkflowStore>,
  'getWorkflowByPath'
>

type WorkflowScopeAction =
  | { kind: 'drop'; workflowId: string }
  | {
      kind: 'restore'
      tabPath: string
      graphId: string
    }

interface DroppedWorkflowScope {
  tabPath: string
  graphId: string
}

type WorkflowTarget = 'saved-via-picker' | 'unsaved-draft'

interface ReplayResponseOptions {
  beforeFirstGraphOps?: () => Promise<void>
  beforeGraphOps?: (ops: readonly RecordedGraphOperation[]) => Promise<void>
  waitForGraphOpsDelivery?: (ops: readonly RecordedGraphOperation[]) => boolean
}

export class AgentConversationHarness {
  readonly panel: Locator
  readonly vueNodes: VueNodeHelpers
  readonly topbar: Topbar
  readonly composer: Locator
  readonly summaries: Locator

  private readonly host: HostDoc
  private readonly hostSocket: AgentFollowerHostSocket
  private readonly streams: Locator
  // Every node id the host has held so far, seed included.
  private readonly seenIds: Set<string>
  private readonly expectations: ExpectedTurn[]
  private postedTurns = 0
  private lastAddGhosted = false
  private readonly displayNames = new Map<string, string>()
  // Resolved when the panel cancels the turn the recording stopped.
  private readonly cancelWaiters = new Map<string, () => void>()
  private savedWorkflow: Awaited<
    ReturnType<typeof mockSavedWorkflowPersistence>
  > | null = null

  constructor(
    private readonly page: Page,
    private readonly comfyPage: ComfyPage,
    readonly conversation: AgentConversation,
    readonly replayTiming: ReplayTiming,
    caseId: string,
    private readonly extraNodeDefs: Record<string, ComfyNodeDef> = {},
    humanOpsHost: HumanOpsHost = 'hold',
    private readonly workflowTarget: WorkflowTarget = 'saved-via-picker'
  ) {
    const { workflow } = conversation
    this.host = new HostDoc(workflow.id, workflow.seed, workflow.catalog)
    this.hostSocket = new AgentFollowerHostSocket(
      page,
      workflow.id,
      this.host,
      humanOpsHost
    )
    this.seenIds = new Set(workflow.seed.nodes.map((node) => String(node.id)))
    const expectations = RECORDED_EXPECTATIONS[caseId]
    const recorded = expectations?.length ?? 0
    if (recorded !== conversation.turns.length)
      throw new Error(
        `agentConversationExpectations.ts records ${recorded} turn(s) for ${caseId}; the recording has ${conversation.turns.length}`
      )
    this.expectations = expectations ?? []
    this.panel = page.locator('#agent-panel-root')
    this.streams = this.panel.getByTestId('markdown-stream')
    this.composer = this.panel.getByRole('textbox', {
      name: AGENT_COMPOSER_LABEL
    })
    this.summaries = this.panel.getByRole('button', { name: SUMMARY_LABEL })
    this.vueNodes = new VueNodeHelpers(page)
    this.topbar = new Topbar(page)
  }

  addedNodeIds(): string[] {
    return this.conversation.turns
      .flatMap((turn) => turn.response)
      .flatMap((entry) => (entry.kind === 'graph_ops' ? entry.ops : []))
      .filter((op) => op.op === 'add_node')
      .map((op) => String(op.node_id))
  }

  async nodesOutsideVisibleCanvas(ids: readonly string[]): Promise<string[]> {
    const viewport = this.page.viewportSize()
    if (!viewport) throw new Error('this assertion needs a sized page')
    const panelBox = await this.panel.boundingBox()
    const visible = {
      right: panelBox ? Math.min(panelBox.x, viewport.width) : viewport.width,
      bottom: viewport.height
    }
    const seen = await Promise.all(
      ids.map(async (id) => {
        const box = await this.vueNodes.getNodeLocator(id).boundingBox()
        const inside =
          box !== null &&
          box.x >= 0 &&
          box.y >= 0 &&
          box.x + box.width <= visible.right &&
          box.y + box.height <= visible.bottom
        return { id, inside }
      })
    )
    return seen
      .filter((node) => !node.inside)
      .map((node) => node.id)
      .sort()
  }

  async boot(
    agentFlag: boolean,
    vueNodes: boolean,
    bootAssets: ListAssetsResponse,
    telemetryEnabled: boolean
  ): Promise<void> {
    await this.mockAgentApi()
    await this.hostSocket.install()
    await announceHandledAgentFrames(this.page)
    const objectInfo = this.page.waitForResponse((response) =>
      new URL(response.url()).pathname.endsWith('/api/object_info')
    )
    await bootAgentApp(this.page, agentFlag, {
      vueNodes,
      features: { enable_telemetry: telemetryEnabled },
      settings: {
        'Comfy.Graph.CanvasInfo': false,
        'Comfy.NodeSearchBoxImpl': 'default',
        'Comfy.NodeSearchBoxImpl.FollowCursor': true
      },
      // Replayed nodes materialize from registered node types; the recordings use
      // core nodes only, so a case needing another node supplies its definition
      // here rather than routing /object_info a second time behind this one.
      objectInfo: { ...agentReplayNodeDefs, ...this.extraNodeDefs },
      assets: bootAssets
    })
    const definitions = (await (await objectInfo).json()) as ObjectInfoResponse
    for (const [type, definition] of Object.entries(definitions))
      this.displayNames.set(type, definition.display_name || definition.name)
    const unregistered = Object.keys(
      this.conversation.workflow.catalog.types
    ).filter((type) => !this.displayNames.has(type))
    if (unregistered.length > 0)
      throw new Error(
        `${this.page.url()} serves no node definitions for ${unregistered.join(', ')}; the replay needs a ComfyUI backend behind the dev server (browser_tests/README.md, "Replay coverage for agent bug fixes")`
      )

    await loadSeedIntoActiveTab(this.page, this.conversation.workflow.seed)
    await new AgentPanel(this.page).open(PANEL_MOUNT_TIMEOUT)
    if (this.workflowTarget === 'saved-via-picker')
      await this.selectWorkflowTarget()
  }

  private async selectWorkflowTarget(name = 'Unsaved Workflow'): Promise<void> {
    await mockWorkflowPersistence(this.page, this.conversation.workflow.id)
    const picker = this.panel.getByRole('button', {
      name: enMessages.agent.switchWorkflow
    })
    await picker.click()
    await this.page.getByRole('menuitemradio', { name, exact: true }).click()
    await expect(picker).toHaveText(name)
  }

  async persistSavedWorkflow(): Promise<void> {
    this.savedWorkflow = await mockSavedWorkflowPersistence(
      this.page,
      this.conversation.workflow.id
    )
  }

  savedWorkflowPath(): string | null {
    const name = this.savedWorkflow?.savedName()
    return name === undefined ? null : `workflows/${name}.json`
  }

  async savedWorkflowContent(): Promise<ComfyWorkflowJSON> {
    const content = this.savedWorkflow?.savedContent()
    if (content === undefined)
      throw new Error('the app has not saved a workflow yet')
    const errors: string[] = []
    const workflow = await validateComfyWorkflow(
      JSON.parse(content) as unknown,
      (error) => errors.push(error)
    )
    if (!workflow)
      throw new Error(
        `the saved workflow is not schema-valid: ${errors.join('; ')}`
      )
    return workflow
  }

  replaceInSavedWorkflow(search: string, replacement: string): void {
    const content = this.savedWorkflow?.savedContent()
    if (!content?.includes(search))
      throw new Error(`the saved workflow does not contain "${search}"`)
    this.savedWorkflow?.corruptSavedContent(
      content.replaceAll(search, replacement)
    )
  }

  refuseHostSubscribes(reason = 'overloaded'): void {
    this.hostSocket.refuseSubscribes(reason)
  }

  async sendPrompt(turn = 0): Promise<void> {
    const { content } = this.conversation.turns[turn].request
    await this.composer.fill(content)
    await this.panel.getByRole('button', { name: SEND_LABEL }).click()
    // Replay frames are dropped until the page has applied the ack's thread id.
    // useAgentSession records the user turn straight after storing that id, so
    // the rendered turn says the ack landed without reading private storage.
    await expect(this.panel.getByText(content).first()).toBeVisible()
  }

  private async waitForRecordedOffset(
    startedAt: number,
    offset: number | undefined
  ): Promise<void> {
    if (this.replayTiming !== 'recorded' || offset === undefined) return

    let remaining = offset - (Date.now() - startedAt)
    // A timer can fire a millisecond early, so wait until the offset has really passed.
    while (remaining > 0) {
      await new Promise((resolve) => setTimeout(resolve, remaining))
      remaining = offset - (Date.now() - startedAt)
    }
  }

  async replayResponse(
    turn = 0,
    options: ReplayResponseOptions = {}
  ): Promise<void> {
    const startedAt = Date.now()
    const response = this.conversation.turns[turn].response
    const firstGraphOps = response.findIndex(
      (entry) => entry.kind === 'graph_ops'
    )
    for (const [index, entry] of response.entries()) {
      await this.waitForRecordedOffset(startedAt, entry.at_ms)
      if (entry.kind === 'event')
        this.hostSocket.send(this.stampTurn(entry.event, turn))
      else {
        await this.hostSocket.waitForSubscribe()
        if (index === firstGraphOps) await options.beforeFirstGraphOps?.()
        await options.beforeGraphOps?.(entry.ops)
        await this.sendHostFrame(
          this.host.apply(entry.ops),
          options.waitForGraphOpsDelivery?.(entry.ops) === true
        )
        for (const id of Object.keys(this.host.graph().nodes))
          this.seenIds.add(id)
      }
      // The recorded turn was stopped here, so the panel stops here too.
      if (index === this.conversation.turns[turn].cancel_after)
        await this.stopTurn(turn)
    }
  }

  // Every turn in order, each judged on the panel and the canvas as it lands.
  async runTurns(options: ReplayResponseOptions = {}): Promise<void> {
    for (const turn of this.conversation.turns.keys()) {
      const before = await this.panelCounts()
      await this.sendPrompt(turn)
      await this.replayResponse(turn, options)
      await this.waitForTurnComplete()
      await this.expectTurnRendered(turn, before)
      await this.expectCanvasReplayed(turn)
    }
  }

  async applyGraphOps(ops: RecordedGraphOperation[]): Promise<void> {
    await this.hostSocket.waitForSubscribe()
    this.hostSocket.send(this.host.apply(ops))
    const addedNodeIds = ops.flatMap((op) =>
      op.op === 'add_node' && op.node_id != null ? [String(op.node_id)] : []
    )
    await expect
      .poll(() =>
        this.page.evaluate((ids) => {
          const graph = window.app!.graph
          const renderedIds = new Set(graph._nodes.map(({ id }) => String(id)))
          return ids.filter((id) => !renderedIds.has(id))
        }, addedNodeIds)
      )
      .toEqual([])
  }

  private async panelCounts(): Promise<PanelCounts> {
    return {
      streams: await this.streams.count(),
      summaries: await this.summaries.count()
    }
  }

  // Everything the recording played through the given turn (all turns by default).
  private entries(throughTurn?: number): AgentConversationTurn['response'] {
    const last = throughTurn === undefined ? undefined : throughTurn + 1
    return this.conversation.turns
      .slice(0, last)
      .flatMap((turn) => turn.response)
  }

  // Clicks Stop, then holds the recorded tail until the panel's cancel for this
  // turn reaches the server: the completed conversation is reachable only
  // through that request.
  private async stopTurn(turn: number): Promise<void> {
    const accepted = new Promise<void>((resolve) =>
      this.cancelWaiters.set(turnId(turn), resolve)
    )
    await this.panel.getByRole('button', { name: STOP_LABEL }).click()
    await withTimeout(
      accepted,
      CANCEL_TIMEOUT,
      'the panel never cancelled the stopped turn'
    )
  }

  async waitForTurnComplete(): Promise<void> {
    await expect(
      this.panel.getByRole('button', { name: SEND_LABEL })
    ).toBeVisible()
    await expect(
      this.panel.getByRole('button', { name: STOP_LABEL })
    ).toHaveCount(0)
  }

  // Last write wins per widget; the rendered control shows only the final value.
  private recordedWidgetValues(throughTurn: number): RecordedWidgetValue[] {
    const graph = this.host.graph()
    const latest = new Map<string, RecordedWidgetValue>()
    for (const entry of this.entries(throughTurn)) {
      if (entry.kind !== 'graph_ops') continue
      for (const op of entry.ops) {
        if (op.op !== 'set_widget' || typeof op.widget !== 'string') continue
        const nodeId = String(op.node_id)
        const widget = op.widget
        const widgets = graph.nodes[nodeId]?.widgets as
          | Record<string, unknown>
          | undefined
        const value = widgets?.[widget]
        if (typeof value === 'string' || typeof value === 'number')
          latest.set(`${nodeId}/${widget}`, { nodeId, widget, value })
      }
    }
    return [...latest.values()]
  }

  // The renderer's link map names the endpoints no DOM surface does; the
  // painted result is a screenshot expectation in the replay spec.
  private async renderedLinks(): Promise<RecordedLink[]> {
    const links = await this.page.evaluate(() =>
      [...window.app!.graph.links.values()].map((link) => ({
        fromNode: String(link.origin_id),
        fromSlot: link.origin_slot,
        toNode: String(link.target_id),
        toSlot: link.target_slot
      }))
    )
    return links.sort(byLinkKey)
  }

  // What this turn put on the panel, against the recording's explicit
  // expectations: the complete assistant text, and the tool call rows in order
  // as a user reads them once the turn's work summary is open.
  private async expectTurnRendered(
    turn: number,
    before: PanelCounts
  ): Promise<void> {
    const expected = this.expectations[turn]
    const apiBase = new URL('/api', this.page.url()).href.replace(/\/+$/, '')
    const text = expected.text.replaceAll('{apiBase}', apiBase)
    await expect
      .poll(async () =>
        collapse(
          (await this.streams.allInnerTexts()).slice(before.streams).join(' ')
        )
      )
      .toBe(text)

    // A finished turn folds its tool calls into one closed summary; the
    // thinking rows it lists between them are not part of the recording.
    const rows = expected.groups.flat()
    await expect(this.summaries).toHaveCount(
      before.summaries + (rows.length > 0 ? 1 : 0)
    )
    if (rows.length === 0) return
    const summary = this.summaries.nth(before.summaries)
    await expect(summary).toHaveAttribute('aria-expanded', 'false')
    await summary.click()
    const items = summary
      .locator('..')
      .getByRole('listitem')
      .filter({ hasNot: this.page.locator(THINKING_GLYPH) })
    await expect(items).toHaveCount(rows.length)
    for (const [at, row] of rows.entries()) {
      const item = items.nth(at)
      await expect(item.getByText(row.label, { exact: true })).toBeVisible()
      const glyph = item.locator('span').first()
      if (row.failed) await expect(glyph).toHaveClass(FAILED_GLYPH)
      else await expect(glyph).not.toHaveClass(FAILED_GLYPH)
      if (row.count > 1) await expect(item).toContainText(`×${row.count}`)
      else await expect(item).not.toContainText('×')
    }
  }

  renderedWidgetRows(): Promise<RenderedWidgetRow[]> {
    return this.page.getByTestId(TestIds.widgets.widget).evaluateAll(
      (rows, labelTestId) =>
        rows.map((row) => {
          const control = row.querySelector('input, textarea')
          return {
            nodeId:
              row.closest('[data-node-id]')?.getAttribute('data-node-id') ?? '',
            label:
              row
                .querySelector(`[data-testid="${labelTestId}"]`)
                ?.textContent.trim() ?? '',
            value:
              control instanceof HTMLInputElement ||
              control instanceof HTMLTextAreaElement
                ? control.value
                : row.textContent.trim(),
            invalid: row.querySelector('[aria-invalid="true"]') !== null
          }
        }),
      TestIds.widgets.layoutFieldLabel
    )
  }

  // What the canvas shows after the given turn, judged the way a user would
  // (which nodes, under which titles, with which widget values, wired on
  // both slot rows) against the workflow the production library projects.
  //
  // `skipTitleCheckForNodeIds` opts specific node ids out of the per-node
  // title assertion below. It exists for callers that deliberately hold a
  // node's live title away from the doc's own projected title (e.g. a known,
  // unfixed "local rename doesn't survive reconcile" repro) — asserting the
  // doc's stale title there would hard-code the very gap under test, and
  // would keep hard-failing even once a real fix makes the live title
  // outlive the reconcile, since this host's projection only reflects
  // replayed ops and has no way to observe that local rename either way.
  // Every other node, and every other caller, keeps the full contract check.
  async expectCanvasReplayed(
    throughTurn: number,
    skipTitleCheckForNodeIds: ReadonlySet<string> = new Set()
  ): Promise<void> {
    const projected = this.host.projection()
    const nodes = projected.nodes.map((node) => zProjectedNode.parse(node))
    const present = new Set(nodes.map((node) => String(node.id)))
    for (const id of this.seenIds)
      if (!present.has(id))
        await expect(this.vueNodes.getNodeLocator(id)).toHaveCount(0)
    for (const node of nodes) {
      const id = String(node.id)
      const locator = this.vueNodes.getNodeLocator(id)
      await expect(locator).toBeVisible()
      const materialized = await this.page.evaluate((nodeId) => {
        const liveNode = window.app?.graph.getNodeById(nodeId)
        return liveNode
          ? { type: liveNode.type, hasErrors: liveNode.has_errors === true }
          : null
      }, toNodeId(id))
      const expectedTitle = assertAgentReplayNodeContract(
        node,
        this.displayNames.get(node.type),
        materialized
      )
      if (!skipTitleCheckForNodeIds.has(id))
        await expect(locator.getByTestId('node-title')).toHaveText(
          expectedTitle
        )
    }
    await expect(this.page.getByTestId('node-title')).toHaveCount(nodes.length)

    for (const { nodeId, widget, value } of this.recordedWidgetValues(
      throughTurn
    )) {
      const field = this.vueNodes
        .getNodeLocator(nodeId)
        .getByLabel(widget, { exact: true })
      if (typeof value === 'number') {
        // Number widgets format their input (0.5 renders as 0.50), so compare the number.
        await expect
          .poll(async () =>
            Number(await field.locator('input').first().inputValue())
          )
          .toBe(value)
        continue
      }
      const tag = await field.evaluate((el) => el.tagName.toLowerCase())
      if (tag === 'button') await expect(field).toContainText(value)
      else await expect(field).toHaveValue(value)
    }

    const links = projected.links
      .map((raw): RecordedLink => {
        const [, fromNode, fromSlot, toNode, toSlot] = zProjectedLink.parse(raw)
        return {
          fromNode: String(fromNode),
          fromSlot,
          toNode: String(toNode),
          toSlot
        }
      })
      .sort(byLinkKey)
    await expect.poll(() => this.renderedLinks()).toEqual(links)
    // A widget-backed input renders no slot row on an uncollapsed node
    // (NodeSlots.vue); the wire above already covers that end.
    for (const link of links) {
      await expect(
        this.vueNodes.getOutputSlotRow(link.fromNode, link.fromSlot)
      ).toHaveClass(/lg-slot--connected/)
      const target = nodes.find((node) => String(node.id) === link.toNode)
      if (target?.inputs?.[link.toSlot]?.widget == null)
        await expect(
          this.vueNodes.getInputSlotRow(link.toNode, link.toSlot)
        ).toHaveClass(/lg-slot--connected/)
    }
  }

  private async mockAgentApi(): Promise<void> {
    const { page } = this
    await mockEmptyAgentThreadList(page)
    await page.route('**/api/agent/threads/*/messages', (route) => {
      const request = route.request()
      if (request.method() === 'POST') {
        this.postedTurns += 1
        return route.fulfill({
          status: 202,
          contentType: 'application/json',
          body: JSON.stringify({
            thread_id: THREAD_ID,
            message_id: turnId(this.postedTurns - 1),
            workflow_id: this.conversation.workflow.id
          })
        })
      }
      const history: AgentMessages = []
      return route.fulfill(jsonRoute(history))
    })
    await page.route('**/api/agent/threads/*/messages/*/cancel', (route) => {
      const target = /\/threads\/([^/]+)\/messages\/([^/]+)\/cancel/.exec(
        route.request().url()
      )
      const release =
        target === null || target[1] !== THREAD_ID
          ? undefined
          : this.cancelWaiters.get(target[2])
      if (release === undefined) return route.fulfill({ status: 404 })
      release()
      const cancelled: AgentCancelAccepted = { status: 'cancelling' }
      return route.fulfill(jsonRoute(cancelled))
    })
    await page.route('**/api/workflows**', (route) =>
      route.fulfill(
        jsonRoute({
          data: [],
          pagination: { has_more: false, limit: 100, offset: 0, total: 0 }
        })
      )
    )
  }

  private stampTurn(event: RecordedWsEvent, turn: number): AgentWsEvent {
    const stamped = {
      type: event.type,
      data: { ...event.data, message_id: turnId(turn), thread_id: THREAD_ID }
    }
    const parsed = parseAgentWsEvent(stamped)
    if (!parsed.success)
      throw new Error(
        `recorded ${event.type} frame is not a valid agent event: ${parsed.error.message}`
      )
    return parsed.data
  }

  /** Every `doc_*` frame the page has sent so far, oldest first. */
  clientDocFrames(): ClientDocFrame[] {
    return this.hostSocket.clientDocFrames()
  }

  async activateEmptyWorkflow(workflowId: string, name: string): Promise<void> {
    const seed = structuredClone(this.conversation.workflow.seed)
    seed.nodes = []
    seed.links = []
    seed.groups = []
    this.hostSocket.addWorkflow(
      workflowId,
      new HostDoc(workflowId, seed, this.conversation.workflow.catalog)
    )
    const subscribes = this.subscribeCount(workflowId)
    this.hostSocket.send({
      type: 'agent_active_tab',
      data: { workflow_id: workflowId, name }
    })
    await expect(this.topbar.getActiveTab()).toContainText(name)
    await expect
      .poll(() => this.subscribeCount(workflowId))
      .toBeGreaterThanOrEqual(subscribes + 1)
  }

  resumeWorkflowSubscribe(workflowId: string): void {
    this.hostSocket.resumeSubscribe(workflowId)
  }

  sendDocumentReset(workflowId: string): void {
    this.hostSocket.send({
      type: 'doc_reset',
      data: {
        v: DOC_PROTOCOL_VERSION,
        workflow_id: workflowId,
        seq: 1,
        lineage_seq: 1,
        actor: 'system:test-reset'
      }
    })
  }

  /** Returns to the recorded workflow's tab (the first) and holds its subscribe ack. */
  async activateRecordedWorkflowBeforeSubscribeAck(): Promise<void> {
    const { id, name } = this.conversation.workflow
    this.hostSocket.pauseSubscribes(id)
    const sent = this.clientDocFrames().filter(
      (frame) => frame.type === 'doc_subscribe' && frame.workflowId === id
    ).length
    this.hostSocket.send({
      type: 'agent_active_tab',
      data: { workflow_id: id, name }
    })
    await expect
      .poll(
        () =>
          this.clientDocFrames().filter(
            (frame) => frame.type === 'doc_subscribe' && frame.workflowId === id
          ).length
      )
      .toBeGreaterThanOrEqual(sent + 1)
    await expect(
      this.topbar.getTab(0).and(this.topbar.getActiveTab())
    ).toBeVisible()
  }

  /** The applier's verdict on every human op the host has judged so far. */
  humanOpOutcomes(): ApplyOutcome[] {
    return this.hostSocket.humanOpOutcomes()
  }

  /** Node ids the host document holds right now. */
  hostNodeIds(): string[] {
    return Object.keys(this.host.graph().nodes)
  }

  /** What the host document holds for one widget; undefined when it has none. */
  hostWidgetValue(nodeId: string, widget: string): unknown {
    const widgets = z
      .record(z.string(), z.unknown())
      .optional()
      .parse(this.host.graph().nodes[nodeId]?.widgets)
    return widgets?.[widget]
  }

  /** How many minted human ops a `hold` host has not judged yet. */
  heldHumanOpCount(): number {
    return this.hostSocket.heldClientOps().length
  }

  /**
   * Releases the oldest batch a `hold` host is sitting on, which is what a
   * page's own edit coming back to it IS: same op ids, and the broadcast
   * carries the client's actor rather than the host's. Holding first and
   * releasing later is therefore a real echo arriving late, not a host write
   * standing in for one - the distinction decides which branch
   * `useAgentCrdtFollower` takes for the frame.
   *
   * Returns the number of ops released, so a caller can tell an echo that
   * landed from one the sender had not flushed yet.
   */
  releaseHeldHumanOps(): number {
    return this.hostSocket.releaseHeldClientOps().length
  }

  // A host-side edit outside the recording, pushed as one `doc_update`. The
  // follower applies frames in order, so a rendered effect of this edit
  // proves every earlier frame (a catch-up included) has been applied too.
  pushHostOps(operations: RecordedGraphOperation[]): HostFrame {
    const frame = this.host.apply(operations)
    this.hostSocket.send(frame)
    for (const id of Object.keys(this.host.graph().nodes)) this.seenIds.add(id)
    return frame
  }

  redeliverHostFrame(frame: HostFrame): void {
    this.hostSocket.send(frame)
  }

  // A host-side delete applied to the document WITHOUT sending a frame: what
  // the host does while this client is not subscribed. The deletion reaches
  // the follower only in the catch-up that answers its next subscribe, which
  // is the whole point of the close/reopen cases.
  deleteNodeOnHost(nodeId: number, removedLinkIds: number[]): void {
    this.host.apply([
      {
        op: 'delete_node',
        node_id: nodeId,
        removed_links: removedLinkIds
      }
    ])
  }

  applyOpsOnHostUnsent(operations: RecordedGraphOperation[]): void {
    this.host.apply(operations)
    for (const id of Object.keys(this.host.graph().nodes)) this.seenIds.add(id)
  }

  /** Holds `threadId`'s transcript reads until `release` is called. */
  async holdTranscript(
    threadId: string
  ): Promise<{ requested: Promise<void>; release: () => void }> {
    let release!: () => void
    let reached!: () => void
    const held = new Promise<void>((resolve) => (release = resolve))
    const requested = new Promise<void>((resolve) => (reached = resolve))
    await this.page.route(
      `**/api/agent/threads/${threadId}/messages`,
      async (route) => {
        if (route.request().method() !== 'GET') return route.fallback()
        reached()
        await held
        return route.fallback()
      }
    )
    return { requested, release }
  }

  /** Serves a second workflow's document beside the recorded one. */
  serveWorkflow(workflowId: string, seed: WorkflowJSON): void {
    this.hostSocket.addWorkflow(
      workflowId,
      new HostDoc(workflowId, seed, this.conversation.workflow.catalog)
    )
  }

  // Rises once per follower subscribe; a tab return re-subscribes and the
  // host answers with the catch-up frame this counter has just sent.
  subscribeCount(workflowId?: string): number {
    return this.hostSocket.subscribeCount(workflowId)
  }

  humanOpFrames(): ClientDocFrame[] {
    return this.clientDocFrames().filter((frame) => frame.type === 'doc_ops')
  }

  async humanAddNodeBaseVersion(
    workflowId: string,
    nodeId: string
  ): Promise<number> {
    const find = () => {
      for (const frame of this.humanOpFrames()) {
        if (frame.workflowId !== workflowId) continue
        const index = frame.ops.indexOf(`add_node:${nodeId}`)
        if (index !== -1) return frame.baseVersions[index]
      }
      return undefined
    }
    await expect.poll(find).toEqual(expect.any(Number))
    const baseVersion = find()
    if (typeof baseVersion !== 'number')
      throw new Error(`no numeric base_version for add_node:${nodeId}`)
    return baseVersion
  }

  leaveNextHumanBatchUnanswered(): void {
    this.hostSocket.leaveHumanBatchesUnanswered(1)
  }

  async disconnectComfySocket(): Promise<void> {
    await this.hostSocket.disconnectComfySocket()
  }

  async disconnectAndApplyRecordedTurn(turn: number): Promise<void> {
    await this.hostSocket.disconnect()
    for (const entry of this.conversation.turns[turn].response) {
      if (entry.kind === 'graph_ops') this.host.apply(entry.ops)
    }
    for (const id of Object.keys(this.host.graph().nodes)) this.seenIds.add(id)
  }

  private graphNodeIds(): Promise<string[]> {
    return this.page.evaluate(() =>
      window.app!.graph.nodes.map((node) => String(node.id))
    )
  }

  // The ordinary add path: the same createNode + graph.add every node type
  // takes, whether the search box, the sidebar or a paste drives it.
  addNodeOfType(type: string, position: [number, number]): Promise<string> {
    return this.page.evaluate(
      ([nodeType, pos]) => {
        const node = window.LiteGraph!.createNode(nodeType)
        if (!node) throw new Error(`${nodeType} is not a registered node type`)
        node.pos = [pos[0], pos[1]]
        window.app!.graph.add(node)
        return String(node.id)
      },
      [type, position] as const
    )
  }

  // The blueprint add path (`addNodeOnGraph` for a `SubgraphBlueprint.*` def):
  // the blueprint's nodes and definitions pasted through `_deserializeItems`.
  addBlueprint(
    promoteText: boolean,
    position: [number, number]
  ): Promise<string> {
    return this.page.evaluate(
      ([bp, pos]) => {
        const items: object = {
          nodes: bp.nodes,
          subgraphs: bp.definitions?.subgraphs
        }
        const results = window.app!.canvas._deserializeItems(items, {
          position: [pos[0], pos[1]]
        })
        const node = results?.nodes.values().next().value
        if (!node) throw new Error('the blueprint paste produced no node')
        return String(node.id)
      },
      [agentHumanAddBlueprint(promoteText), position] as const
    )
  }

  pushNestedDefinition(): void {
    this.hostSocket.send(
      this.host.seedDefinition(agentNestedSubgraphDefinition())
    )
  }

  // A frontend-only node added the way a person actually adds one: the node
  // search box, double-clicked open, typed into, Enter — not a direct
  // LiteGraph.createNode call. The non-Agent baseline
  // (workflowTabSwitchKeepsAddedNodes.spec.ts) covers this path too.
  async addNoteThroughSearchBox(position: {
    x: number
    y: number
  }): Promise<string> {
    const before = new Set(await this.graphNodeIds())
    await this.page.mouse.dblclick(position.x, position.y, { delay: 5 })
    const dialog = this.page.getByRole('search')
    const input = dialog.getByRole('combobox', { name: enMessages.g.addNode })
    await input.waitFor({ state: 'visible' })
    await input.fill('Note')
    const results = dialog.getByTestId(TestIds.searchBoxV2.resultItem)
    await expect(results.first()).toContainText('Note')
    await this.page.keyboard.press('Enter')
    await expect(dialog).toBeHidden()

    this.lastAddGhosted = await this.page.evaluate(() => {
      const app = window.app!
      const ghostNodeId = app.canvas.state.ghostNodeId
      const ghostNode =
        ghostNodeId === null
          ? null
          : app.graph.nodes.find(
              (node) => String(node.id) === String(ghostNodeId)
            )
      return Boolean(ghostNode?.flags.ghost)
    })

    const canvasBounds = await this.comfyPage.canvas.boundingBox()
    if (!canvasBounds) throw new Error('the graph canvas is not visible')
    await this.comfyPage.canvasOps.click({
      x: position.x - canvasBounds.x,
      y: position.y - canvasBounds.y
    })
    const after = await this.graphNodeIds()
    const [added] = after.filter((id) => !before.has(id))
    if (!added) throw new Error('the search box add produced no node')
    return added
  }

  get placementWasGhosted(): boolean {
    return this.lastAddGhosted
  }

  // Records the live node set the moment a tab's canvas finishes rebuilding,
  // and every node the live graph drops afterwards, so a node present after
  // configure() and gone later is distinguishable from one never rebuilt.
  installTabSwitchObserver(): Promise<void> {
    return this.page.evaluate(() => {
      const lens: TabSwitchLens = { afterConfigure: [], removed: [] }
      window.__tabSwitchLens = lens
      const app = window.app!
      app.registerExtension({
        name: 'TabSwitchLens',
        afterConfigureGraph() {
          lens.afterConfigure.push(
            app.graph.nodes.map((node) => String(node.id))
          )
        }
      })
      app.rootGraph.events.addEventListener('node:removed', (event) => {
        lens.removed.push(String(event.detail.node.id))
      })
    })
  }

  readNodeLens(): Promise<NodeLens> {
    return this.page.evaluate(() => {
      const app = window.app!
      const store = app.extensionManager as WorkspaceStore
      return {
        live: app.graph.nodes.map((node) => String(node.id)),
        serialized: app.graph.serialize().nodes.map((node) => String(node.id)),
        activeState:
          store.workflow.activeWorkflow?.changeTracker.activeState.nodes.map(
            (node) => String(node.id)
          ) ?? [],
        observer: window.__tabSwitchLens ?? null
      }
    })
  }

  // A snapshot of every lens this suite judges a tab switch by, attached to
  // the test report under `phase` so a failure's evidence is easy to find.
  async attachEvidence(testInfo: TestInfo, phase: string): Promise<NodeLens> {
    const lens = await this.readNodeLens()
    await attachJson(testInfo, `${phase}-node-lens`, lens)
    await attachJson(testInfo, `${phase}-host-node-ids`, this.hostNodeIds())
    await attachJson(
      testInfo,
      `${phase}-client-doc-frames`,
      this.clientDocFrames()
    )
    await attachJson(
      testInfo,
      `${phase}-human-op-outcomes`,
      this.humanOpOutcomes()
    )
    await testInfo.attach(`${phase}.png`, {
      body: await this.page.screenshot(),
      contentType: 'image/png'
    })
    return lens
  }

  // The page has minted `count` human batches and the host has judged each.
  async waitForHumanOps(count: number): Promise<ApplyOutcome[]> {
    await expect
      .poll(() => this.humanOpOutcomes().length)
      .toBeGreaterThanOrEqual(count)
    return this.humanOpOutcomes()
  }

  // A host edit pushed after everything under test; once it renders, every
  // frame queued ahead of it (a tab-return catch-up, an op echo) has applied.
  async waitForPendingFrames(
    nodeId: string,
    widget: string,
    marker: string
  ): Promise<void> {
    this.pushHostOps([
      { op: 'set_widget', node_id: Number(nodeId), widget, value: marker }
    ])
    await expect(
      this.vueNodes.getNodeLocator(nodeId).getByLabel(widget, { exact: true })
    ).toHaveValue(marker)
  }

  // A recorded tab switch parks the viewport at the origin, hiding node headers above the top edge.
  async fitCanvasToGraph(): Promise<void> {
    await this.page.evaluate(() =>
      window.app!.extensionManager.command.execute('Comfy.Canvas.FitView')
    )
    await nextFrame(this.page)
  }

  async switchAwayAndBack(
    nodeId: string,
    widget: string,
    expectedValue?: string
  ): Promise<void> {
    const tabs = this.topbar.tabs
    await expect(tabs).toHaveCount(1)
    await this.topbar.newWorkflowButton.click()
    await expect(tabs).toHaveCount(2)
    await expect(this.vueNodes.nodes).toHaveCount(0)

    const subscribes = this.subscribeCount()
    await this.topbar.getTab(0).click()
    await expect(
      this.topbar.getTab(0).and(this.topbar.getActiveTab())
    ).toBeVisible()
    await expect.poll(() => this.subscribeCount()).toBe(subscribes + 1)
    if (expectedValue !== undefined)
      await expect(
        this.vueNodes.getNodeLocator(nodeId).getByLabel(widget, { exact: true })
      ).toHaveValue(expectedValue)
    await this.waitForPendingFrames(
      nodeId,
      widget,
      'tab return catch-up landed'
    )
  }

  hostNodePositions(): (number[] | undefined)[] {
    return this.host.projection().nodes.map((node) => node.pos)
  }

  /**
   * The workflow node the host document holds for `nodeId`, as the library
   * projects it — the same snapshot a catch-up, a resubscribe or an agent op
   * that copies an existing node would carry. Undefined when the document has
   * no such node.
   */
  hostNode(nodeId: string): WorkflowJSON['nodes'][number] | undefined {
    return this.host
      .projection()
      .nodes.find((node) => String(node.id) === nodeId)
  }

  async reloadWithoutLocalWorkflow(): Promise<void> {
    await this.page.evaluate(() => {
      for (const storage of [localStorage, sessionStorage]) {
        const workflowKeys = Object.keys(storage).filter((key) =>
          key.startsWith('Comfy.Workflow.')
        )
        for (const key of workflowKeys) storage.removeItem(key)
      }
    })
    await this.page.reload({ waitUntil: 'domcontentloaded' })
    await this.page.waitForFunction(() => window.app?.extensionManager)
    await this.page.getByTestId(TestIds.app.loadingOverlay).waitFor({
      state: 'hidden',
      timeout: PANEL_MOUNT_TIMEOUT
    })
    await expect(this.panel).toBeVisible({ timeout: PANEL_MOUNT_TIMEOUT })
    await this.selectWorkflowTarget()
  }

  // A reload that carries the canvas over the way the app's own persistence
  // does: serialize what is on screen now, reload, then load that graph back
  // into a fresh blank workflow. `reloadWithoutLocalWorkflow` deliberately
  // drops the local workflow; this one deliberately keeps it, so a node that
  // only exists locally is still there for the first reconcile after reload.
  async reloadWithCurrentGraph(): Promise<void> {
    const graph = await this.comfyPage.nodeOps.getSerializedGraph()
    await this.page.reload({ waitUntil: 'domcontentloaded' })
    await this.comfyPage.waitForAppReady()
    await this.comfyPage.workflow.newBlankWorkflow()
    await this.comfyPage.workflow.loadGraphData(graph)
    await expect(this.panel).toBeVisible({ timeout: PANEL_MOUNT_TIMEOUT })
    const name = await this.topbar
      .getActiveTab()
      .locator('.workflow-label')
      .innerText()
    await this.selectWorkflowTarget(name)
  }

  // Sends one more doc_update that resyncs `widget` on `nodeId` to its
  // current doc value — the same effect on a live widget as a stale echo,
  // a reconnect resync, or an unrelated full-graph reconcile has whenever
  // that frame's changed-widgets sweep happens to touch it. Lets a test
  // race this deterministically against a live keystroke instead of
  // waiting on the timing a real run happens to produce.
  async resyncWidget(nodeId: string, widget: string): Promise<void> {
    const value = this.hostWidgetValue(nodeId, widget)
    if (value === undefined)
      throw new Error(`Host widget ${nodeId}.${widget} does not exist`)
    const operation = {
      op: 'set_widget',
      node_id: nodeId,
      widget,
      value,
      old: value
    } satisfies GraphOperation
    const frame = this.host.apply([operation])
    await this.sendHostFrame(frame, true)
  }

  async dropWorkflowScope(): Promise<() => Promise<void>> {
    const workflowId = this.conversation.workflow.id
    const dropped = await this.runWorkflowScopeAction({
      kind: 'drop',
      workflowId
    })
    if (!dropped)
      throw new Error(`no bound tab path for workflow ${workflowId}`)

    let restored = false
    return async () => {
      if (restored) return
      await this.runWorkflowScopeAction({ kind: 'restore', ...dropped })
      restored = true
    }
  }

  async rememberRecoveryGraph(): Promise<void> {
    await this.page.evaluate(() => {
      if (!window.app?.rootGraph) throw new Error('root graph is unavailable')
      window.__agentRecoveryGraph = window.app.rootGraph
    })
  }

  async isRecoveryGraphUnchanged(): Promise<boolean> {
    return await this.page.evaluate(
      () => window.__agentRecoveryGraph === window.app?.rootGraph
    )
  }

  private async runWorkflowScopeAction(
    action: WorkflowScopeAction
  ): Promise<DroppedWorkflowScope | undefined> {
    if (action.kind === 'drop')
      return await this.dropWorkflowScopeInPage(action)
    await this.restoreWorkflowScopeInPage(action)
    return undefined
  }

  private async dropWorkflowScopeInPage(
    action: Extract<WorkflowScopeAction, { kind: 'drop' }>
  ): Promise<DroppedWorkflowScope> {
    return await this.page.evaluate((workflowId) => {
      const isBinding = (value: unknown): value is WorkflowBindingActions =>
        typeof value === 'object' &&
        value !== null &&
        'tabPathFor' in value &&
        typeof value.tabPathFor === 'function'
      const isWorkflowLookup = (value: unknown): value is WorkflowLookup =>
        typeof value === 'object' &&
        value !== null &&
        'getWorkflowByPath' in value &&
        typeof value.getWorkflowByPath === 'function'

      const mount = document.getElementById('vue-app')
      const pinia = mount?.__vue_app__?.config.globalProperties.$pinia
      if (!pinia) throw new Error('Pinia is not mounted')
      const stores = [...pinia._s.values()]
      const binding = stores.find(isBinding)
      const workflows = stores.find(isWorkflowLookup)
      if (!binding)
        throw new Error('agentWorkflowTabBinding store is not mounted')
      if (!workflows) throw new Error('workflow store is not mounted')

      const tabPath = binding.tabPathFor(workflowId)
      if (!tabPath)
        throw new Error(`no bound tab path for workflow ${workflowId}`)
      const tab = workflows.getWorkflowByPath(tabPath)
      if (!tab) throw new Error(`no open tab at ${tabPath}`)
      const graphId = tab.activeState?.id
      if (!graphId) throw new Error(`workflow at ${tabPath} has no graph id`)
      delete tab.activeState?.id
      return { tabPath, graphId }
    }, action.workflowId)
  }

  private async restoreWorkflowScopeInPage(
    action: Extract<WorkflowScopeAction, { kind: 'restore' }>
  ): Promise<void> {
    await this.page.evaluate((action) => {
      const isWorkflowLookup = (value: unknown): value is WorkflowLookup =>
        typeof value === 'object' &&
        value !== null &&
        'getWorkflowByPath' in value &&
        typeof value.getWorkflowByPath === 'function'
      const mount = document.getElementById('vue-app')
      const pinia = mount?.__vue_app__?.config.globalProperties.$pinia
      if (!pinia) throw new Error('Pinia is not mounted')
      const workflows = [...pinia._s.values()].find(isWorkflowLookup)
      if (!workflows) throw new Error('workflow store is not mounted')
      const tab = workflows.getWorkflowByPath(action.tabPath)
      if (!tab) throw new Error(`no open tab at ${action.tabPath}`)
      if (!tab.activeState)
        throw new Error(`workflow at ${action.tabPath} has no active state`)
      tab.activeState.id = action.graphId
    }, action)
  }

  private async sendHostFrame(
    frame: HostFrame,
    waitForDelivery = false
  ): Promise<void> {
    if (!waitForDelivery) {
      this.hostSocket.send(frame)
      return
    }
    const parsedFrame = parseServerDocFrame(frame)
    if (parsedFrame?.type !== 'doc_update')
      throw new Error('Host operation did not produce a doc_update')

    const receipt = crypto.randomUUID()
    await this.page.evaluate(
      ({ receipt, workflowId, seq, handledEvent }) => {
        const attribute = 'data-agent-crdt-update-receipt'
        const cleanupType = `agent-crdt-update-cleanup-${receipt}`
        function removeReceiptListener() {
          document.removeEventListener(handledEvent, recordReceipt)
          document.removeEventListener(cleanupType, removeReceiptListener)
        }
        function isRecord(value: unknown): value is Record<string, unknown> {
          return typeof value === 'object' && value !== null
        }
        function isThisUpdate(detail: unknown): boolean {
          if (typeof detail !== 'string') return false
          const frame: unknown = JSON.parse(detail)
          if (!isRecord(frame) || frame.type !== 'doc_update') return false
          return (
            isRecord(frame.data) &&
            frame.data.workflow_id === workflowId &&
            frame.data.seq === seq
          )
        }
        function recordReceipt(event: Event) {
          if (!(event instanceof CustomEvent) || !isThisUpdate(event.detail))
            return
          document.documentElement.setAttribute(attribute, receipt)
          removeReceiptListener()
        }
        document.addEventListener(handledEvent, recordReceipt)
        document.addEventListener(cleanupType, removeReceiptListener, {
          once: true
        })
      },
      {
        receipt,
        workflowId: parsedFrame.data.workflowId,
        seq: parsedFrame.data.seq,
        handledEvent: AGENT_FRAME_HANDLED_EVENT
      }
    )
    try {
      this.hostSocket.send(frame)
      await expect(this.page.locator('html')).toHaveAttribute(
        'data-agent-crdt-update-receipt',
        receipt
      )
    } finally {
      await this.page.evaluate((receipt) => {
        document.dispatchEvent(
          new CustomEvent(`agent-crdt-update-cleanup-${receipt}`)
        )
        document.documentElement.removeAttribute(
          'data-agent-crdt-update-receipt'
        )
      }, receipt)
    }
  }
}

export type ReplayTiming = 'immediate' | 'recorded'

function defaultReplayTiming(): ReplayTiming {
  const value = process.env.AGENT_REPLAY_TIMING
  if (value === undefined || value === 'immediate') return 'immediate'
  if (value === 'recorded') return 'recorded'
  throw new Error(
    `AGENT_REPLAY_TIMING must be immediate or recorded, got ${value}`
  )
}

interface ConversationFixtures {
  conversationCase: string
  // 'recorded' replays the fixture's at_ms gaps; the default follows AGENT_REPLAY_TIMING.
  replayTiming: ReplayTiming
  // Node definitions this case needs beyond the recorded core subset.
  extraNodeDefs: Record<string, ComfyNodeDef>
  humanOpsHost: HumanOpsHost
  workflowTarget: WorkflowTarget
  // Assets the boot mock serves for every /api/assets query, so combo widgets
  // loaded with the seed already see them.
  bootAssets: ListAssetsResponse
  // Opt in only for cases that assert telemetry through hostTelemetryFixture.
  telemetryEnabled: boolean
  seedPassthrough: Omit<Partial<WorkflowJSON>, 'nodes' | 'links'>
  comfyPage: ComfyPage
  agentConversation: AgentConversationHarness
}

// Wide enough to keep the whole seed graph beside the docked panel; the video follows the viewport instead of Playwright's 800px cap.
const VIEWPORT = { width: 2560, height: 1440 }

export const agentConversationTest = agentTest.extend<ConversationFixtures>({
  conversationCase: ['', { option: true }],
  replayTiming: [defaultReplayTiming(), { option: true }],
  extraNodeDefs: [{}, { option: true }],
  humanOpsHost: ['hold', { option: true }],
  workflowTarget: ['saved-via-picker', { option: true }],
  bootAssets: [{ assets: [], total: 0, has_more: false }, { option: true }],
  telemetryEnabled: [false, { option: true }],
  seedPassthrough: [{}, { option: true }],
  comfyPage: async ({ page, request }, use) => {
    await use(new ComfyPage(page, request))
  },
  viewport: VIEWPORT,
  video: {
    mode:
      process.env.PLAYWRIGHT_LOCAL || process.env.RECORD_VIDEO === 'true'
        ? 'on'
        : 'off',
    size: VIEWPORT
  },
  agentConversation: async (
    {
      page,
      comfyPage,
      agentFlagEnabled,
      conversationCase,
      replayTiming,
      extraNodeDefs,
      humanOpsHost,
      workflowTarget,
      bootAssets,
      telemetryEnabled,
      seedPassthrough
    },
    use,
    testInfo
  ) => {
    if (conversationCase.length === 0)
      throw new Error('test.use({ conversationCase }) names the conversation')
    const vueNodes = testInfo.tags.includes(VUE_NODES_TAG)
    if (!vueNodes)
      throw new Error(
        `a conversation replay is judged on Vue nodes; tag the test ${VUE_NODES_TAG}`
      )
    const conversation = loadAgentConversation(conversationCase)
    conversation.workflow.seed = {
      ...conversation.workflow.seed,
      ...seedPassthrough
    }
    const harness = new AgentConversationHarness(
      page,
      comfyPage,
      conversation,
      replayTiming,
      conversationCase,
      extraNodeDefs,
      humanOpsHost,
      workflowTarget
    )
    await harness.boot(agentFlagEnabled, vueNodes, bootAssets, telemetryEnabled)
    await use(harness)
  }
})
