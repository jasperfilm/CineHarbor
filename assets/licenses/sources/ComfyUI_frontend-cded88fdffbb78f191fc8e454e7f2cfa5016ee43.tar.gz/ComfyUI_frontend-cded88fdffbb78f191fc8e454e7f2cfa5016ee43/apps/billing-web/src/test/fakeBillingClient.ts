/**
 * A `BillingClient` whose readers and commands answer from canned core
 * results. The hosted surfaces only project what the composables expose, so a
 * scripted client is enough here; the composables themselves are covered
 * against a real core in `@comfyorg/account-ui`. Operations a command or a
 * recovery produces are published to lifecycle subscribers the way the real
 * lifecycle would, so a view's projection over them is exercised for real.
 */
import type { Mock } from 'vitest'
import { vi } from 'vitest'

import type {
  BillingCapabilities,
  BillingDeclineReason,
  BillingOperationServerPhase,
  BillingOperationState,
  BillingPlansData,
  BillingResult,
  BillingStatusData,
  BillingStatusSnapshot,
  CancelOperationResult,
  CapabilitiesSnapshot,
  PaymentMethodsSnapshot,
  PaymentPortalResult,
  PendingBillingOperation,
  PlansSnapshot,
  PreviewSubscribeResult,
  SavedPaymentMethod,
  SubscriptionCommandResult,
  SubscriptionPreview,
  TerminalBillingOperation,
  TopupQuoteResult,
  TopupResult,
  WorkspaceInviteCommands
} from '@comfyorg/account-core/billing'
import type { BillingClient } from '@comfyorg/account-ui/billing'

/** Nothing on these surfaces touches the rest of the client. */
function unusedByHostedSurfaces(member: string) {
  return () => {
    throw new Error(`fake billing client: ${member} is never called`)
  }
}

const SCOPE: PlansSnapshot['scope'] = {
  userId: 'uid-1',
  workspaceId: 'ws-1',
  role: 'owner'
}
const READ_AT = 1_700_000_000_000

export interface FakeBillingClientOptions {
  readonly plans?: BillingResult<BillingPlansData>
  readonly paymentMethods?: BillingResult<readonly SavedPaymentMethod[]>
  /** Methods an earlier read left cached, before this page reads its own. */
  readonly cachedPaymentMethods?: readonly SavedPaymentMethod[]
  readonly preview?: PreviewSubscribeResult
  readonly portalUrl?: string
  /** Overrides `portalUrl` when the portal itself should answer with a failure. */
  readonly portal?: PaymentPortalResult
  readonly subscribe?: SubscriptionCommandResult
  readonly cancel?: SubscriptionCommandResult
  readonly resubscribe?: SubscriptionCommandResult
  readonly recover?: BillingResult<BillingOperationState | undefined>
  /** Every capability is denied unless named here. */
  readonly capabilities?: Partial<BillingCapabilities>
  readonly denials?: CapabilitiesSnapshot['denials']
  readonly status?: BillingStatusData
  readonly topupQuote?: TopupQuoteResult
  readonly topup?: TopupResult
  readonly cancelOperation?: CancelOperationResult
}

export interface FakeBillingClient {
  readonly client: BillingClient
  readonly readPlans: () => Promise<BillingResult<PlansSnapshot>>
  readonly readPaymentMethods: Mock<
    () => Promise<BillingResult<PaymentMethodsSnapshot>>
  >
  readonly invalidatePaymentMethods: () => void
  readonly previewSubscribe: Mock<BillingClient['commands']['previewSubscribe']>
  readonly reportChallengeStarted: Mock<
    BillingClient['lifecycle']['reportChallengeStarted']
  >
  readonly reportHostedStepOpened: Mock<
    BillingClient['lifecycle']['reportHostedStepOpened']
  >
  readonly reportChallengeSettled: Mock<
    BillingClient['lifecycle']['reportChallengeSettled']
  >
  readonly openPaymentPortal: BillingClient['commands']['openPaymentPortal']
  /** A mock, so a test can script a sequence of answers for one attempt. */
  readonly subscribe: Mock<BillingClient['commands']['subscribe']>
  readonly cancelSubscription: Mock<
    BillingClient['commands']['cancelSubscription']
  >
  readonly resubscribe: Mock<BillingClient['commands']['resubscribe']>
  readonly cancelOperation: Mock<BillingClient['commands']['cancelOperation']>
  readonly recover: Mock<BillingClient['lifecycle']['recover']>
  readonly quoteTopup: Mock<BillingClient['topup']['quoteTopup']>
  readonly createTopupCheckout: Mock<
    BillingClient['topup']['createTopupCheckout']
  >
  readonly createInteractiveTopup: Mock<
    BillingClient['topup']['createInteractiveTopup']
  >
  readonly readCapabilities: Mock<BillingClient['capabilities']['read']>
  readonly invalidateCapabilities: BillingClient['capabilities']['invalidate']
  readonly readStatus: Mock<BillingClient['status']['read']>
  /** Publishes an operation as the lifecycle would after a poll. */
  readonly publishOperation: (state: BillingOperationState) => void
  readonly invites: {
    readonly listPendingInvites: Mock<
      WorkspaceInviteCommands['listPendingInvites']
    >
    readonly createInvite: Mock<WorkspaceInviteCommands['createInvite']>
  }
}

export function createFakeBillingClient(
  options: FakeBillingClientOptions = {}
): FakeBillingClient {
  const {
    plans = {
      status: 'ok',
      value: { current_plan_slug: undefined, plans: [] }
    },
    paymentMethods = { status: 'ok', value: [] },
    cachedPaymentMethods,
    preview = { status: 'error', code: 'REQUEST_FAILED' },
    portalUrl = 'https://billing.stripe.test/session',
    portal: portalOutcome = { status: 'ok', value: { url: portalUrl } },
    subscribe: subscribeOutcome = { status: 'error', code: 'REQUEST_FAILED' },
    cancel: cancelOutcome = { status: 'error', code: 'REQUEST_FAILED' },
    resubscribe: resubscribeOutcome = {
      status: 'error',
      code: 'REQUEST_FAILED'
    },
    recover: recoverOutcome = { status: 'ok', value: undefined },
    capabilities: granted = {},
    denials = {},
    status = {
      is_active: true,
      has_funds: true,
      max_seats: 1,
      occupied_seats: 1,
      scheduled_change: null,
      team_credit_stop: null
    },
    topupQuote = { status: 'error', code: 'REQUEST_FAILED' },
    topup: topupOutcome = { status: 'error', code: 'REQUEST_FAILED' },
    cancelOperation: cancelOperationOutcome = { status: 'canceled' }
  } = options

  const operations = new Map<string, BillingOperationState>()
  const listeners = new Set<(state: BillingOperationState) => void>()

  function publishOperation(state: BillingOperationState) {
    operations.set(state.id, state)
    for (const listener of listeners) listener(state)
  }

  const readPlans = vi.fn(async () =>
    plans.status === 'ok'
      ? ({
          status: 'ok',
          value: { scope: SCOPE, data: plans.value, readAt: READ_AT }
        } satisfies BillingResult<PlansSnapshot>)
      : plans
  )
  const readPaymentMethods: Mock<
    () => Promise<BillingResult<PaymentMethodsSnapshot>>
  > = vi.fn(async () =>
    paymentMethods.status === 'ok'
      ? ({
          status: 'ok',
          value: {
            scope: SCOPE,
            methods: paymentMethods.value,
            readAt: READ_AT
          }
        } satisfies BillingResult<PaymentMethodsSnapshot>)
      : paymentMethods
  )
  const invalidatePaymentMethods = vi.fn(() => {})
  const reportChallengeStarted: Mock<
    BillingClient['lifecycle']['reportChallengeStarted']
  > = vi.fn()
  const reportHostedStepOpened: Mock<
    BillingClient['lifecycle']['reportHostedStepOpened']
  > = vi.fn()
  const reportChallengeSettled: Mock<
    BillingClient['lifecycle']['reportChallengeSettled']
  > = vi.fn()
  const previewSubscribe = vi.fn(async () => preview)
  const openPaymentPortal = vi.fn(async () => portalOutcome)
  const subscribe = vi.fn(async () => {
    if (subscribeOutcome.status === 'ok' && subscribeOutcome.value.operation) {
      publishOperation(subscribeOutcome.value.operation)
    }
    return subscribeOutcome
  })
  function commandOf(outcome: SubscriptionCommandResult) {
    return vi.fn(async () => {
      if (outcome.status === 'ok' && outcome.value.operation) {
        publishOperation(outcome.value.operation)
      }
      return outcome
    })
  }
  const quoteTopup: Mock<BillingClient['topup']['quoteTopup']> = vi.fn(
    async () => topupQuote
  )
  const createTopupCheckout: Mock<
    BillingClient['topup']['createTopupCheckout']
  > = vi.fn(async () => {
    if ('operation' in topupOutcome) publishOperation(topupOutcome.operation)
    return topupOutcome
  })
  const createInteractiveTopup: Mock<
    BillingClient['topup']['createInteractiveTopup']
  > = vi.fn(async () => {
    if ('operation' in topupOutcome) publishOperation(topupOutcome.operation)
    return topupOutcome
  })
  const cancelSubscription = commandOf(cancelOutcome)
  const cancelOperation: Mock<BillingClient['commands']['cancelOperation']> =
    vi.fn(async () => cancelOperationOutcome)
  const resubscribe = commandOf(resubscribeOutcome)
  const capabilitiesSnapshot: CapabilitiesSnapshot = {
    capabilities: {
      can_cancel: false,
      can_change_seats: false,
      can_downgrade_to_personal: false,
      can_edit_workspace: false,
      can_invite_members: false,
      can_manage_auto_top_up: false,
      can_manage_members: false,
      can_manage_subscription: false,
      can_open_plans: false,
      can_delete_workspace: false,
      can_leave_workspace: false,
      can_manage_billing: false,
      can_manage_partner_node_access: false,
      can_view_pending_invites: false,
      can_view_team_usage: false,
      can_reactivate: false,
      can_revert_scheduled_change: false,
      can_run_workflows: false,
      can_subscribe_self_serve: false,
      can_top_up: false,
      can_upgrade: false,
      ...granted
    },
    denials,
    rolloutDefaultsApplied: {
      can_downgrade_to_personal: false,
      can_subscribe_self_serve: false,
      can_top_up: false
    },
    revision: 1,
    scope: SCOPE,
    freshUntil: READ_AT + 60_000
  }
  const readCapabilities = vi.fn(async () => ({
    status: 'ok' as const,
    value: capabilitiesSnapshot
  }))
  const invalidateCapabilities = vi.fn(() => {})
  const readStatus: Mock<BillingClient['status']['read']> = vi.fn(async () => ({
    status: 'ok' as const,
    value: {
      status,
      scope: SCOPE,
      readAt: READ_AT
    } satisfies BillingStatusSnapshot
  }))
  const recover: Mock<BillingClient['lifecycle']['recover']> = vi.fn(
    async () => {
      if (recoverOutcome.status === 'ok' && recoverOutcome.value) {
        publishOperation(recoverOutcome.value)
      }
      return recoverOutcome
    }
  )

  const client: BillingClient = {
    lifecycle: {
      begin: unusedByHostedSurfaces('lifecycle.begin'),
      recover,
      wake: unusedByHostedSurfaces('lifecycle.wake'),
      switchPresentation: unusedByHostedSurfaces(
        'lifecycle.switchPresentation'
      ),
      reportHostedStepOpened,
      reportChallengeStarted,
      reportChallengeSettled,
      get: (id) => operations.get(id),
      getSnapshot: () => [...operations.values()],
      subscribe: (listener) => {
        listeners.add(listener)
        return () => listeners.delete(listener)
      },
      settled: unusedByHostedSurfaces('lifecycle.settled'),
      dispose: () => {}
    },
    capabilities: {
      read: readCapabilities,
      getSnapshot: () => undefined,
      invalidate: invalidateCapabilities,
      dispose: () => {}
    },
    credits: {
      read: unusedByHostedSurfaces('credits.read'),
      getSnapshot: () => undefined,
      dispose: () => {}
    },
    status: {
      read: readStatus,
      getSnapshot: () => undefined,
      dispose: () => {}
    },
    plans: {
      read: readPlans,
      getSnapshot: () => undefined,
      dispose: () => {}
    },
    paymentMethods: {
      read: readPaymentMethods,
      getSnapshot: () =>
        cachedPaymentMethods && {
          scope: SCOPE,
          methods: cachedPaymentMethods,
          readAt: READ_AT
        },
      invalidate: invalidatePaymentMethods,
      dispose: () => {}
    },
    events: {
      read: unusedByHostedSurfaces('events.read'),
      getSnapshot: () => undefined,
      dispose: () => {}
    },
    topup: {
      quoteTopup,
      createTopupCheckout,
      createInteractiveTopup,
      createHostedTopupCheckout: unusedByHostedSurfaces(
        'topup.createHostedTopupCheckout'
      )
    },
    commands: {
      subscribe,
      previewSubscribe,
      resubscribe,
      cancelSubscription,
      cancelOperation,
      openPaymentPortal
    }
  }

  const invites = {
    listPendingInvites: vi.fn<WorkspaceInviteCommands['listPendingInvites']>(
      async () => ({ status: 'ok', value: [] })
    ),
    createInvite: vi.fn<WorkspaceInviteCommands['createInvite']>(
      async (email) => ({
        status: 'ok',
        value: {
          id: `inv_${email}`,
          email,
          invited_at: '2026-09-27T00:00:00Z',
          expires_at: '2026-10-04T00:00:00Z'
        }
      })
    )
  }

  return {
    client,
    invites,
    readPlans,
    readPaymentMethods,
    invalidatePaymentMethods,
    reportHostedStepOpened,
    reportChallengeStarted,
    reportChallengeSettled,
    previewSubscribe,
    openPaymentPortal,
    subscribe,
    cancelSubscription,
    resubscribe,
    cancelOperation,
    recover,
    quoteTopup,
    createTopupCheckout,
    createInteractiveTopup,
    readCapabilities,
    invalidateCapabilities,
    readStatus,
    publishOperation
  }
}

export function previewOf(
  overrides: Partial<SubscriptionPreview> = {}
): SubscriptionPreview {
  return {
    allowed: true,
    cost_today_cents: 2800,
    cost_next_period_cents: 2800,
    credits_today_cents: 6900,
    credits_next_period_cents: 6900,
    effective_at: '2026-10-01T00:00:00.000Z',
    is_immediate: true,
    transition_type: 'new_subscription',
    new_plan: {
      credits_cents: 6900,
      duration: 'MONTHLY',
      price_cents: 2800,
      seat_summary: {
        seat_count: 1,
        total_cost_cents: 2800,
        total_credits_cents: 6900
      },
      slug: 'creator_monthly',
      tier: 'CREATOR'
    },
    ...overrides
  }
}

export function planOf(
  overrides: Partial<BillingPlansData['plans'][number]> = {}
): BillingPlansData['plans'][number] {
  return {
    action: 'subscribe',
    availability: { available: true },
    credits_cents: 6900n,
    duration: 'MONTHLY',
    max_seats: 1n,
    price_cents: 2800n,
    seat_summary: {
      seat_count: 1,
      total_cost_cents: 2800n,
      total_credits_cents: 6900n
    },
    slug: 'creator_monthly',
    tier: 'CREATOR',
    ...overrides
  }
}

/** The identity every operation the fake publishes shares: this scope, embedded. */
function operationIdentity(id: string) {
  return {
    id,
    kind: 'subscription',
    scope: SCOPE,
    observedAt: READ_AT,
    attemptStartedAt: READ_AT,
    presentation: 'embedded'
  } as const
}

export function succeededOperation(id = 'op_1'): TerminalBillingOperation {
  return { ...operationIdentity(id), phase: 'succeeded' }
}

/** Ended without a verdict: the poll budget ran out, the server parked it, or another replaced it. */
export function unresolvedOperation(
  phase: 'timed_out' | 'reconciliation_needed' | 'superseded',
  id = 'op_1'
): TerminalBillingOperation {
  return { ...operationIdentity(id), phase }
}

/** Pending with no continuation on offer: the lifecycle is still polling it. */
export function pendingOperation(id = 'op_1'): PendingBillingOperation {
  return {
    ...operationIdentity(id),
    phase: 'pending',
    customerActionSeen: false
  }
}

/** Pending in a phase the server reports while it waits on the customer. */
export function serverPhasePendingOperation(
  serverPhase: BillingOperationServerPhase,
  id = 'op_1'
): PendingBillingOperation {
  return {
    ...operationIdentity(id),
    phase: 'pending',
    serverPhase,
    customerActionSeen: false
  }
}

/** Pending with a hosted continuation: the customer has to be sent to it. */
export function hostedPendingOperation(
  actionUrl: string,
  id = 'op_1'
): PendingBillingOperation {
  return {
    id,
    kind: 'subscription',
    scope: SCOPE,
    observedAt: READ_AT,
    attemptStartedAt: READ_AT,
    presentation: 'hosted',
    hostedDestination: 'stripe',
    phase: 'pending',
    actionUrl,
    customerActionSeen: true
  }
}

/** Pending with an in-page challenge this tab has to drive. */
export function challengedPendingOperation(
  clientSecret: string,
  id = 'op_1'
): PendingBillingOperation {
  return {
    ...operationIdentity(id),
    phase: 'pending',
    challenge: { status: 'required', clientSecret },
    customerActionSeen: true
  }
}

export function failedOperation(
  declineReason: BillingDeclineReason,
  id = 'op_1'
): TerminalBillingOperation {
  return {
    ...operationIdentity(id),
    phase: 'failed',
    declineReason,
    retryable: true
  }
}
