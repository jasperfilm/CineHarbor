<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

import { formatQuoteMoney } from '@comfyorg/account-ui/billing/checkout'
import { buttonVariants } from '@comfyorg/design-system/button.variants'
import { cn } from '@comfyorg/tailwind-utils'

import type { ScheduledChange } from '@/checkout/checkoutPage'
import type {
  EndingKind,
  EndingScreen,
  ReceiptRow
} from '@/checkout/endingScreen'
import { endingReceipt } from '@/checkout/endingScreen'
import { longDate } from '@/checkout/longDate'
import { supportLinkWithCode } from '@/checkout/payVerdict'
import type { SuccessBreakdown } from '@/checkout/successBreakdown'
import { namedPlan } from '@/checkout/summaryLedger'
import EndingCodeCard from '@/components/fullPage/EndingCodeCard.vue'
import EndingFrame from '@/components/fullPage/EndingFrame.vue'
import type { EndingPlan } from '@/components/fullPage/EndingPlanCard.vue'
import EndingPlanCard from '@/components/fullPage/EndingPlanCard.vue'
import SuccessCloseFooter from '@/components/fullPage/SuccessCloseFooter.vue'
import { useHostedCopy } from '@/composables/useHostedCopy'
import { reportReturnClicked } from '@/telemetry/webReturnTelemetry'

type Tone = 'done' | 'waiting' | 'refused'

/**
 * How each ending reads. The done family closes back to the product; the
 * waiting family ends on support, since closing changes nothing about money
 * still moving; the refused family offers the one action that can help.
 */
const ENDINGS: Readonly<
  Record<
    EndingKind,
    {
      readonly tone: Tone
      readonly primary?: 'close' | 'retry' | 'view_plans' | 'add_credits'
      readonly support: boolean
      /** This page's own Pay ended here, so the tab can close itself. */
      readonly closeFooter?: true
    }
  >
> = {
  success: {
    tone: 'done',
    primary: 'close',
    support: false,
    closeFooter: true
  },
  scheduled: {
    tone: 'done',
    primary: 'close',
    support: false,
    closeFooter: true
  },
  completed: { tone: 'done', primary: 'close', support: false },
  already_completed: { tone: 'done', primary: 'close', support: false },
  in_progress: { tone: 'waiting', support: true },
  received: { tone: 'waiting', support: true },
  unconfirmed: { tone: 'waiting', support: true },
  refused: { tone: 'refused', support: true },
  plan_unavailable: { tone: 'refused', primary: 'view_plans', support: true },
  link_invalid: { tone: 'refused', primary: 'add_credits', support: true },
  load_failed: { tone: 'refused', primary: 'retry', support: true }
}

const ICON: Readonly<Record<Tone, string>> = {
  done: 'icon-[lucide--circle-check-big] text-success',
  waiting: 'icon-[lucide--clock] text-warning',
  refused: 'icon-[lucide--circle-alert] text-muted-foreground'
}

const {
  screen,
  workspace,
  plan,
  breakdown,
  closesItself = false
} = defineProps<{
  screen: EndingScreen
  workspace: string
  plan?: EndingPlan
  breakdown?: SuccessBreakdown
  closesItself?: boolean
}>()

const emit = defineEmits<{
  close: []
  retry: []
  viewPlans: []
  addCredits: []
}>()

const { t, locale } = useI18n()
const { coded } = useHostedCopy()

const R = 'checkout.fullPage.ending.receipt'
const credits = (count: number) =>
  new Intl.NumberFormat(locale.value).format(count)
const money = (cents: number) => formatQuoteMoney(cents, 'usd', locale.value)

const ending = computed(() => ENDINGS[screen.kind])
const copyKey = computed(() =>
  screen.kind === 'success' && screen.purchase === 'credits'
    ? 'checkout.fullPage.ending.success_credits'
    : `checkout.fullPage.ending.${screen.kind}`
)
/** A top-up's Success leads with the credits the server counted, when it has. */
const title = computed(() => {
  const added =
    screen.kind === 'success' && screen.purchase === 'credits'
      ? screen.receipt?.creditsAdded
      : undefined
  return added === undefined
    ? t(`${copyKey.value}.title`)
    : t(`${copyKey.value}.titleCounted`, { count: credits(added) })
})
const bodyKey = computed(() => {
  if (screen.kind === 'refused') return `${copyKey.value}.body.${screen.copy}`
  if (screen.kind === 'load_failed')
    return `${copyKey.value}.body.${screen.cause}`
  return `${copyKey.value}.body`
})
const planName = (plan: ScheduledChange['plan']) =>
  namedPlan(
    { t, tierName: (tier) => coded('tier', tier) },
    plan,
    plan.duration === 'ANNUAL'
  )
const bodyParams = computed(() => {
  if (screen.kind === 'refused' && screen.copy === 'change_scheduled')
    return {
      workspace,
      plan: planName(screen.scheduled.plan),
      date: longDate(screen.scheduled.effectiveAt, locale.value)
    }
  if (screen.kind === 'scheduled')
    return {
      workspace,
      plan: planName(screen.change.plan),
      date: longDate(screen.change.effectiveAt, locale.value),
      kept: planName(screen.kept)
    }
  return { workspace }
})
/** A refusal the server worded reads in its words. */
const body = computed(
  () =>
    ('serverMessage' in screen ? screen.serverMessage : undefined) ??
    t(bodyKey.value, bodyParams.value)
)
const code = computed(() => ('code' in screen ? screen.code : undefined))
const receipt = computed(() => endingReceipt(screen))
/** A plan card stands in for the reference; without the plan's listing the code stays. */
const planCard = computed(() => (receipt.value.namesPlan ? plan : undefined))
const showsCode = computed(
  () =>
    code.value !== undefined &&
    planCard.value === undefined &&
    !receipt.value.rowsReplaceCode
)
const creditsAdded = computed(() =>
  'receipt' in screen ? screen.receipt?.creditsAdded : undefined
)

/** Each row the receipt shows, as label and value; a plan row needs the plan's name. */
const receiptRows = computed(() =>
  receipt.value.rows.flatMap((row) => {
    const value = rowValue(row)
    return value === undefined
      ? []
      : [{ kind: row.kind, label: t(`${R}.${row.kind}`), value }]
  })
)

function rowValue(row: ReceiptRow): string | undefined {
  switch (row.kind) {
    case 'payment':
    case 'amount_paid':
      return money(row.cents)
    case 'adding':
      return t(`${R}.addingValue`)
    case 'added':
      return t(`${R}.creditCount`, { count: credits(row.credits) })
    case 'plan':
      return plan?.name
  }
}
const supportLink = computed(() => supportLinkWithCode(code.value))
const primary = computed(() => ending.value.primary)

function act() {
  if (primary.value === 'close') {
    reportReturnClicked('success_close')
    emit('close')
  } else if (primary.value === 'retry') emit('retry')
  else if (primary.value === 'view_plans') emit('viewPlans')
  else if (primary.value === 'add_credits') emit('addCredits')
}
</script>

<template>
  <EndingFrame :title :body data-testid="checkout-ending">
    <template #icon>
      <i :class="cn(ICON[ending.tone], 'size-10')" aria-hidden="true" />
    </template>
    <template #note>
      <i18n-t
        v-if="screen.kind === 'in_progress'"
        keypath="checkout.fullPage.ending.in_progress.warning"
        tag="p"
        class="m-0 text-sm/5 text-muted-foreground"
      >
        <template #dontPayAgain>
          <strong class="font-bold">
            {{ t('checkout.fullPage.ending.in_progress.dontPayAgain') }}
          </strong>
        </template>
      </i18n-t>
    </template>

    <EndingPlanCard
      v-if="planCard"
      :plan="planCard"
      :credits-added
      :breakdown
    />

    <dl
      v-if="receiptRows.length > 0"
      class="m-0 flex w-full flex-col gap-2 rounded-lg bg-secondary p-4 text-left text-sm"
      data-testid="checkout-ending-receipt"
    >
      <div
        v-for="row in receiptRows"
        :key="row.kind"
        class="flex items-baseline justify-between gap-4"
      >
        <dt class="text-muted-foreground">{{ row.label }}</dt>
        <dd class="m-0 flex items-center gap-1.5 text-foreground tabular-nums">
          <i
            v-if="row.kind === 'added'"
            class="icon-[lucide--coins] size-4 shrink-0"
            aria-hidden="true"
            data-testid="checkout-ending-credits-icon"
          />
          <span>{{ row.value }}</span>
        </dd>
      </div>
    </dl>

    <EndingCodeCard
      v-if="showsCode && code !== undefined"
      :label="t(`${copyKey}.codeLabel`)"
      :code
    />

    <div class="flex w-full flex-col items-center gap-4">
      <p
        v-if="ending.tone === 'waiting'"
        class="m-0 text-sm/5 text-muted-foreground"
      >
        {{ t('checkout.fullPage.ending.closeLine') }}
      </p>
      <button
        v-if="primary !== undefined"
        type="button"
        :class="
          cn(
            'h-10 w-full cursor-pointer rounded-lg px-4 text-sm font-semibold focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background focus-visible:outline-none',
            primary === 'close'
              ? 'bg-secondary text-foreground hover:bg-accent'
              : 'bg-foreground text-background hover:opacity-90'
          )
        "
        @click="act"
      >
        {{ t(`checkout.fullPage.ending.actions.${primary}`) }}
      </button>
      <SuccessCloseFooter
        v-if="ending.closeFooter"
        :closes-itself
        @close="emit('close')"
      />
      <a
        v-if="ending.support"
        :href="supportLink"
        :class="
          cn(
            buttonVariants({ variant: 'textonly', size: 'lg' }),
            'w-full font-semibold no-underline'
          )
        "
      >
        {{ t('checkout.fullPage.outcome.contactSupport') }}
      </a>
    </div>
  </EndingFrame>
</template>
