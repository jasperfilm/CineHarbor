<script setup lang="ts">
/**
 * Where a hosted payment step sends the customer back. Nothing about the
 * payment travels in the URL: the lifecycle recovers whatever this scope is
 * still waiting on — the server's pending operation first, then the tab's own
 * pointer — and the projection over it is what the page shows. The trip back
 * to the product carries the coarse outcome and the operation id.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute, useRouter } from 'vue-router'

import { isTerminal } from '@comfyorg/account-core/billing'
import {
  CheckoutSteps,
  useBillingClient,
  useCheckout
} from '@comfyorg/account-ui/billing'
import type { BillingOutcome } from '@comfyorg/billing-contract'
import { billingIntentPath } from '@comfyorg/billing-contract'

import HostedSurface from '@/components/HostedSurface.vue'
import { useHostedCopy } from '@/composables/useHostedCopy'
import { awaitBillingWebStripeKey } from '@/config/stripeKey'
import { createDeferredStripeChallengePort } from '@/session/stripeChallengePort'
import { reportReturnedSubscriptionCheckout } from '@/telemetry/subscriptionCheckoutTelemetry'

const { t } = useI18n()
const { coded } = useHostedCopy()
const route = useRoute()
const router = useRouter()
const { lifecycle } = useBillingClient<'lifecycle'>(undefined)

const checkout = useCheckout({
  openUrl: (url) => window.location.assign(url),
  navigationMode: 'redirect',
  // Deferred: reads the key at challenge time, not this setup's snapshot.
  challengePort: createDeferredStripeChallengePort(awaitBillingWebStripeKey)
})

watch(
  () => checkout.operation.value,
  (operation) => {
    if (operation !== undefined && isTerminal(operation))
      reportReturnedSubscriptionCheckout(operation, { ui: 'embedded' })
  }
)

const recovering = ref(true)
const recoveryFailure = ref<string | undefined>()

onMounted(async () => {
  // `recover` reports a refusal rather than throwing, and this page is where a
  // customer lands back from the provider. Swallowing that result would tell
  // someone who may well have paid that no payment exists.
  const recovered = await lifecycle.recover()
  if (recovered.status === 'error') recoveryFailure.value = recovered.code
  recovering.value = false
})

/**
 * A recovered operation carries no `subscribe` input, so the lifecycle's own
 * retry has nothing to resend. The payment form is where a new attempt starts.
 */
function retryPayment() {
  void router.push({
    path: billingIntentPath('checkout'),
    query: route.query
  })
}

const outcome = computed<BillingOutcome>(() => {
  switch (checkout.projection.value.step) {
    case 'success':
      return 'success'
    case 'canceled':
      return 'cancelled'
    default:
      return 'pending'
  }
})

// No confirm form here: an operation in the preview step awaits the server.
const awaitingServer = computed(
  () =>
    checkout.operation.value !== undefined &&
    checkout.projection.value.step === 'preview'
)

const returnResult = computed(() => ({
  result: outcome.value,
  reference: checkout.projection.value.operationId
}))
</script>

<template>
  <HostedSurface :return-result="returnResult">
    <p
      v-if="recovering || awaitingServer"
      class="m-0 text-sm text-muted-foreground"
    >
      {{ t('hosted.result.recovering') }}
    </p>
    <p v-else-if="recoveryFailure" class="m-0 text-sm text-destructive">
      {{ coded('failure', recoveryFailure) }}
    </p>
    <p
      v-else-if="!checkout.operation.value"
      class="m-0 text-sm text-muted-foreground"
    >
      {{ t('hosted.result.none') }}
    </p>
    <CheckoutSteps
      v-else
      :projection="checkout.projection.value"
      root-class="flex flex-col gap-3 rounded-xl border border-border/50 bg-secondary p-6"
      header-class="m-0 text-base font-semibold text-foreground"
      body-class="m-0 text-sm text-muted-foreground"
      reason-class="m-0 text-sm text-destructive"
      safety-class="m-0 text-sm text-muted-foreground"
      actions-class="mt-2 flex gap-2"
      action-class="inline-flex h-11 cursor-pointer items-center justify-center rounded-lg bg-foreground px-5 font-semibold text-background"
      @retry="retryPayment"
      @cancel="checkout.cancel()"
      @continue-verification="checkout.continueVerification()"
    />
  </HostedSurface>
</template>
