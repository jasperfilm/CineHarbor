<script setup lang="ts">
import { useI18n } from 'vue-i18n'

import { cn } from '@comfyorg/tailwind-utils'

import type { OperationPlanLabel } from '@/checkout/operationPlan'
import type { SummaryLedger } from '@/checkout/summaryLedger'
import OperationPlanSummary from '@/components/OperationPlanSummary.vue'
import CheckoutLedger from '@/components/fullPage/summary/CheckoutLedger.vue'

const {
  ledger,
  operationPlan,
  locked = false,
  repricing = false
} = defineProps<{
  ledger?: SummaryLedger
  /** Money in flight this page did not send, summarized by the plan the server reports for it. */
  operationPlan?: { readonly label?: OperationPlanLabel }
  /** Money on its way: the back arrow goes with the rest of the page. */
  locked?: boolean
  /** A promo re-quote is in flight, so the total on screen is not final. */
  repricing?: boolean
}>()

const emit = defineEmits<{ back: [] }>()

const { t } = useI18n()

const SKELETON_BAR = 'block rounded-full bg-muted motion-safe:animate-pulse'
</script>

<template>
  <section
    class="flex justify-center bg-background lg:w-1/2 lg:justify-end"
    :aria-label="t('checkout.fullPage.summary.label')"
    :aria-busy="
      (ledger === undefined && operationPlan === undefined) || repricing
    "
  >
    <div class="flex w-full max-w-lg flex-col px-6 py-12 lg:px-16">
      <div class="relative flex h-5 items-center max-lg:h-10">
        <button
          v-if="!locked"
          type="button"
          :aria-label="t('checkout.back')"
          class="absolute -left-10 flex size-8 cursor-pointer items-center justify-center rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none max-lg:static max-lg:mr-2 max-lg:size-10"
          @click="emit('back')"
        >
          <i class="icon-[lucide--arrow-left] size-4" aria-hidden="true" />
        </button>
        <span
          v-else
          class="mr-2 size-10 shrink-0 lg:hidden"
          aria-hidden="true"
        />
        <i
          class="icon-[comfy--comfy-logo] h-5 w-18 text-brand-yellow"
          role="img"
          :aria-label="t('checkout.fullPage.logo')"
        />
      </div>

      <OperationPlanSummary
        v-if="operationPlan"
        class="mt-16"
        :recovered="operationPlan"
      />
      <CheckoutLedger v-else-if="ledger" :ledger>
        <slot :ledger />
      </CheckoutLedger>
      <template v-else>
        <div class="mt-16 flex flex-col gap-3">
          <span class="sr-only">{{ t('hosted.loading') }}</span>
          <span :class="cn(SKELETON_BAR, 'h-3 w-2/3')" />
          <span :class="cn(SKELETON_BAR, 'h-4 w-2/3')" />
        </div>
        <div class="mt-8 flex items-center justify-between gap-4 border-t pt-6">
          <span class="text-base font-semibold text-foreground">
            {{ t('checkout.totalDueToday') }}
          </span>
          <span :class="cn(SKELETON_BAR, 'h-3 w-16')" />
        </div>
      </template>
    </div>
  </section>
</template>
