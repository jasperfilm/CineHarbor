/**
 * billing-web on the shared web session: identity comes from ingest's
 * session cookie, and the workspace from `GET /workspaces/current` under the
 * entry's workspace header. This origin's own Firebase is touched only once
 * the session has answered that there is none, to restore or sign in.
 */
import type { CurrentWorkspaceResponse } from '@comfyorg/ingest-types'
import {
  zCurrentWorkspaceResponse,
  zErrorResponse
} from '@comfyorg/ingest-types/zod'
import type { User } from 'firebase/auth'
import { computed, shallowRef, watch } from 'vue'

import type {
  BillingScope,
  BillingScopeSource,
  CredentialedWebSession
} from '@comfyorg/account-core/billing'
import type { FirebaseIdentity } from '@comfyorg/account-core/firebase'
import { createRequestAuthorizer } from '@comfyorg/account-core/requestAuth'
import { webSessionTelemetryHooks } from '@comfyorg/account-core/telemetry'
import type { SessionErrorCode } from '@comfyorg/account-core/session'
import type {
  WebSession,
  WebSessionFailure,
  WebSessionOptions
} from '@comfyorg/account-core/webSession'
import {
  createWebSession,
  readWebSession
} from '@comfyorg/account-core/webSession'
import type { WebSessionIdentityState } from '@comfyorg/account-core/webSessionIdentity'
import { createWebSessionIdentity } from '@comfyorg/account-core/webSessionIdentity'

import type {
  SessionEstablishment,
  SessionRefusal,
  SignInPort
} from '@/auth/useSignInController'
import type { BillingWebSessionPhase } from '@/router'
import { billingWebTelemetry } from '@/telemetry/billingWebTelemetry'

export interface UnifiedBillingSessionDeps {
  /** Ingest API root, e.g. `https://cloud.comfy.org/api`. */
  readonly apiBaseUrl: string
  readonly fetchImpl: typeof fetch
  readonly loadFirebase: () => Promise<FirebaseIdentity | undefined>
  /** The entry-bound workspace, read live; absent means personal. */
  readonly workspaceId: () => string | undefined
}

type WorkspaceResolution =
  | { readonly status: 'ok'; readonly workspace: CurrentWorkspaceResponse }
  | { readonly status: 'error'; readonly code: SessionErrorCode }

const REFUSALS: Readonly<Partial<Record<string, SessionErrorCode>>> = {
  workspace_access_denied: 'ACCESS_DENIED',
  workspace_id_invalid: 'WORKSPACE_NOT_FOUND'
}

async function refusalCode(response: Response): Promise<SessionErrorCode> {
  if (response.status === 401) return 'NOT_AUTHENTICATED'
  const body = zErrorResponse.safeParse(await response.json().catch(() => 0))
  return (body.success && REFUSALS[body.data.code]) || 'TOKEN_EXCHANGE_FAILED'
}

function establishmentOf(
  resolution: WorkspaceResolution
): SessionEstablishment {
  return resolution.status === 'ok'
    ? { status: 'ok' }
    : { status: 'error', code: resolution.code }
}

/**
 * A refused credential and an account its SSO organization holds are their own
 * codes; every other failure to create the session is one bucket, as in the
 * token exchange.
 */
function creationRefusal(failure: WebSessionFailure): SessionRefusal {
  if (failure.code === 'SSO_REQUIRED') {
    return failure.organizationId === undefined
      ? { code: 'SSO_REQUIRED' }
      : { code: 'SSO_REQUIRED', organizationId: failure.organizationId }
  }
  return {
    code:
      failure.httpStatus === 401
        ? 'INVALID_FIREBASE_TOKEN'
        : 'TOKEN_EXCHANGE_FAILED'
  }
}

function restoredUser(identity: FirebaseIdentity): Promise<User | null> {
  return new Promise((resolve) => {
    const stop = identity.onUserChanged((user) => {
      resolve(user)
      queueMicrotask(() => stop())
    })
  })
}

export function createUnifiedBillingSession(deps: UnifiedBillingSessionDeps) {
  let sessionLive = false
  const session: WebSessionOptions = {
    apiBaseUrl: deps.apiBaseUrl,
    fetchImpl: async (input, init) => {
      const response = await deps.fetchImpl(input, init)
      if (init?.method === 'GET') sessionLive = response.ok
      return response
    }
  }
  const firebaseUser = async () => {
    const identity = await deps.loadFirebase()
    return identity ? restoredUser(identity) : null
  }
  const identity = createWebSessionIdentity({
    session,
    origin: globalThis.location.origin,
    principal: {
      kind: 'account',
      rememberedLogin: {
        currentUserId: async () =>
          sessionLive ? null : ((await firebaseUser())?.uid ?? null),
        getProof: async () =>
          (await (await firebaseUser())?.getIdToken()) ?? null,
        signOutLocally: async () => (await deps.loadFirebase())?.signOut()
      }
    },
    ...webSessionTelemetryHooks(billingWebTelemetry.trackWebSessionEvent)
  })
  const authorize = createRequestAuthorizer({
    getWorkspaceToken: () =>
      Promise.reject(new Error('billing-web never mints a workspace token'))
  })

  const state = shallowRef<WebSessionIdentityState>(identity.getState())
  const workspace = shallowRef<WorkspaceResolution>()
  /** Why the last attempt to create a session was refused, until one holds. */
  const creationFailure = shallowRef<SessionRefusal>()
  let resolvedBinding: string | undefined
  let resolving: Promise<WorkspaceResolution> | undefined

  async function fetchWorkspace(
    current: WebSession,
    binding: string | undefined
  ): Promise<WorkspaceResolution> {
    try {
      const auth = await authorize(
        { kind: 'session', session: current },
        { target: 'ingest', method: 'GET', workspaceId: binding }
      )
      const response = await deps.fetchImpl(
        `${deps.apiBaseUrl}/workspaces/current`,
        { ...auth, cache: 'no-store' }
      )
      if (!response.ok) {
        return { status: 'error', code: await refusalCode(response) }
      }
      const parsed = zCurrentWorkspaceResponse.safeParse(await response.json())
      return parsed.success
        ? { status: 'ok', workspace: parsed.data }
        : { status: 'error', code: 'TOKEN_EXCHANGE_FAILED' }
    } catch {
      return { status: 'error', code: 'TOKEN_EXCHANGE_FAILED' }
    }
  }

  /** One GET on the session cookie; undefined while signed out. */
  async function sessionGet(
    url: string,
    init: RequestInit
  ): Promise<Response | undefined> {
    const current = state.value
    if (current.phase !== 'signed_in') return undefined
    const auth = await authorize(
      { kind: 'session', session: current.session },
      { target: 'ingest', method: 'GET' }
    )
    return deps.fetchImpl(url, { ...init, ...auth })
  }

  function resolveWorkspace(): Promise<WorkspaceResolution> {
    const current = state.value
    if (current.phase !== 'signed_in') {
      return Promise.resolve({ status: 'error', code: 'NOT_AUTHENTICATED' })
    }
    const binding = deps.workspaceId()
    if (binding !== resolvedBinding) workspace.value = undefined
    const outcome: Promise<WorkspaceResolution> = fetchWorkspace(
      current.session,
      binding
    ).then((result) => {
      if (resolving !== outcome) return resolving ?? result
      if (state.value !== current) {
        return { status: 'error', code: 'NOT_AUTHENTICATED' }
      }
      workspace.value = result
      resolvedBinding = binding
      return result
    })
    resolving = outcome
    return outcome
  }

  identity.subscribe((next) => {
    state.value = next
    workspace.value = undefined
    if (next.phase === 'signed_in') {
      creationFailure.value = undefined
      void resolveWorkspace()
    }
  })

  function settledOf(): BillingWebSessionPhase | undefined {
    const current = state.value
    if (
      current.phase === 'signed_out' ||
      current.phase === 'api_key' ||
      current.phase === 'retry_wait'
    ) {
      return 'signed-out'
    }
    if (current.phase !== 'signed_in' || workspace.value === undefined) {
      return undefined
    }
    return workspace.value.status === 'ok' ? 'authenticated' : 'error'
  }

  /** Boots on first use and resolves once the session and workspace settle. */
  function settledPhase(): Promise<BillingWebSessionPhase> {
    identity.boot()
    return new Promise((resolve) => {
      const stop = watch(
        [state, workspace],
        () => {
          const phase = settledOf()
          if (phase === undefined) return
          resolve(phase)
          queueMicrotask(() => stop())
        },
        { immediate: true, flush: 'sync' }
      )
    })
  }

  /** Without a session to resolve against, a retry creates one for whoever Firebase holds. */
  async function sessionCreator(user?: User): Promise<User | undefined> {
    if (user !== undefined || state.value.phase === 'signed_in') return user
    return (await firebaseUser()) ?? undefined
  }

  async function establish(user?: User): Promise<SessionEstablishment> {
    const creator = await sessionCreator(user)
    if (creator === undefined) return establishmentOf(await resolveWorkspace())
    const created = await createWebSession(session, () => creator.getIdToken())
    if (created.status !== 'ok') {
      creationFailure.value = creationRefusal(created)
      return { status: 'error', code: creationFailure.value.code }
    }
    creationFailure.value = undefined
    identity.dispose()
    if ((await settledPhase()) === 'authenticated') return { status: 'ok' }
    const resolved = workspace.value
    return {
      status: 'error',
      code: resolved?.status === 'error' ? resolved.code : 'NOT_AUTHENTICATED'
    }
  }

  const scope = computed<BillingScope | undefined>(() => {
    const current = state.value
    const resolved = workspace.value
    if (current.phase !== 'signed_in' || resolved?.status !== 'ok') {
      return undefined
    }
    return {
      userId: current.session.user.id,
      workspaceId: resolved.workspace.id,
      role: resolved.workspace.role ?? 'member'
    }
  })

  const scopeSource: BillingScopeSource = {
    getScope: () => scope.value,
    subscribe: (listener) => watch(scope, () => listener(), { flush: 'sync' })
  }

  const webSession: CredentialedWebSession = {
    authorize,
    getSession: () =>
      state.value.phase === 'signed_in' ? state.value.session : undefined,
    readSession: ({ expectedUserId, signal }) =>
      readWebSession({ ...session, signal }, { expectedUserId })
  }

  const signInPort: SignInPort = {
    user: computed(() =>
      state.value.phase === 'signed_in' ? state.value.session.user : null
    ),
    failure: computed(() =>
      workspace.value?.status === 'error'
        ? { code: workspace.value.code }
        : creationFailure.value
    ),
    loadIdentity: async () =>
      (await settledPhase()) === 'signed-out' ? deps.loadFirebase() : undefined,
    establish
  }

  return {
    fetchImpl: deps.fetchImpl,
    settledPhase,
    livePhase: computed(settledOf),
    resolveWorkspace,
    sessionGet,
    scopeSource,
    webSession,
    signInPort,
    billedScope: computed(() => {
      const resolved = workspace.value
      const userId = scope.value?.userId
      return userId !== undefined && resolved?.status === 'ok'
        ? { uid: userId, workspace: resolved.workspace }
        : undefined
    })
  }
}

export type UnifiedBillingSession = ReturnType<
  typeof createUnifiedBillingSession
>
