<script setup lang="ts">
import { useId } from 'vue'
import { useI18n } from 'vue-i18n'

import type { PromoRejection } from '@/checkout/promoEntry'

const { draft, error, locked } = defineProps<{
  draft: string
  error?: PromoRejection
  /** Not live, or the typed code is being priced. */
  locked: boolean
}>()

const emit = defineEmits<{
  edit: [draft: string]
  dismiss: []
  apply: []
}>()

const { t } = useI18n()
const errorId = useId()

const P = 'checkout.fullPage.summary.promo'

function edit(event: Event) {
  if (event.target instanceof HTMLInputElement) emit('edit', event.target.value)
}
</script>

<template>
  <form class="flex flex-col gap-2" novalidate @submit.prevent="emit('apply')">
    <div class="flex items-center gap-2 text-foreground">
      <input
        :value="draft"
        :aria-label="t(`${P}.field`)"
        :aria-invalid="error !== undefined"
        :aria-describedby="error && errorId"
        :disabled="locked"
        autocomplete="off"
        spellcheck="false"
        class="h-8 min-w-0 flex-1 rounded-lg border bg-input px-3 text-sm focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:opacity-40 max-lg:h-10"
        @input="edit"
      />
      <button
        type="submit"
        :disabled="locked"
        class="flex h-8 cursor-pointer items-center rounded-lg bg-secondary px-2 text-xs hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-40 max-lg:h-10 max-lg:px-3"
      >
        {{ t(`${P}.apply`) }}
      </button>
      <button
        type="button"
        :disabled="locked"
        :aria-label="t(`${P}.dismiss`)"
        class="flex size-8 cursor-pointer items-center justify-center rounded-lg hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-40 max-lg:size-10"
        @click="emit('dismiss')"
      >
        <i class="icon-[lucide--x] size-4" aria-hidden="true" />
      </button>
    </div>
    <p
      v-if="error"
      :id="errorId"
      role="alert"
      class="m-0 text-xs text-destructive"
    >
      {{ t(`${P}.${error}`) }}
    </p>
  </form>
</template>
