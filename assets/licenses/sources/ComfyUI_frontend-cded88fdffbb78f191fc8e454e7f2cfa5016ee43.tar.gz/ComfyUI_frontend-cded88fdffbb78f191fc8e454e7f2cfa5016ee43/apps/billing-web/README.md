# Billing Web

`@comfyorg/billing-web` is the static Vue/Vite SPA for the hosted Comfy Cloud
billing experience.

## Current scope

This package contains the application shell, routing, localization, test/build
tooling, the hosted embedded subscription checkout presentation, this origin's
own Firebase identity and workspace session, the shared web session behind the
`unified_web_session` flag, and the Billing SDK composition over them. The
checkout component owns the payment-summary and success layouts
and emits host events for the Billing SDK adapter. It does not contain:

- a server runtime or BFF
- a cookie-backed session of its own: the shared web session is Cloud's, read
  through `@comfyorg/account-core`
- Stripe Elements initialization

The hosted views read the SDK client, but the checkout's confirm action stays
disabled until the payment slice connects it. Billing data, quotes, commands,
and operation state come from the shared `@comfyorg/account-core` Billing SDK;
`src/session/billingWebClient.ts` is the single place the core is constructed.
The billing backend remains owned by the Cloud repository. The existing
frontend Pinia, workspace API, and dialog orchestration are not copied into
this app.

## Authentication

Every route but `/sign-in` requires an authenticated workspace session; the
router guard redirects anyone else to `/sign-in?returnTo=<path>`, and only a
same-origin absolute path is ever honoured as a return destination.

**Flag off (default).** The session is this origin's own: a Firebase identity
for the project its Cloud origin's `/api/features` names at runtime, exchanged at
`${cloud}/api/auth/token` for the workspace-scoped JWT, cached in
`sessionStorage` so it survives a reload but never outlives the tab. There is
no build-time Firebase configuration and no fallback if that fetch fails: a
stale project surviving a rotation is worse than reporting sign-in
unavailable, since a usable session only ever comes from token exchange at
that same Cloud origin anyway. Password recovery stays a single flow, owned
by the Cloud app's own page.

**`unified_web_session` on.** The mode is decided once per page load in
`src/session/billingWebAuth.ts`. It reads the `web_session_probe` from the
`/api/features` document this app already fetches, then a credentialed read of
`unified_web_session`. If neither answers within 800 ms the page stays on
Firebase, and the mode never changes after that. On the session path:

- Identity comes from the shared session cookie, read at
  `${cloud}/api/auth/session`.
- The workspace comes from `GET /api/workspaces/current`, sent with the entry
  link's `X-Comfy-Workspace-ID`. Without one it is the personal workspace.
- Billing calls use the cookie transport: no `Authorization` header, and a CSRF
  token on unsafe methods (`createWebSessionBillingClient`).
- Firebase loads only when the session reports none, to restore a login or to
  sign in. A sign-in creates the shared session, so the next page load needs no
  Firebase.

See [ADR-AUTH-SESSION-0037](../../docs/adr/AUTH-SESSION-0037-shared-web-session-on-a-host-only-cookie.md)
for the decision and `packages/account-core/docs/web-session.md` for the
shared building blocks.

## Environment variables

Configure these per deployment (see `.env_example`):

| Variable                      | Required | Meaning                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ----------------------------- | -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `VITE_BILLING_ENV`            | no       | Backend family: `production`, `staging` or `test`. Unset or misspelt resolves to `test`, so a misconfigured deployment cannot reach production Cloud. It selects the Cloud origin (`https://cloud.comfy.org`, `https://stagingcloud.comfy.org`, `https://testcloud.comfy.org`), whose `/api/features` names this deployment's Firebase project. Only needed when the deployment hostname isn't one of the three below — `billing.comfy.org`, `stagingbilling.comfy.org` and `testbilling.comfy.org` self-detect their family and need no override. |
| `VITE_STRIPE_PUBLISHABLE_KEY` | no       | Stripe publishable key for the same family. Without it the checkout surface reports that payment is unavailable and takes no card: there is no hosted-page fallback on `/v1/checkout`. The portal-driven steps (payment methods, invoices) are unaffected, since they open the provider's own hosted portal and need no key.                                                                                                                                                                                                                       |

## Telemetry

Datadog RUM reports to the Cloud app's RUM application as the
`comfy-billing-web` service. Only the three billing hosts report, each under
the Cloud family's `env` (`prod-v2`, `stg-v2`, `test-v2`); previews and local
builds send nothing. `version` is the build's commit, from
`FRONTEND_COMMIT_HASH` or `git rev-parse HEAD`. Trace headers are off, since
every Cloud call is cross-origin. Before an event leaves the page, URLs lose
their query and fragment, and error text and clicked element text lose emails,
tokens and client secrets. RUM cannot rewrite an error's causes, so an error
whose cause carries such text is dropped. No deployment setting is needed.

The RUM user is the signed-in user's opaque id, the one the Cloud app sets and
PostHog identifies here, and nothing else: no email, no name. It follows the
same session as PostHog, so a refused or still-resolving session sets and
clears nothing, and only the sign-out of a user set here clears it.

PostHog joins the Cloud app's project with the token, host and
`telemetry_disabled_events` that the Cloud origin's `/api/features` returns, on
the same fetch that names the Firebase project. Its identity cookie is shared
with every `*.comfy.org` page: it identifies the signed-in user unless the
cookie already names them, starts fresh when it names someone else, and resets
only when the user identified here signs out. It keeps
`person_profiles: 'identified_only'`; the server's `posthog_config` overrides
are not applied here. Session recording, web vitals, heatmaps, dead clicks,
exception capture and external scripts are off, and the promo code and Stripe
return parameters are masked wherever PostHog stores a URL, its cookie
included. Its `before_send` strips the same PII keys as the Cloud app and drops
every URL's query and fragment. Billing events go through
`billingWebTelemetry.trackBillingEvent`, which takes a `BillingTelemetryEvent`
from `@comfyorg/account-core/billing`, keeps only its allowlisted fields,
stamps `billing_surface: 'billing_web'` and sends to both sinks.
PostHog adds `$feature/<flag>` to an event only once this origin has loaded
the flags, so billing events wait for that load, at most three seconds,
before they reach PostHog. The rollout cohort tiles split on those flags.

### Attempt and operation events

The SDK's operation lifecycle reports through `toBillingTelemetryEvent` from
`@comfyorg/account-core/billing`, the one mapper the Cloud app uses too:
`billing.operation.started`, `.succeeded`, `.failed` and `.timeout`, with
`billing_client: 'sdk'`, for every operation this tab issues or recovers
(subscribe, resubscribe, cancel and top-up). A recovered operation reports
`resumed: true`. A refusal before the server issues an operation has no
operation to report, so it is not on this stream.

A subscribe or plan change reports its own lifecycle on both checkouts:
`billing.subscription_checkout.intent` and `.started` at the pay press,
immediately before the request, then one `.succeeded` or `.failed`. The
terminal carries `billing_op_id` once the server issued one. A refusal before
that (validation, a 4xx or 5xx, no connection, an operation already pending, a
stale quote) fails with a bounded `failure_category` and `error_code`, never
the server's words. The server asking for the reactivation consent keeps the
same attempt open, and a retry after a terminal starts a new one.
`checkout_ui` names the checkout, `embedded` or `full_page`.

Resubscribing from the subscription screen reports `billing.resubscribe.started`
and one terminal the same way, with `source: 'billing_web_subscription'`. A plan
that is already active counts as succeeded. The SDK stream reports a
resubscribe as a plain `subscription` operation, so these events are the only
way to tell the two apart. Cancel reports only the SDK stream.

### Entry, session and return events

These are client journey events: they carry `outcome: 'pending'` and never
claim an operation result. Each is reported once per tab, not per navigation:
`trackOncePerTab` remembers what the tab has reported in `sessionStorage`, so a
route change, the sign-in redirect and a reload send nothing more. A tab that
refuses storage still reports once per page load.

- `billing.web_entry.received`: an entry link was admitted. Carries `intent`,
  `product`, `has_plan`, and the link's `payment_intent_source` and
  `correlation_id` (the Cloud journey id) when it has them.
- `billing.web_entry.rejected`: the link could not be used; `error_code` is the
  entry parser's code.
- `billing.web_entry.bounced`: billing web sent the customer back to the host
  (`pricing_link`, `planless_checkout`) or replaced a checkout's `return_to`
  (`return_target_rewritten`); `to` is the return target or `pricing_table`.
- `billing.web_session.signin_required`: the sign-in page opened on a session
  that is signed out (`no_session`) or refused (`refused`). Counting these
  against `received` is the second sign-in the shared web session removes.
- `billing.web_session.established`: a session became usable. `origin` is
  `interactive` once the customer signed in on this page, otherwise `restored`;
  `mode` is `session-client` or `web-session`.
- `billing.web_session.failed`: a session could not be established; `error_code`
  is a `SessionErrorCode`, reported once per code. Creating the shared session
  reports `INVALID_FIREBASE_TOKEN` for a refused credential and
  `TOKEN_EXCHANGE_FAILED` for any other failure.
- `billing.web_return.clicked`: the customer clicked a way back to the host. It
  is sent on each click, not once per tab. `control` is `back` (a checkout's
  back arrow or Back button), `close` (the embedded checkout frame's close),
  `success_close` (the Close of a finished checkout) or `host_link` (a surface's
  "Return to" link). The countdown that closes a finished checkout's tab is
  not a click and reports nothing.

### Checkout journey events

Both checkouts report the cloud app's `billing.checkout.<phase>` journey through
`billingWebTelemetry.trackCheckoutJourneyEvent`, stamped with
`billing_surface: 'billing_web'` and a `ui_mode` of `embedded` or `full_page`,
so the funnel compares per surface. The journey id is the entry link's
`correlation_id`, or a fresh one for a link that carries none, and
`payment_intent_source` on `entered` is the link's `source`. `preview_ready` and `preview_failed` report each quote
once; a refused capability, plan or quote names a bounded `denial_reason` or
`error_code`. The payment form's `payment_element_*` and `payment_submit_*`
phases pass through as the form reports them, `submitted` fires on each Pay that
goes ahead, and `operation_linked` carries the operation that Pay issued, never
one the checkout recovered. `method_selected` names the rail (`saved`, `new`,
`on_file`) and the method kind (`card`, `alipay`, `other`) just before
`submitted`. `promo` reports `applied`, `rejected`, `removed` or `expired`, with
`prefilled` when the entry link carried the code, and `pay_blocked` reports a
full-page Pay held back by an unticked consent or an unapplied code. The
embedded checkout disables Pay under those guards, so it reports no blocked
press. `entry_flow` is the quote's, so it reads `unknown` on `entered`. No event
carries a promo code, an email, a URL, a client secret or a provider id.

## Commands

Run these commands from the repository root:

```bash
pnpm dev:cloud:billing-web
pnpm --filter @comfyorg/billing-web dev
pnpm --filter @comfyorg/billing-web typecheck
pnpm --filter @comfyorg/billing-web test:unit
pnpm --filter @comfyorg/billing-web build
```

## Deployment

The app deploys to Vercel as a static SPA from
`apps/billing-web/vercel.json`. Vercel hosts the MVP only;
[ADR-BILLING-WEB-0031](../../docs/adr/BILLING-WEB-0031-static-spa-boundary.md)
targets self-hosted nginx for production billing traffic, so keep the build a
plain directory of static files and express hosting behavior in ways an nginx
rule can reproduce. Two workflows own the deploys, both driving prebuilt
Vercel CLI deploys rather than Vercel's own git integration:

| Environment | Host                       | Vercel project                               | Trigger                                            |
| ----------- | -------------------------- | -------------------------------------------- | -------------------------------------------------- |
| PR preview  | `*.vercel.app` alias       | `billing-web`                                | `billing-preview` label on a pull request          |
| test        | `testbilling.comfy.org`    | `billing-web-test`                           | every push to `main` touching this app or its deps |
| staging     | `stagingbilling.comfy.org` | `billing-web` (`staging` custom environment) | manual dispatch                                    |
| production  | `billing.comfy.org`        | `billing-web`                                | manual dispatch                                    |

`.github/workflows/ci-vercel-billing-web-preview.yaml` owns the PR preview.
`.github/workflows/ci-vercel-billing-web-deploy.yaml` owns test, staging and
production: a push to `main` deploys test automatically, and a
`workflow_dispatch` with an `environment` choice (`staging` or `production`,
default `staging`) deploys the other two. Both jobs in the deploy workflow
refuse any ref other than `main`, so a dispatch from a feature branch cannot
reach a hosted environment, and test never runs from a fork since it only
triggers on `push`.

Staging and production never follow a merge. Merging to `main` only changes
what test serves; a person runs the deploy workflow from the Actions tab (or
`gh workflow run ci-vercel-billing-web-deploy.yaml --ref main -f
environment=staging`) when either hosted app should change for customers.

Previews are opt-in. The preview workflow triggers on pull requests touching
`apps/billing-web/**`, the workspace packages it imports
(`packages/account-core/**`, `packages/account-ui/**`,
`packages/billing-contract/**`, `packages/design-system/**`,
`packages/ingest-types/**`, `packages/tailwind-utils/**`), `public/fonts/**`
or `pnpm-workspace.yaml`, and never on one targeting `core/**` or `cloud/**`.
The deploy job then runs only while the `billing-preview` label is on the
pull request, and never from a fork. Adding the label deploys the current
head; removing it stops subsequent deploys. The path filter keeps the
workflow off unrelated pull requests, so the label alone will not deploy a
branch that changes none of those paths. The `push`-triggered test deploy
uses the same package list plus `pnpm-lock.yaml`, since a lockfile-only bump
of one of those packages should still refresh test.

Vercel project settings:

- Project Name: `billing-web`, under the `comfyui` team. Ingest matches
  `billing-web-<hash>-comfyui.vercel.app` and
  `billing-web-git-<branch>-comfyui.vercel.app` by pattern
  (`services/ingest/server/server.go` in `Comfy-Org/cloud`), so a rename
  CORS-blocks every preview until those patterns change with it.
- Root Directory: `apps/billing-web`, with **Include source files outside of
  the Root Directory** enabled — the build resolves workspace packages.
- Framework Preset: Other. `vercel.json` supplies the install, build, and
  output settings.
- Git integration disabled (`github.enabled: false`) on both the
  `billing-web` and `billing-web-test` projects, and both keep their Ignored
  Build Step as `exit 0`. A git-triggered build never deploys; only a
  prebuilt CLI deploy from one of these workflows does.

Every job in both workflows sits behind its own `preflight` job that checks
the Vercel secrets it needs. While any of them is missing, the deploy it
gates skips with a notice instead of failing, so a workflow can merge before
its Vercel project exists.

Required GitHub Actions secrets:

| Secret                               | Value                                                                             |
| ------------------------------------ | --------------------------------------------------------------------------------- |
| `VERCEL_BILLING_WEB_ORG_ID`          | Vercel team ID for the `comfyui` scope                                            |
| `VERCEL_BILLING_WEB_TOKEN`           | Vercel access token scoped to the team                                            |
| `VERCEL_BILLING_WEB_PROJECT_ID`      | Project ID of the `billing-web` Vercel project (PR previews, staging, production) |
| `VERCEL_BILLING_WEB_TEST_PROJECT_ID` | Project ID of the `billing-web-test` Vercel project                               |

The token has to carry team scope. A token scoped to the `billing-web`
project alone cannot read project settings — the API answers `403` and
`vercel pull` fails with `Could not retrieve Project Settings`, which reads as
a linking problem rather than a permission one. Narrowing the blast radius
belongs to a dedicated CI account that owns the token, not to the token's
scope.

Client-side routes fall back to `index.html` through the `rewrites` rule. The
rule matches extensionless paths only, so a missing file stays a 404 instead of
returning the HTML shell under a script, style, or font URL. The design-system
stylesheet still carries absolute `/fonts/*.woff2` sources that this app does
not host; they 404 and the browser falls through to the hashed `/assets/` faces
in the same `@font-face` rule.

A custom host is a separate step. `comfy.org` DNS is on Cloudflare, so
`billing.comfy.org` needs a `CNAME` to `cname.vercel-dns.com` there plus the
domain added to the Vercel project. Until that exists, the deployment is
reachable at its `*.vercel.app` host, and the core frontend's
`VITE_BILLING_WEB_URL` must point at whichever origin is live — it accepts
`https` only outside local development.

## Browser tests

`pnpm --filter @comfyorg/billing-web test:e2e` runs the Playwright suite in
`e2e/` against a production build of this app and a Cloud, identity and
payment portal the suite answers in-process; see `e2e/README.md`. CI runs it
as `CI: Billing Web E2E` whenever this app or a package changes.

## Path-prefixed hosting

`VITE_BILLING_WEB_URL` may point at a path prefix, such as
`https://host/billing/`. The router takes its history base from
`import.meta.env.BASE_URL`, which Vite fills in from `base`, so a prefixed
deployment needs nothing beyond the build-time value:

```bash
pnpm --filter @comfyorg/billing-web build --base=/billing/
```

Built assets and history routes then resolve under the same prefix. Which
prefix a deployment uses belongs to the hosting-provider decision deferred in
`docs/adr/BILLING-WEB-0031-static-spa-boundary.md`.

`pnpm dev:cloud:billing-web` runs the Cloud frontend on port 5173 and this app
on port 5174. The command supplies `VITE_BILLING_WEB_URL` to the Cloud frontend.
The hosted entry stays on the provider page until the server's
`hosted_billing_destination` flag resolves to `billing_web` or a developer
opts in from the browser console:

```javascript
localStorage.setItem('ff:hosted_billing_destination', '"billing_web"')
```

Reload the Cloud frontend after changing the override. Existing Subscribe,
Resubscribe, and embedded-checkout actions remain in the core frontend until
the hosted app reaches feature parity.

## Vercel previews

The Vercel project is `billing-web` under the `comfyui` team, so every
deployment answers on `billing-web-<hash>-comfyui.vercel.app` and every branch
on `billing-web-git-<branch>-comfyui.vercel.app`; CI also aliases each pull
request to `comfy-billing-web-preview-pr-<N>.vercel.app`. Ingest's non-prod
`CORS_ORIGIN` and `TOPUP_CHECKOUT_RETURN_HOSTS` sentinels are derived from
those three hostname shapes, so renaming the project or the team is a breaking
change for the Cloud overlays, not a dashboard-only edit.

## Security headers

`vercel.json` sends `X-Robots-Tag: noindex`, `X-Content-Type-Options: nosniff`,
`Referrer-Policy: strict-origin-when-cross-origin` and `X-Frame-Options: DENY`
on every response: billing is opened as its own tab and is never embedded.

A Content Security Policy is sent as `Content-Security-Policy-Report-Only`
while the hosted checkout is verified on previews. Report-only means a
violation is logged in the browser console and blocks nothing, so a missing
origin surfaces during review instead of as a payment that silently fails in
production. The allowlist names what the app actually loads:

| Directive     | Origins                                                                                                                                                            | For                                                         |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------- |
| `script-src`  | `js.stripe.com`, `challenges.cloudflare.com`, `apis.google.com`                                                                                                    | Stripe.js, Turnstile, the Firebase popup sign-in helper     |
| `connect-src` | the three Cloud origins, `api.stripe.com`, the Firebase identity and token endpoints, the two auth domains, the Datadog RUM intake, the PostHog host `t.comfy.org` | billing reads and commands, Elements, sign-in, RUM, PostHog |
| `frame-src`   | `js.stripe.com`, `hooks.stripe.com`, `challenges.cloudflare.com`, the two auth domains, `apis.google.com`                                                          | Elements, 3DS, Turnstile, the Firebase auth iframe          |
| `style-src`   | `'self' 'unsafe-inline'`                                                                                                                                           | Vue-managed inline styles                                   |

The two auth domains are `dreamboothy.firebaseapp.com` (production) and
`dreamboothy-dev.firebaseapp.com` (staging and test), the projects the three
Cloud origins report in `/api/features`. They are spelled out rather than
wildcarded because `*.firebaseapp.com` is every Firebase project there is;
naming a Cloud origin's project under a new auth domain needs a CSP update
here alongside it.

No `report-to` endpoint is set: this origin has no server of its own to
receive reports, so a violation is visible only in the console of a browser
with devtools open. That is the deliberate scope of the report-only phase,
which is verified by hand on previews as described below. After promotion a
violation in production is invisible until a reporting endpoint exists, which
is the first addition to make when one does.

Promote it to `Content-Security-Policy` once a preview has completed sign-in
(email and Google), a card checkout with a 3DS challenge, and a portal
round-trip with no violation in the console. Read each report before acting on
it: add an origin only when the report names an expected, trusted external
resource the flow loads. A report about inline code, a `data:` or `blob:`
source, or framing is a resource to fix or a directive to keep, not a source
to add.
