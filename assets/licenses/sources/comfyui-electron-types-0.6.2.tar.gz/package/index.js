const IPC_CHANNELS = {
  LOADING_PROGRESS: "loading-progress",
  IS_PACKAGED: "is-packaged",
  RENDERER_READY: "renderer-ready",
  RESTART_APP: "restart-app",
  REINSTALL: "reinstall",
  QUIT: "quit",
  LOG_MESSAGE: "log-message",
  DOWNLOAD_PROGRESS: "download-progress",
  START_DOWNLOAD: "start-download",
  PAUSE_DOWNLOAD: "pause-download",
  RESUME_DOWNLOAD: "resume-download",
  CANCEL_DOWNLOAD: "cancel-download",
  DELETE_MODEL: "delete-model",
  GET_ALL_DOWNLOADS: "get-all-downloads",
  GET_ELECTRON_VERSION: "get-electron-version",
  GET_BASE_PATH: "get-base-path",
  SET_BASE_PATH: "set-base-path",
  GET_MODEL_CONFIG_PATH: "get-model-config-path",
  OPEN_PATH: "open-path",
  OPEN_LOGS_PATH: "open-logs-path",
  OPEN_DEV_TOOLS: "open-dev-tools",
  TERMINAL_WRITE: "execute-terminal-command",
  TERMINAL_RESIZE: "resize-terminal",
  TERMINAL_RESTORE: "restore-terminal",
  TERMINAL_ON_OUTPUT: "terminal-output",
  GET_SYSTEM_PATHS: "get-system-paths",
  VALIDATE_INSTALL_PATH: "validate-install-path",
  VALIDATE_COMFYUI_SOURCE: "validate-comfyui-source",
  SHOW_DIRECTORY_PICKER: "show-directory-picker",
  INSTALL_COMFYUI: "install-comfyui",
  CHANGE_THEME: "change-theme",
  SHOW_CONTEXT_MENU: "show-context-menu",
  RESTART_CORE: "restart-core",
  GET_GPU: "get-gpu",
  SET_WINDOW_STYLE: "set-window-style",
  GET_VALIDATION_STATE: "get-validation-state",
  VALIDATION_UPDATE: "validation-update",
  COMPLETE_VALIDATION: "complete-validation",
  CANCEL_VALIDATION: "cancel-validation",
  VALIDATE_INSTALLATION: "start-validation",
  UV_INSTALL_REQUIREMENTS: "uv-install-requirements",
  GET_WINDOW_STYLE: "get-window-style",
  TRACK_EVENT: "track-event",
  SET_METRICS_CONSENT: "set-metrics-consent",
  INCREMENT_USER_PROPERTY: "increment-user-property",
  UV_CLEAR_CACHE: "uv-clear-cache",
  UV_RESET_VENV: "uv-delete-venv",
  CAN_ACCESS_URL: "can-access-url",
  START_TROUBLESHOOTING: "start-troubleshooting",
  DISABLE_CUSTOM_NODES: "disable-custom-nodes",
  CHECK_FOR_UPDATES: "check-for-updates",
  RESTART_AND_INSTALL: "restart-and-install",
  CHECK_BLACKWELL: "check-blackwell",
  GET_INSTALL_STAGE: "get-install-stage",
  INSTALL_STAGE_UPDATE: "install-stage-update",
  DIALOG_CLICK_BUTTON: "dialog-click-button"
};
var ProgressStatus = /* @__PURE__ */ ((ProgressStatus2) => {
  ProgressStatus2["INITIAL_STATE"] = "initial-state";
  ProgressStatus2["PYTHON_SETUP"] = "python-setup";
  ProgressStatus2["STARTING_SERVER"] = "starting-server";
  ProgressStatus2["READY"] = "ready";
  ProgressStatus2["ERROR"] = "error";
  return ProgressStatus2;
})(ProgressStatus || {});
const InstallStage = {
  // Initial stages
  IDLE: "idle",
  APP_INITIALIZING: "app_initializing",
  CHECKING_EXISTING_INSTALL: "checking_existing_install",
  // Pre-installation checks
  HARDWARE_VALIDATION: "hardware_validation",
  GIT_CHECK: "git_check",
  // User interaction
  WELCOME_SCREEN: "welcome_screen",
  INSTALL_OPTIONS_SELECTION: "install_options_selection",
  // Installation process
  CREATING_DIRECTORIES: "creating_directories",
  INITIALIZING_CONFIG: "initializing_config",
  PYTHON_ENVIRONMENT_SETUP: "python_environment_setup",
  INSTALLING_REQUIREMENTS: "installing_requirements",
  INSTALLING_PYTORCH: "installing_pytorch",
  INSTALLING_COMFYUI_REQUIREMENTS: "installing_comfyui_requirements",
  INSTALLING_MANAGER_REQUIREMENTS: "installing_manager_requirements",
  MIGRATING_CUSTOM_NODES: "migrating_custom_nodes",
  // Post-installation
  MAINTENANCE_MODE: "maintenance_mode",
  STARTING_SERVER: "starting_server",
  READY: "ready",
  ERROR: "error"
};
const ELECTRON_BRIDGE_API = "electronAPI";
const SENTRY_URL_ENDPOINT = "https://942cadba58d247c9cab96f45221aa813@o4507954455314432.ingest.us.sentry.io/4508007940685824";
const AMD_VENDOR_ID = "1002";
const NVIDIA_VENDOR_ID = "10DE";
const MigrationItems = [
  {
    id: "user_files",
    label: "User Files",
    description: "Settings and user-created workflows"
  },
  {
    id: "models",
    label: "Models",
    description: "Reference model files from existing ComfyUI installations. (No copy)"
  },
  {
    id: "custom_nodes",
    label: "Custom Nodes",
    description: "Reinstall custom nodes from existing ComfyUI installations."
  }
];
const DEFAULT_SERVER_ARGS = {
  listen: "127.0.0.1",
  port: "8000",
  "enable-manager": ""
};
var DownloadStatus = /* @__PURE__ */ ((DownloadStatus2) => {
  DownloadStatus2["PENDING"] = "pending";
  DownloadStatus2["IN_PROGRESS"] = "in_progress";
  DownloadStatus2["COMPLETED"] = "completed";
  DownloadStatus2["PAUSED"] = "paused";
  DownloadStatus2["ERROR"] = "error";
  DownloadStatus2["CANCELLED"] = "cancelled";
  return DownloadStatus2;
})(DownloadStatus || {});
var TorchMirrorUrl = /* @__PURE__ */ ((TorchMirrorUrl2) => {
  TorchMirrorUrl2["Default"] = "https://pypi.org/simple/";
  TorchMirrorUrl2["Cuda"] = "https://download.pytorch.org/whl/cu129";
  TorchMirrorUrl2["NightlyCuda"] = "https://download.pytorch.org/whl/nightly/cu129";
  TorchMirrorUrl2["NightlyCpu"] = "https://download.pytorch.org/whl/nightly/cpu";
  return TorchMirrorUrl2;
})(TorchMirrorUrl || {});
const CUDA_TORCH_URL = "https://download.pytorch.org/whl/cu129";
const NIGHTLY_CPU_TORCH_URL = "https://download.pytorch.org/whl/nightly/cpu";
const DEFAULT_PYPI_INDEX_URL = "https://pypi.org/simple/";
const AMD_ROCM_SDK_PACKAGES = [
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/rocm_sdk_core-0.1.dev0-py3-none-win_amd64.whl",
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/rocm_sdk_devel-0.1.dev0-py3-none-win_amd64.whl",
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/rocm_sdk_libraries_custom-0.1.dev0-py3-none-win_amd64.whl",
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/rocm-0.1.dev0.tar.gz"
];
const AMD_TORCH_PACKAGES = [
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/torch-2.9.0+rocmsdk20251116-cp312-cp312-win_amd64.whl",
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/torchaudio-2.9.0+rocmsdk20251116-cp312-cp312-win_amd64.whl",
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.1.1/torchvision-0.24.0+rocmsdk20251116-cp312-cp312-win_amd64.whl"
];
var LogFile = /* @__PURE__ */ ((LogFile2) => {
  LogFile2["ComfyUI"] = "comfyui.log";
  LogFile2["Main"] = "main.log";
  return LogFile2;
})(LogFile || {});
export {
  AMD_ROCM_SDK_PACKAGES,
  AMD_TORCH_PACKAGES,
  AMD_VENDOR_ID,
  CUDA_TORCH_URL,
  DEFAULT_PYPI_INDEX_URL,
  DEFAULT_SERVER_ARGS,
  DownloadStatus,
  ELECTRON_BRIDGE_API,
  IPC_CHANNELS,
  InstallStage,
  LogFile,
  MigrationItems,
  NIGHTLY_CPU_TORCH_URL,
  NVIDIA_VENDOR_ID,
  ProgressStatus,
  SENTRY_URL_ENDPOINT,
  TorchMirrorUrl
};
