export declare const AMD_ROCM_SDK_PACKAGES: string[];

export declare const AMD_TORCH_PACKAGES: string[];

export declare const AMD_VENDOR_ID = "1002";

/** @deprecated Use {@link TorchMirrorUrl} instead. */
export declare const CUDA_TORCH_URL = TorchMirrorUrl.Cuda;

/** @deprecated Use {@link TorchMirrorUrl} instead. */
export declare const DEFAULT_PYPI_INDEX_URL = TorchMirrorUrl.Default;

export declare const DEFAULT_SERVER_ARGS: ServerArgs;

export declare type DesktopInstallState = 'started' | 'installed' | 'upgraded';

export declare type DesktopWindowStyle = 'custom' | 'default';

export declare interface DownloadProgressUpdate {
    url: string;
    filename: string;
    savePath: string;
    progress: number;
    status: DownloadStatus;
    message?: string;
}

export declare interface DownloadState {
    url: string;
    filename: string;
    state: DownloadStatus;
    receivedBytes: number;
    totalBytes: number;
    isPaused: boolean;
}

export declare enum DownloadStatus {
    PENDING = "pending",
    IN_PROGRESS = "in_progress",
    COMPLETED = "completed",
    PAUSED = "paused",
    ERROR = "error",
    CANCELLED = "cancelled"
}

export declare const ELECTRON_BRIDGE_API = "electronAPI";

export declare type ElectronAPI = typeof electronAPI;

declare const electronAPI: {
    /**
     * Callback for progress updates from the main process for starting ComfyUI.
     * @param callback
     */
    readonly onProgressUpdate: (callback: (update: {
        status: ProgressStatus;
    }) => void) => void;
    readonly onLogMessage: (callback: (message: string) => void) => void;
    readonly sendReady: () => void;
    /** Emulates app.ispackaged in renderer */
    readonly isPackaged: () => Promise<boolean>;
    readonly restartApp: (customMessage?: string, delay?: number) => Promise<void>;
    /** Exits the application gracefully. */
    readonly quit: () => Promise<void>;
    /** @todo Move to {@link electronAPI.Validation} */
    readonly reinstall: () => Promise<void>;
    /**
     * Various paths that are useful to the renderer.
     * - Base path: The base path of the application.
     * - Model config path: The path to the model config yaml file.
     */
    readonly getBasePath: () => Promise<string>;
    /**
     * Opens a directory picker, saves the result as the base path if not cancelled.
     * @returns `true` if a new base path was selected and set successfully, otherwise `false`
     */
    readonly setBasePath: () => Promise<boolean>;
    readonly getModelConfigPath: () => Promise<string>;
    /**
     * Open various folders in the system's default file explorer.
     */
    readonly openLogsFolder: () => void;
    readonly openModelsFolder: () => Promise<void>;
    readonly openOutputsFolder: () => Promise<void>;
    readonly openInputsFolder: () => Promise<void>;
    readonly openCustomNodesFolder: () => Promise<void>;
    readonly openModelConfig: () => Promise<void>;
    /**
     * Open the developer tools window.
     */
    readonly openDevTools: () => void;
    readonly DownloadManager: {
        readonly onDownloadProgress: (callback: (progress: DownloadProgressUpdate) => void) => void;
        readonly startDownload: (url: string, path: string, filename: string) => Promise<boolean>;
        readonly cancelDownload: (url: string) => Promise<void>;
        readonly pauseDownload: (url: string) => Promise<void>;
        readonly resumeDownload: (url: string) => Promise<void>;
        readonly deleteModel: (filename: string, path: string) => Promise<boolean>;
        readonly getAllDownloads: () => Promise<DownloadState[]>;
    };
    /**
     * Get the current Electron version
     */
    readonly getElectronVersion: () => Promise<string>;
    /** The ComfyUI core version (as defined in package.json) */
    readonly getComfyUIVersion: () => string;
    readonly Terminal: {
        /**
         * Writes the data to the terminal
         * @param data The command to execute
         */
        readonly write: (data: string) => Promise<void>;
        /**
         * Resizes the terminal
         * @param data The command to execute
         */
        readonly resize: (cols: number, rows: number) => Promise<void>;
        /**
         * Gets the data required to restore the terminal
         * @param data The command to execute
         */
        readonly restore: () => Promise<{
            buffer: string[];
            size: {
                cols: number;
                rows: number;
            };
        }>;
        /**
         * Callback for terminal output messages
         * @param callback The output handler
         */
        readonly onOutput: (callback: (message: string) => void) => () => void;
    };
    /**
     * Get the system paths for the application.
     */
    readonly getSystemPaths: () => Promise<SystemPaths>;
    /**
     * Validate the install path for the application. Check whether the path is valid
     * and writable. The disk should have enough free space to install the application.
     * @param path The path to validate
     * @param bypassSpaceCheck Optional flag to bypass disk space requirement
     */
    readonly validateInstallPath: (path: string, bypassSpaceCheck?: boolean) => Promise<PathValidationResult>;
    /**
     * Validate whether the given path is a valid ComfyUI source path.
     */
    readonly validateComfyUISource: (path: string) => Promise<{
        isValid: boolean;
        error?: string;
    }>;
    /**
     * Show a directory picker dialog and return the selected path.
     */
    readonly showDirectoryPicker: () => Promise<string>;
    /**
     * Install ComfyUI with given options.
     * @todo Move to {@link electronAPI.Validation}
     */
    readonly installComfyUI: (installOptions: InstallOptions) => void;
    /**
     * Update the Window Controls Overlay theme overrides
     * @param theme The theme settings to apply
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Window_Controls_Overlay_API}
     */
    readonly changeTheme: (theme: ElectronOverlayOptions) => void;
    /**
     * Opens native context menus.
     *
     * {@link ElectronContextMenuOptions} contains the various options to control the menu type.
     * @param options Define which type of menu to use, position, etc.
     */
    readonly showContextMenu: (options?: ElectronContextMenuOptions) => void;
    readonly Config: {
        /**
         * Finds the name of the last detected GPU type.  Detection only runs during installation.
         * @returns The last GPU detected by `validateHardware` - runs during installation
         */
        readonly getDetectedGpu: () => Promise<GpuType | undefined>;
        /** Sets the window style */
        readonly setWindowStyle: (style: DesktopWindowStyle) => Promise<void>;
        readonly getWindowStyle: () => Promise<DesktopWindowStyle | undefined>;
    };
    readonly Events: {
        readonly trackEvent: (eventName: string, properties?: Record<string, unknown>) => void;
        readonly incrementUserProperty: (propertyName: string, number: number) => void;
    };
    readonly NetWork: {
        readonly canAccessUrl: (url: string, options?: {
            timeout?: number;
        }) => Promise<boolean>;
    };
    /** Restart the python server without restarting desktop. */
    readonly restartCore: () => Promise<void>;
    /** Gets the platform reported by node.js */
    readonly getPlatform: () => NodeJS.Platform;
    readonly setMetricsConsent: (consent: boolean) => Promise<void>;
    /**
     *  Interfaces related to installation / install validation
     *
     * Example usage:
     * ```typescript
     * // Set up validation listener
     * electronAPI.Validation.onUpdate((update) => {
     *   const validationInProgress.value = update.inProgress;
     *
     *   for (const [task, state] of Object.entries(update)) {
     *     if (task === 'installState' && !state) installApp();
     *     if (task === 'git' && state === 'error') downloadGit();
     *   }
     * });
     *
     * // Start installation validation
     * await electronAPI.Validation.validateInstallation((update) => {
     *   if (update.pythonInterpreter === 'error') {
     *     console.error('Python interpreter validation failed');
     *   }
     * });
     *
     * // Get current validation state
     * const status = await electronAPI.Validation.getStatus();
     *
     * // Clean up when done
     * electronAPI.Validation.dispose();
     * ```
     */
    readonly Validation: {
        /**
         * Sets a callback to receive updates during validation.
         * If an existing callback is set, it will be replaced.
         * @param callback Called with every update during validation
         */
        readonly onUpdate: (callback: (update: InstallValidation) => void) => void;
        /** Requests the current state of validation, for use by UI when initialising a component.  */
        readonly getStatus: () => Promise<InstallValidation>;
        /**
         * Attempts to complete validation, returning `true` if successful.
         * @returns A promise that resolves when validation is complete, `true` if validation was successful, otherwise `false`
         */
        readonly complete: () => Promise<boolean>;
        /**
         * Initiates validation.  Notifies updates via callback.
         * If an existing callback is set, it will be replaced.
         * @param callback Called with every update during validation
         * @returns A promise that resolves when validation is complete. The final {@link onUpdate} callback will have run in the main process, but the IPC event may not yet have hit the renderer when this promise resolves.
         */
        readonly validateInstallation: (callback: (update: InstallValidation) => void) => Promise<void>;
        /** Removes the validation update listener. Simpler than verifying determinism of UPDATE and COMPLETE. */
        readonly dispose: () => void;
    };
    /** Prepares IPC handlers. Until #831 is resolved, this will always load the troubleshooting page. */
    readonly startTroubleshooting: () => Promise<void>;
    /** Disables custom nodes by setting the `Comfy.Server.LaunchArgs` to an empty array. */
    readonly disableCustomNodes: () => Promise<void>;
    /**
     * Checks if the system is running on NVIDIA's Blackwell architecture.
     */
    readonly isBlackwell: () => Promise<boolean>;
    /**
     * Installation stage tracking interfaces
     */
    readonly InstallStage: {
        /**
         * Get the current installation stage
         * @returns The current installation stage information
         */
        readonly getCurrent: () => Promise<InstallStageInfo>;
        /**
         * Listen for installation stage updates
         * @param callback Called when the installation stage changes
         * @returns A function to remove the event listener
         */
        readonly onUpdate: (callback: (stage: InstallStageInfo) => void) => () => void;
    };
    readonly uv: {
        /**
         * Install the requirements for the ComfyUI server.
         * @returns A promise that resolves when the uv command is complete.
         */
        readonly installRequirements: () => Promise<boolean>;
        /**
         * Clears the uv cache of all downloaded packages.
         * @returns `true` if the cache was cleared successfully, otherwise `false`
         */
        readonly clearCache: () => Promise<boolean>;
        /**
         * Resets the virtual environment by deleting the venv directory.
         * @returns `true` if the virtual environment was reset successfully, otherwise `false`
         */
        readonly resetVenv: () => Promise<boolean>;
    };
    /**
     * Manually check for application updates.
     * @param options Optional option args, see todesktop docs.
     * @returns A promise that resolves to update availability and version.
     */
    readonly checkForUpdates: (options?: object) => Promise<{
        isUpdateAvailable: boolean;
        version?: string;
    }>;
    /**
     * Restarts and installs updates using todesktop.autoUpdater.restartAndInstall().
     */
    readonly restartAndInstall: () => Promise<void>;
    /**
     * Dialog API for custom dialogs
     */
    readonly Dialog: {
        /**
         * Sends a button click result back to the main process
         * @param returnValue The value to return from the dialog
         */
        readonly clickButton: (returnValue: string) => Promise<boolean>;
    };
};

export declare interface ElectronContextMenuOptions {
    type: 'system' | 'text' | 'image';
    pos?: Electron.Point;
}

/** @todo Type inference chain broken by comfyui-electron-types. This is duplication. */
export declare interface ElectronOverlayOptions {
    /**
     * The CSS color of the Window Controls Overlay when enabled.
     */
    color?: string;
    /**
     * The CSS color of the symbols on the Window Controls Overlay when enabled.
     */
    symbolColor?: string;
    /**
     * The height of the title bar and Window Controls Overlay in pixels.
     */
    height?: number;
}

export declare type GpuType = 'nvidia' | 'amd' | 'mps' | 'unsupported';

export declare interface InstallOptions {
    /** Base installation path */
    installPath: string;
    autoUpdate: boolean;
    allowMetrics: boolean;
    migrationSourcePath?: string;
    migrationItemIds?: string[];
    /** Torch compute device */
    device: TorchDeviceType;
    /** UV python mirror */
    pythonMirror?: string;
    /** pip mirrors */
    pypiMirror?: string;
    torchMirror?: string;
    /** Whether to bypass disk space requirements during installation */
    bypassSpaceCheck?: boolean;
}

export declare const InstallStage: {
    readonly IDLE: "idle";
    readonly APP_INITIALIZING: "app_initializing";
    readonly CHECKING_EXISTING_INSTALL: "checking_existing_install";
    readonly HARDWARE_VALIDATION: "hardware_validation";
    readonly GIT_CHECK: "git_check";
    readonly WELCOME_SCREEN: "welcome_screen";
    readonly INSTALL_OPTIONS_SELECTION: "install_options_selection";
    readonly CREATING_DIRECTORIES: "creating_directories";
    readonly INITIALIZING_CONFIG: "initializing_config";
    readonly PYTHON_ENVIRONMENT_SETUP: "python_environment_setup";
    readonly INSTALLING_REQUIREMENTS: "installing_requirements";
    readonly INSTALLING_PYTORCH: "installing_pytorch";
    readonly INSTALLING_COMFYUI_REQUIREMENTS: "installing_comfyui_requirements";
    readonly INSTALLING_MANAGER_REQUIREMENTS: "installing_manager_requirements";
    readonly MIGRATING_CUSTOM_NODES: "migrating_custom_nodes";
    readonly MAINTENANCE_MODE: "maintenance_mode";
    readonly STARTING_SERVER: "starting_server";
    readonly READY: "ready";
    readonly ERROR: "error";
};

export declare interface InstallStageInfo {
    stage: InstallStageName;
    progress?: number;
    message?: string;
    error?: string;
    timestamp: number;
}

export declare type InstallStageName = ValuesOf<typeof InstallStage>;

export declare interface InstallValidation {
    inProgress: boolean;
    /** Whether the app just been installed, upgraded, or install is complete and the server has been started at least once. */
    installState: DesktopInstallState;
    basePath?: ValidationIssueState;
    /** `true` if the stored base path is accessible but in an unsafe location (inside the app bundle, updater cache, or OneDrive). */
    unsafeBasePath?: boolean;
    /** The primary reason why the base path is considered unsafe, if known. */
    unsafeBasePathReason?: RestrictedPathType;
    venvDirectory?: ValidationIssueState;
    pythonInterpreter?: ValidationIssueState;
    pythonPackages?: ValidationIssueState;
    uv?: ValidationIssueState;
    git?: ValidationIssueState;
    vcRedist?: ValidationIssueState;
    upgradePackages?: ValidationIssueState;
}

export declare const IPC_CHANNELS: {
    readonly LOADING_PROGRESS: "loading-progress";
    readonly IS_PACKAGED: "is-packaged";
    readonly RENDERER_READY: "renderer-ready";
    readonly RESTART_APP: "restart-app";
    readonly REINSTALL: "reinstall";
    readonly QUIT: "quit";
    readonly LOG_MESSAGE: "log-message";
    readonly DOWNLOAD_PROGRESS: "download-progress";
    readonly START_DOWNLOAD: "start-download";
    readonly PAUSE_DOWNLOAD: "pause-download";
    readonly RESUME_DOWNLOAD: "resume-download";
    readonly CANCEL_DOWNLOAD: "cancel-download";
    readonly DELETE_MODEL: "delete-model";
    readonly GET_ALL_DOWNLOADS: "get-all-downloads";
    readonly GET_ELECTRON_VERSION: "get-electron-version";
    readonly GET_BASE_PATH: "get-base-path";
    readonly SET_BASE_PATH: "set-base-path";
    readonly GET_MODEL_CONFIG_PATH: "get-model-config-path";
    readonly OPEN_PATH: "open-path";
    readonly OPEN_LOGS_PATH: "open-logs-path";
    readonly OPEN_DEV_TOOLS: "open-dev-tools";
    readonly TERMINAL_WRITE: "execute-terminal-command";
    readonly TERMINAL_RESIZE: "resize-terminal";
    readonly TERMINAL_RESTORE: "restore-terminal";
    readonly TERMINAL_ON_OUTPUT: "terminal-output";
    readonly GET_SYSTEM_PATHS: "get-system-paths";
    readonly VALIDATE_INSTALL_PATH: "validate-install-path";
    readonly VALIDATE_COMFYUI_SOURCE: "validate-comfyui-source";
    readonly SHOW_DIRECTORY_PICKER: "show-directory-picker";
    readonly INSTALL_COMFYUI: "install-comfyui";
    readonly CHANGE_THEME: "change-theme";
    readonly SHOW_CONTEXT_MENU: "show-context-menu";
    readonly RESTART_CORE: "restart-core";
    readonly GET_GPU: "get-gpu";
    readonly SET_WINDOW_STYLE: "set-window-style";
    readonly GET_VALIDATION_STATE: "get-validation-state";
    readonly VALIDATION_UPDATE: "validation-update";
    readonly COMPLETE_VALIDATION: "complete-validation";
    readonly CANCEL_VALIDATION: "cancel-validation";
    readonly VALIDATE_INSTALLATION: "start-validation";
    readonly UV_INSTALL_REQUIREMENTS: "uv-install-requirements";
    readonly GET_WINDOW_STYLE: "get-window-style";
    readonly TRACK_EVENT: "track-event";
    readonly SET_METRICS_CONSENT: "set-metrics-consent";
    readonly INCREMENT_USER_PROPERTY: "increment-user-property";
    readonly UV_CLEAR_CACHE: "uv-clear-cache";
    readonly UV_RESET_VENV: "uv-delete-venv";
    readonly CAN_ACCESS_URL: "can-access-url";
    readonly START_TROUBLESHOOTING: "start-troubleshooting";
    readonly DISABLE_CUSTOM_NODES: "disable-custom-nodes";
    readonly CHECK_FOR_UPDATES: "check-for-updates";
    readonly RESTART_AND_INSTALL: "restart-and-install";
    readonly CHECK_BLACKWELL: "check-blackwell";
    readonly GET_INSTALL_STAGE: "get-install-stage";
    readonly INSTALL_STAGE_UPDATE: "install-stage-update";
    readonly DIALOG_CLICK_BUTTON: "dialog-click-button";
};

export declare type IPCChannel = (typeof IPC_CHANNELS)[keyof typeof IPC_CHANNELS];

/** The log files used by the desktop process. */
export declare enum LogFile {
    /** The ComfyUI server log file. */
    ComfyUI = "comfyui.log",
    /** The desktop process log file. */
    Main = "main.log"
}

export declare interface MigrationItem {
    id: string;
    label: string;
    description: string;
}

export declare const MigrationItems: MigrationItem[];

/** @deprecated Use {@link TorchMirrorUrl} instead. */
export declare const NIGHTLY_CPU_TORCH_URL = TorchMirrorUrl.NightlyCpu;

export declare const NVIDIA_VENDOR_ID = "10DE";

/** The result of validating a path (originally for ComfyUI installation). */
export declare type PathValidationResult = {
    isValid: boolean;
    /** `true` if the parent of the selected path (via `dirname()`) is not present (it must be present). */
    parentMissing?: boolean;
    /** `true` if the selected path already exists. */
    exists?: boolean;
    /** `true` if the selected path is not writable. */
    cannotWrite?: boolean;
    /** `true` if the selected path is within OneDrive. */
    isOneDrive?: boolean;
    /** `true` if the selected path is on a non-default drive. */
    isNonDefaultDrive?: boolean;
    /** `true` if the selected path is inside the desktop app bundle/install directory. */
    isInsideAppInstallDir?: boolean;
    /** `true` if the selected path is inside the updater cache directory that gets deleted on updates. */
    isInsideUpdaterCache?: boolean;
    /** The amount of free space in the path. `-1` if this could not be determined. */
    freeSpace: number;
    /** The amount of space in bytes required to install ComfyUI. */
    requiredSpace: number;
    /** If any unhandled exceptions occured, this is the result of casting the error to string. */
    error?: string;
};

export declare enum ProgressStatus {
    /**
     * Initial state, after the app has started.
     */
    INITIAL_STATE = "initial-state",
    /**
     * Setting up Python Environment.
     */
    PYTHON_SETUP = "python-setup",
    /**
     * Starting ComfyUI server.
     */
    STARTING_SERVER = "starting-server",
    /**
     * Ending state.
     * The ComfyUI server successfully started. ComfyUI loaded into the main window.
     */
    READY = "ready",
    /**
     * Ending state. General error state.
     */
    ERROR = "error"
}

declare type RestrictedPathType = 'appInstallDir' | 'updaterCache' | 'oneDrive';

export declare const SENTRY_URL_ENDPOINT = "https://942cadba58d247c9cab96f45221aa813@o4507954455314432.ingest.us.sentry.io/4508007940685824";

export declare interface ServerArgs {
    /** The host to use for the ComfyUI server. */
    listen: string;
    /** The port to use for the ComfyUI server. */
    port: string;
    /** Extra arguments to pass to the ComfyUI server. */
    [key: string]: string | number;
}

export declare interface SystemPaths {
    appData: string;
    appPath: string;
    defaultInstallPath: string;
}

export declare type TorchDeviceType = GpuType | 'cpu';

/** Python package index URLs to use when installing torch, torchvision, and torchaudio. */
export declare enum TorchMirrorUrl {
    /** Regular PyPI index URL. */
    Default = "https://pypi.org/simple/",
    /** PyTorch CUDA mirror. */
    Cuda = "https://download.pytorch.org/whl/cu129",
    /** PyTorch Nightly CUDA mirror. */
    NightlyCuda = "https://download.pytorch.org/whl/nightly/cu129",
    /** PyTorch nightly CPU mirror. */
    NightlyCpu = "https://download.pytorch.org/whl/nightly/cpu"
}

declare type ValidationIssueState = 'OK' | 'warning' | 'error' | 'skipped';

declare type ValuesOf<T> = T[keyof T];

export { }
